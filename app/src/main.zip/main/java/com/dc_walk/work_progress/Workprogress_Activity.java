package com.dc_walk.work_progress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class Workprogress_Activity extends Activity {

    //public String EMP_ID = "emp_id";


    Button back_btn;
    ImageButton next_btn;

    EditText ed_other_rsp, ed_supplier_rsp, ed_vendorResp;
    String str_supplier_rsp, str_other_rsp, str_vendorResp;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.workprogress);

        next_btn = (ImageButton) findViewById(R.id.next_btn);

     //-------------for back Page-----------------//
        back_btn = (Button) findViewById(R.id.back_btn);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Intent i = new Intent(ReceivingInspection_Activity.this, Home_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });

        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 Intent i = new Intent(Workprogress_Activity.this, Workprogress_Item_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish(); // finish activity
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);




    }
   /* public void onBackPressed() {
        startActivity(new Intent(ReceivingInspection_Activity.this, Home_Activity.class));
        finish();
        overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }*/




}
