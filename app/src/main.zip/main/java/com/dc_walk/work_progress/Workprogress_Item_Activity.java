package com.dc_walk.work_progress;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class Workprogress_Item_Activity extends Activity {


    Button imageButton7;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.workprogress_item);

        imageButton7=(Button)findViewById(R.id.imageButton7);


    }





}