package com.dc_walk.takeover;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class Takeover_activity extends Activity {

    //public String EMP_ID = "emp_id";


    Button finishBtn,factory_inspection_item;

    EditText ed_other_rsp, ed_supplier_rsp, ed_vendorResp;
    String str_supplier_rsp, str_other_rsp, str_vendorResp;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.takeover_activity);







    }





}
