package com.dc_walk.walk;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;

import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;

import java.util.ArrayList;


public class Walk_Activity extends Activity {
    boolean check=true;

    public static MapFragment mapFragment;
    //public static View myView;

    RadioGroup radio_consumer_type;
    View myView;


    Spinner spinner_city,spinner_junction;
    String str_zone_id,str_city_name,str_city_id,str_junction_id,str_junction_name;


    Cursor city_cursor,junction_cursor;

    ArrayList<String> city_id_list,city_name_list,zone_id_list;
    ArrayList<String> junction_id_list,junction_name_list;


    ArrayAdapter<String> city_adapter,junction_adapter;
    SQLiteAdapter1 sqLiteAdapter;

    Button raid_btn,locobs_btn,struct_param_done_btn,structure_btn,rem_cancel,rem_ok;
    ImageButton pointer_btn,mapclose_btn,actestclose_btn,actest_btn,struct_param_close_btn,structure_close_btn,remBtn;
    FrameLayout mapbox,struct_param_box;
    ScrollView actest,struct_box;
    CheckBox checkStruct_btn,checkEnv_btn,checkBuilt_btn,checkUtil_btn;
    LinearLayout remark_pop;

    SessionManager sessionManager;
    ConnectionDetector connectionDetector;
    String response;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.walk_details);

        connectionDetector=new ConnectionDetector(Walk_Activity.this);
        sessionManager =new SessionManager(Walk_Activity.this);

        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        GoogleMap map = mapFragment.getMap();


        //myView = (View)findViewById(R.id.myview);

        pointer_btn = (ImageButton)findViewById(R.id.pointerId);
        mapbox= (FrameLayout) findViewById(R.id.mapBoxId);
        mapclose_btn= (ImageButton)findViewById(R.id.mapCloseId);
        locobs_btn=(Button) findViewById(R.id.locObs_Id);
        actest=(ScrollView) findViewById(R.id.actest);
        actest_btn=(ImageButton) findViewById(R.id.actest_done);
        actestclose_btn=(ImageButton) findViewById(R.id.actest_close);

        checkStruct_btn=(CheckBox) findViewById(R.id.check_structId);
        checkBuilt_btn=(CheckBox) findViewById(R.id.check_builtId);
        checkEnv_btn=(CheckBox) findViewById(R.id.check_envId);
        checkStruct_btn=(CheckBox) findViewById(R.id.check_structId);

        structure_close_btn=(ImageButton)findViewById(R.id.structure_close_id);
        structure_btn=(Button)findViewById(R.id.structure_id);
        struct_box=(ScrollView)findViewById(R.id.pop_structId);

        struct_param_close_btn=(ImageButton) findViewById(R.id.struct_param_close_id);
        struct_param_done_btn=(Button) findViewById(R.id.struct_param_done_id);
        struct_param_box=(FrameLayout) findViewById(R.id.struct_param_id);

        remBtn=(ImageButton) findViewById(R.id.remButton);
        remark_pop=(LinearLayout) findViewById(R.id.rem_pop1);
        rem_cancel=(Button) findViewById(R.id.rem_pop1_cancel);
        rem_ok=(Button) findViewById(R.id.rem_pop1_ok);

        pointer_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapbox.setVisibility(View.VISIBLE);

            }

        });
        mapclose_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapbox.setVisibility(View.GONE);
            }

        });
        locobs_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actest.setVisibility(View.VISIBLE);
            }

        });
        actest_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actest.setVisibility(View.GONE);
            }

        });
        actestclose_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actest.setVisibility(View.GONE);
            }

        });

        checkEnv_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if ( ((CheckBox)v).isChecked() ) {
                    // perform logic
                    struct_box.setVisibility(View.VISIBLE);
                }
            }
        });

        structure_close_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                struct_box.setVisibility(View.GONE);
            }

        });

        structure_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                struct_param_box.setVisibility(View.VISIBLE);
            }

        });

        struct_param_done_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                struct_param_box.setVisibility(View.GONE);
            }

        });
        struct_param_close_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                struct_param_box.setVisibility(View.GONE);
            }
        });
        remBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                remark_pop.setVisibility(View.VISIBLE);
            }
        });
        rem_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                remark_pop.setVisibility(View.GONE);
            }
        });
        rem_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                remark_pop.setVisibility(View.GONE);
            }
        });






    }








}
