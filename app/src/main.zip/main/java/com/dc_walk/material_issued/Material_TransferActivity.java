package com.dc_walk.material_issued;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Criteria;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.data_holder.DataHolder_ReceivingInspection;
import com.dc_walk.data_holder.DataHolder_SiteInspection;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;
import com.dc_walk.sqlite_adapter.SQLiteAdapterMaterialIssued;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;

public class Material_TransferActivity extends Activity {
    boolean check=true;

     RadioGroup radio_consumer_type;


    Spinner spinner_project, spinner_geographic, spinner_subarea_one,spinner_tkc,spinner_subarea_two,ed_vendor,storestock,ed_field;
    String project_code, project_id, geographic_project_code, geographic_id,geographic_name,
            subareaone_geographic_code,subarea_one_code,subarea_one_name,tkc_name,tkc_id,subareatwo_one_code,subarea_two_code,subarea_two_name;
    String str_qty_transfer,str_qty_rec,str_qty_damaged,str_qty_accepted,str_vendor,receiving_from,str_grn_transfer_note;

    EditText ed_store,ed_qty_transfer,ed_qty_rec,ed_qty_damaged,ed_qty_accepted,ed_grn_transfer_note;
    LinearLayout vendor_hold,citystore_hold;

   Cursor project_cursor,geographic_cursor,subareaone_cursor,tkc_cursor,subareatwo_cursor;

    ArrayList<String> project_code_list,project_name_list,project_id_list;
    ArrayList<String> geographic_project_code_list,geographic_name_list,geographic_code_list;
    ArrayList<String> subareaone_geographic_code_list,subareaone_name_list,subareaone_code_list,storeid_list,storename_list;
    ArrayList<String> tkc_name_list,tkc_id_list;
    ArrayList<String> subareatwo_one_code_list,subareatwo_name_list,subareatwo_code_list;

    ArrayAdapter<String> project_adapter,geographic_adapter,subareaone_adapter,tkc_adapter,subareatwo_adapter;
    SQLiteAdapter1 sqLiteAdapter;

    Button camera_btn,observation_btn,next_btn,finish_btn;

    SessionManager sessionManager;
    ConnectionDetector connectionDetector;
    String response;
    SQLiteAdapterMaterialIssued sqLiteAdapterprogress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materialtransfer);

        connectionDetector=new ConnectionDetector(Material_TransferActivity.this);
        sessionManager =new SessionManager(Material_TransferActivity.this);
        sqLiteAdapterprogress= new SQLiteAdapterMaterialIssued(Material_TransferActivity.this);

        storestock = (Spinner) findViewById(R.id.storestock);
        ed_field = (Spinner) findViewById(R.id.ed_field);

        spinner_project = (Spinner) findViewById(R.id.to_city_id);

        spinner_geographic = (Spinner) findViewById(R.id.level_zone_id);
        spinner_geographic.setVisibility(View.GONE);
        citystore_hold=(LinearLayout) findViewById(R.id.citystore_hold);
        citystore_hold.setVisibility(View.GONE);

        spinner_subarea_one = (Spinner) findViewById(R.id.level_city_id);
        spinner_subarea_one.setVisibility(View.GONE);

        spinner_tkc = (Spinner) findViewById(R.id.item_id);


        spinner_subarea_two = (Spinner) findViewById(R.id.store_id);
        spinner_subarea_two.setVisibility(View.GONE);

        ed_qty_transfer = (EditText) findViewById(R.id.ed_qty_transfer);

        ed_vendor=(Spinner)findViewById(R.id.ed_vendor);
        ed_vendor.setVisibility(View.GONE);
        //vendor_hold=(LinearLayout) findViewById(R.id.vendor_hold);

        //vendor_hold.setVisibility(View.GONE);

        ed_grn_transfer_note = (EditText) findViewById(R.id.ed_grn_transfer_note);

        project_code_list=new ArrayList<String>();
        project_name_list=new ArrayList<String>();
        project_id_list=new ArrayList<String>();

        geographic_project_code_list=new ArrayList<String>();
        geographic_name_list=new ArrayList<String>();
        geographic_code_list=new ArrayList<String>();

        subareaone_geographic_code_list=new ArrayList<String>();
        subareaone_name_list=new ArrayList<String>();
        subareaone_code_list=new ArrayList<String>();

        tkc_name_list=new ArrayList<String>();
        tkc_id_list=new ArrayList<String>();

        subareatwo_one_code_list=new ArrayList<String>();
        subareatwo_name_list=new ArrayList<String>();
        subareatwo_code_list=new ArrayList<String>();


        radio_consumer_type = (RadioGroup) findViewById(R.id.radio_receiving_from);
        radio_consumer_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {

                if (checkedId == R.id.radio_vendor) {
                    receiving_from = "1";
                    ed_vendor.setVisibility(View.VISIBLE);
                    //vendor_hold.setVisibility(View.VISIBLE);
                    citystore_hold.setVisibility(View.GONE);
                    spinner_geographic.setVisibility(View.GONE);
                    spinner_subarea_one.setVisibility(View.GONE);
                    spinner_subarea_two.setVisibility(View.GONE);

                    storestock.setVisibility(View.GONE);
                    ed_field.setVisibility(View.GONE);


                } else if (checkedId == R.id.radio_field) {
                    receiving_from = "2";
                    ed_field.setVisibility(View.VISIBLE);

                    storestock.setVisibility(View.GONE);
                    ed_vendor.setVisibility(View.GONE);

                } else if (checkedId == R.id.radio_city_store) {
                    receiving_from = "3";
                    //new Geographic_Value(Material_TransferActivity.this).execute();

                    storestock.setVisibility(View.VISIBLE);
                    ed_vendor.setVisibility(View.GONE);
                    ed_field.setVisibility(View.GONE);
                    //vendor_hold.setVisibility(View.GONE);

                }

            }
        });



        new Project_Value(Material_TransferActivity.this).execute();


        spinner_project.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                project_code = project_code_list.get(position).toString();
                project_id = project_id_list.get(position).toString();
//                  Toast.makeText(getApplicationContext(),""+position,Toast.LENGTH_LONG).show();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });



        spinner_geographic.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                geographic_project_code=geographic_project_code_list.get(position).toString();
                geographic_id=geographic_code_list.get(position).toString();
                geographic_name=geographic_name_list.get(position).toString();
             //      Toast.makeText(getApplicationContext(),""+subdivision_code,Toast.LENGTH_LONG).show();

                if (position > 0) {
                    new SubAreaOne_Value(Material_TransferActivity.this).execute();
                } else {
                    spinner_subarea_one.setVisibility(View.GONE);
                    //spinner_subarea_one.setAdapter(null);
                    subareaone_geographic_code_list.clear();
                    subareaone_code_list.clear();
                    subareaone_name_list.clear();


                }



            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });


        spinner_subarea_one.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                subareaone_geographic_code = subareaone_geographic_code_list.get(position).toString();
                subarea_one_code=subareaone_code_list.get(position).toString();
                subarea_one_name=subareaone_name_list.get(position).toString();
//                Toast.makeText(getApplicationContext(),""+subdivision_code,Toast.LENGTH_LONG).show();

                if (position > 0) {
                    new SubAreaTwo_Value(Material_TransferActivity.this).execute();
                } else {
                    spinner_subarea_two.setVisibility(View.GONE);
                    //spinner_subarea_two.setAdapter(null);
                    subareatwo_one_code_list.clear();
                    subareatwo_code_list.clear();
                    subareatwo_name_list.clear();

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        spinner_subarea_two.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                subareatwo_one_code = subareatwo_one_code_list.get(position).toString();
                subarea_two_code=subareatwo_code_list.get(position).toString();
                subarea_two_name=subareatwo_name_list.get(position).toString();
//                Toast.makeText(getApplicationContext(),""+subdivision_code,Toast.LENGTH_LONG).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });



        new Tkc_Value(Material_TransferActivity.this).execute();
        spinner_tkc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                tkc_name = tkc_name_list.get(position).toString();
                tkc_id = tkc_id_list.get(position).toString();

                //DataHolder_SiteInspection.getInstance().setStr_tkc(tkc_id);
//                  Toast.makeText(getApplicationContext(),""+position,Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });



        camera_btn = (Button) findViewById(R.id.btn_camera);
        camera_btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub

                //DataHolder_FactoryInspection.getInstance().setStr_lotStatus(inspection_id);
                str_qty_transfer= ed_qty_transfer.getText().toString().trim();

                //str_vendor= ed_vendor.getText().toString().trim();
                str_grn_transfer_note= ed_grn_transfer_note.getText().toString().trim();



               if(spinner_project.getSelectedItemPosition() == 0){
                    Toast.makeText(getApplicationContext(), "Select City Name* ", Toast.LENGTH_SHORT).show();

                }else if (radio_consumer_type.getCheckedRadioButtonId() == -1)
                {
                    Toast.makeText(getApplicationContext(),"Select Vendor/City Store",Toast.LENGTH_SHORT).show();
                    // hurray at-least on radio button is checked.
                }else  if(spinner_tkc.getSelectedItemPosition() == 0){
                    Toast.makeText(getApplicationContext(), "Select Item name", Toast.LENGTH_SHORT).show();

                }else if(TextUtils.isEmpty(str_qty_transfer)){
                    Toast.makeText(getApplicationContext(), "Enter Transfer Qunatity* ", Toast.LENGTH_SHORT).show();

                }else if(TextUtils.isEmpty(str_grn_transfer_note)){
                Toast.makeText(getApplicationContext(), "Enter GRN/Transfer Note No.* ", Toast.LENGTH_SHORT).show();

            } else {

                    DataHolder_ReceivingInspection.getInstance().setCity_id(project_code);
                    DataHolder_ReceivingInspection.getInstance().setReceiving_from(receiving_from);
                    DataHolder_ReceivingInspection.getInstance().setMzone_id(geographic_id);
                    DataHolder_ReceivingInspection.getInstance().setMcity_id(subarea_one_code);
                    DataHolder_ReceivingInspection.getInstance().setStore_id(subarea_two_code);
                    DataHolder_ReceivingInspection.getInstance().setItem_id(tkc_id);
                    DataHolder_ReceivingInspection.getInstance().setQty_transfer(str_qty_transfer);
                    DataHolder_ReceivingInspection.getInstance().setGrn_transfer_no(str_grn_transfer_note);

                    ShowAlertagain();

                }

            }
        });


        // for Factory Observation/Remark  Activity

        observation_btn = (Button) findViewById(R.id.btn_observation);
        observation_btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub

                if(TextUtils.isEmpty(DataHolder_ReceivingInspection.getInstance().getImageNmae1()))
                {
                    //Toast.makeText(SiteInspection_TKC_Activity.this, "Please finished Camera functionality First", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Material_TransferActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Please finished Camera functionality First");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();

                        }
                    });

                    dialog.show();
                }

                else{
                    //Toast.makeText(Home_Activity.this, "Invalid permit id", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Material_TransferActivity.this, Material_IssuedRemark.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);
                }

              /*  Intent i = new Intent(OpenPurchaseInspection_Item_Activity.this, OpenPurchase_Remark_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/

            }
        });

        finish_btn = (Button) findViewById(R.id.btn_finish);
        finish_btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(TextUtils.isEmpty(DataHolder_ReceivingInspection.getInstance().getImageNmae1()))
                {
                    //Toast.makeText(SiteInspection_TKC_Activity.this, "Please finished Camera functionality First", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Material_TransferActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Scan Doc. First");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();

                        }
                    });

                    dialog.show();
                }

                else{
                    //Toast.makeText(Home_Activity.this, "Invalid permit id", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Material_TransferActivity.this, Material_Transfer_Upload_Activity.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);
                }
               /* Intent i = new Intent(Material_TransferActivity.this, Material_Transfer_Upload_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/

            }
        });

        next_btn = (Button) findViewById(R.id.btn_next);
        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(TextUtils.isEmpty(DataHolder_ReceivingInspection.getInstance().getImageNmae1())) {


                    final Dialog dialog = new Dialog(Material_TransferActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Scan Doc. First ");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            //new SendToServer().execute();

                        }
                    });

                    dialog.show();
                } else{

                    if (connectionDetector.isConnectingToInternet()) {
                        //Log.e("Latitude", "" + mLocation.getLatitude());
                        //Log.e("Longitude", "" + mLocation.getLongitude());
                        final Dialog dialog = new Dialog(Material_TransferActivity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText(" Are you Sure to Upload Data ");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                                new SendToServer().execute();

                            }
                        });

                        dialog.show();

                        //new SendToServer().execute();

                    } else {

                        // Toast.makeText(getApplicationContext(), "record saved", Toast.LENGTH_SHORT).show();
                        // custom dialog
                        final Dialog dialog = new Dialog(Material_TransferActivity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("Internet not connecting");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();


                            }
                        });

                        dialog.show();

                        sqLiteAdapterprogress.openToRead();
                        sqLiteAdapterprogress.openToWrite();
                        sqLiteAdapterprogress.insert_value(sessionManager.GET_EMP_ID(),
                                sessionManager.GET_PROJECT(),
                                DataHolder_ReceivingInspection.getInstance().getCity_id(),
                                DataHolder_ReceivingInspection.getInstance().getReceiving_from(),
                                DataHolder_ReceivingInspection.getInstance().getVendor_id(),
                                DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                                DataHolder_ReceivingInspection.getInstance().getMcity_id(),
                                DataHolder_ReceivingInspection.getInstance().getStore_id(),
                                DataHolder_ReceivingInspection.getInstance().getItem_id(),
                                DataHolder_ReceivingInspection.getInstance().getQty_transfer(),
                                DataHolder_ReceivingInspection.getInstance().getGrn_transfer_no(),
                                DataHolder_ReceivingInspection.getInstance().getStr_remark(),
                                DataHolder_ReceivingInspection.getInstance().getCamera_lat(),
                                DataHolder_ReceivingInspection.getInstance().getCamera_long(),
                                DataHolder_ReceivingInspection.getInstance().getCamera_time(),
                                DataHolder_ReceivingInspection.getInstance().getImageNmae1(),
                                DataHolder_ReceivingInspection.getInstance().getImageNmae2(),
                                DataHolder_ReceivingInspection.getInstance().getImageNmae3(),
                                DataHolder_ReceivingInspection.getInstance().getImageNmae4(),
                                DataHolder_ReceivingInspection.getInstance().getImageNmae5(),
                                DataHolder_ReceivingInspection.getInstance().getImg1(),
                                DataHolder_ReceivingInspection.getInstance().getImg2(),
                                DataHolder_ReceivingInspection.getInstance().getImg3(),
                                DataHolder_ReceivingInspection.getInstance().getImg4(),
                                DataHolder_ReceivingInspection.getInstance().getImg5());
                        sqLiteAdapterprogress.close();
                        //Toast.makeText(getApplicationContext(), "record saved", Toast.LENGTH_SHORT).show();
                          /*  Toast toast = Toast.makeText(getApplicationContext(),"record saved",Toast.LENGTH_SHORT);
                            View toastView = toast.getView();
                            TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
                            toastMessage.setTextSize(18);
                            toastMessage.setTextColor(Color.BLACK);
                            //toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
                            toastMessage.setGravity(Gravity.CENTER);
                            toastMessage.setCompoundDrawablePadding(16);
                            toastView.setBackgroundColor(getResources().getColor(R.color.colorBg));
                            toast.show();*/
                        response = null;

                    }

                }

            }
        });



    }



    //...........Project Class...........................................//
    public class Project_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        Project_Value(Context ctx) { _context=ctx;}

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(Material_TransferActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(Material_TransferActivity.this);
            try {
                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
               // project_cursor=sqLiteAdapter.select_project_all();
                project_cursor=sqLiteAdapter.select_subarea_one_all_allocated();
                if(project_cursor!=null && project_cursor.moveToFirst()){
                    project_code_list.add("Select City Name");
                    project_name_list.add("Select City Name");
                    project_id_list.add("Select City Name");
                    do {
                        String project_id=project_cursor.getString(1);
                        String project_code=project_cursor.getString(2);
                        String project_name=project_cursor.getString(3);
                       /* Log.e("dist_code",dist_code);
                        Log.e("dist_name",dist_name);*/
                        project_id_list.add(project_id);
                        project_code_list.add(project_code);
                        project_name_list.add(project_name);
                    } while (project_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
               /* project_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,project_name_list);
                project_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                project_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,project_name_list);
                spinner_project.setAdapter(project_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }


    //.....................Geographic Area.................................................//

    public class Geographic_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;Context _context;
        Geographic_Value(Context ctx) {_context=ctx;}
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Material_TransferActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                if(geographic_cursor!=null){
                    geographic_cursor=null;
                }

                geographic_cursor=sqLiteAdapter.select_geographic_all();

                geographic_project_code_list.add("select");
                geographic_code_list.clear();
                geographic_name_list.clear();
                if(geographic_cursor!=null && geographic_cursor.moveToFirst()){
                    geographic_project_code_list.add("Select "+ DataHolder_SiteInspection.getInstance().getStr_level1());
                    geographic_code_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level1());
                    geographic_name_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level1());

                    do {
                       /* String geographic_code=geographic_cursor.getString(2);
                        String geographic_name=geographic_cursor.getString(3);*/
                        String geographic_project_code=geographic_cursor.getString(1);
                        String geographic_code=geographic_cursor.getString(2);
                        String geographic_name=geographic_cursor.getString(3);
                       /* Log.e("code",code);
                        Log.e("name",name);*/
                        geographic_project_code_list.add(geographic_project_code);
                        geographic_code_list.add(geographic_code);
                        geographic_name_list.add(geographic_name);
                    } while (geographic_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
                // Log.e("exception",e.getMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
                //spinner_geographic.setVisibility(View.VISIBLE);
                spinner_geographic.setVisibility(View.GONE);
                citystore_hold.setVisibility(View.VISIBLE);
               /* geographic_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,geographic_name_list);
                geographic_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                geographic_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,geographic_name_list);

                spinner_geographic.setAdapter(geographic_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }



    //..................... SubAreaOne_Value .................................................//

    public class SubAreaOne_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;Context _context;
        SubAreaOne_Value(Context ctx) {_context=ctx;}
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Material_TransferActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {

                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                if(subareaone_cursor!=null){
                    subareaone_cursor=null;
                }

                subareaone_cursor = sqLiteAdapter.select_msubarea_one_all(Integer.parseInt(geographic_id));
                //subareaone_cursor = sqLiteAdapter.select_subarea_one_all(Integer.parseInt(geographic_id));
                subareaone_code_list.clear();
                subareaone_name_list.clear();
                if(subareaone_cursor!=null && subareaone_cursor.moveToFirst()){
                    subareaone_geographic_code_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level2());
                    subareaone_code_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level2());
                    subareaone_name_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level2());


                    do {
                        String subareaone_geographic_code=subareaone_cursor.getString(1);
                        String subarea_one_code=subareaone_cursor.getString(2);
                        String subarea_one_name=subareaone_cursor.getString(3);
                       /* String store_id=subareaone_cursor.getString(4);
                        String store_name=subareaone_cursor.getString(5);*/
                       /* Log.e("store_id",store_id);
                        Log.e("store_name",store_name);*/

                        subareaone_geographic_code_list.add(subareaone_geographic_code);
                        subareaone_code_list.add(subarea_one_code);
                        subareaone_name_list.add(subarea_one_name);




                    } while (subareaone_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
                // Log.e("exception",e.getMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {

                //spinner_subarea_one.setVisibility(View.VISIBLE);
                spinner_subarea_one.setVisibility(View.GONE);
                /* subareaone_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,subareaone_name_list);
                subareaone_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                subareaone_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,subareaone_name_list);
                spinner_subarea_one.setAdapter(subareaone_adapter);

                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }


    public class Tkc_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        Tkc_Value(Context ctx) { _context=ctx;}

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(Material_TransferActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(Material_TransferActivity.this);
            try {
                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                //DataHolder_SiteInspection.getInstance().getStr_tkc();
                tkc_cursor=sqLiteAdapter.select_item_all();
                if(tkc_cursor!=null && tkc_cursor.moveToFirst()){
                    tkc_id_list.add("Select Iterm Name");
                    tkc_name_list.add("Select Item Name");

                    do {
                        String tkc_id=tkc_cursor.getString(1);
                        String tkc_name=tkc_cursor.getString(2);
                        tkc_id_list.add(tkc_id);
                        tkc_name_list.add(tkc_name);

                    } while (tkc_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
       /* protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
               *//* project_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,project_name_list);
                project_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*//*
                tkc_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,tkc_name_list);
                spinner_tkc.setAdapter(tkc_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }*/

        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {

                tkc_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,tkc_name_list);
                spinner_tkc.setAdapter(tkc_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }

    //-----------------Store name-----------------------//

    public class SubAreaTwo_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;Context _context;
        SubAreaTwo_Value(Context ctx) {_context=ctx;}
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Material_TransferActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {

                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                if(subareatwo_cursor!=null){
                    subareatwo_cursor=null;
                }

                subareatwo_cursor = sqLiteAdapter.select_msubarea_one_all_store(Integer.parseInt(subarea_one_code));
                //subareatwo_cursor = sqLiteAdapter.select_subarea_two_all(57);
                subareatwo_code_list.clear();
                subareatwo_name_list.clear();
                if(subareatwo_cursor!=null && subareatwo_cursor.moveToFirst()){
                   /* subareatwo_one_code_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level3());
                    subareatwo_code_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level3());
                    subareatwo_name_list.add("Select "+DataHolder_SiteInspection.getInstance().getStr_level3());*/

                    do {
                        String subareatwo_one_code=subareatwo_cursor.getString(3);
                        String subarea_two_code=subareatwo_cursor.getString(4);
                        String subarea_two_name=subareatwo_cursor.getString(5);
                       /* Log.e("code",code);
                        Log.e("name",name);*/

                        subareatwo_one_code_list.add(subareatwo_one_code);
                        subareatwo_code_list.add(subarea_two_code);
                        subareatwo_name_list.add(subarea_two_name);

                    } while (subareatwo_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
                // Log.e("exception",e.getMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
                spinner_subarea_two.setVisibility(View.VISIBLE);
                /*subareatwo_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,subareatwo_name_list);
                subareatwo_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                subareatwo_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,subareatwo_name_list);
                spinner_subarea_two.setAdapter(subareatwo_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }


    public boolean isLocationServiceEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = lm.getBestProvider(new Criteria(), true).trim();
        //  Log.e("provider" ,""+provider);
        //  Log.e("LocationManager" ,""+lm);
        return (provider != null &&
                !LocationManager.PASSIVE_PROVIDER.equals(provider));
    }
    public void ShowAlertagain() {
        if (!isLocationServiceEnabled()) {
            // Toast.makeText(getApplicationContext(), "please wait while location is fetching", Toast.LENGTH_SHORT).show();

            runOnUiThread(new Runnable() {
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Material_TransferActivity.this);
                    builder.setMessage("Do you want to Continue without location?");
                    builder.setCancelable(true);
//                    builder.setPositiveButton("OK",
//                            new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    latt = 0;
//                                    longg = 0;
//                                    if (connectionDetector.isConnectingToInternet()) {
////                                        new SendToServer(latt, longg).execute();
//                                    } else {
//
//                                    }
//                                    dialog.cancel();
//                                }
//                            });
                    builder.setNegativeButton("SETTINGS",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    startActivity(intent);
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
        } else {
            //Intent i = new Intent(OpenPurchaseInspection_Item_Activity.this, AndroidCameraExample.class);
            Intent i = new Intent(Material_TransferActivity.this, Receiving_Camera_Activity.class);
            startActivity(i);
            overridePendingTransition(R.anim.right_in, R.anim.left_out);
            //   Log.e("Latitude", "" + mLocation.getLatitude());
            //   Log.e("Longitude", "" + mLocation.getLongitude());
        }
    }


    //---------- for sending punch in data to the server------------------//

    public class SendToServer extends AsyncTask<String, String, String>
    {

        ProgressDialog pd;
        // public SendToServer() {
        public SendToServer() {
            // TODO Auto-generated constructor stub

//            Log.e("from", "sendtoserver");
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Material_TransferActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_material_transfer_data");
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    nameValuePairs.add(new BasicNameValuePair("permit_id", sessionManager.GET_EMP_ID()));
                    nameValuePairs.add(new BasicNameValuePair("project", sessionManager.GET_PROJECT()));
                    nameValuePairs.add(new BasicNameValuePair("city_id", project_id));
                    nameValuePairs.add(new BasicNameValuePair("receiving_from_id", receiving_from));
                    nameValuePairs.add(new BasicNameValuePair("mzone_id", geographic_id));
                    nameValuePairs.add(new BasicNameValuePair("mcity_id", subarea_one_code));
                    nameValuePairs.add(new BasicNameValuePair("store_id", subarea_two_code));
                    nameValuePairs.add(new BasicNameValuePair("item", tkc_id));
                    nameValuePairs.add(new BasicNameValuePair("qty_transfer", str_qty_transfer));
                    nameValuePairs.add(new BasicNameValuePair("grn_transfer", str_grn_transfer_note));
                    nameValuePairs.add(new BasicNameValuePair("remark", DataHolder_ReceivingInspection.getInstance().getStr_remark()));
                    nameValuePairs.add(new BasicNameValuePair("latt", DataHolder_ReceivingInspection.getInstance().getCamera_lat()));
                    nameValuePairs.add(new BasicNameValuePair("longg", DataHolder_ReceivingInspection.getInstance().getCamera_long()));
                    nameValuePairs.add(new BasicNameValuePair("mobile_time", DataHolder_ReceivingInspection.getInstance().getCamera_time()));
                    nameValuePairs.add(new BasicNameValuePair("imagename1", DataHolder_ReceivingInspection.getInstance().getImageNmae1()));
                    nameValuePairs.add(new BasicNameValuePair("imagename2", DataHolder_ReceivingInspection.getInstance().getImageNmae2()));
                    nameValuePairs.add(new BasicNameValuePair("imagename3", DataHolder_ReceivingInspection.getInstance().getImageNmae3()));
                    nameValuePairs.add(new BasicNameValuePair("imagename4", DataHolder_ReceivingInspection.getInstance().getImageNmae4()));
                    nameValuePairs.add(new BasicNameValuePair("imagename5", DataHolder_ReceivingInspection.getInstance().getImageNmae5()));
                    nameValuePairs.add(new BasicNameValuePair("image1", DataHolder_ReceivingInspection.getInstance().getImg1()));
                    nameValuePairs.add(new BasicNameValuePair("image2", DataHolder_ReceivingInspection.getInstance().getImg2()));
                    nameValuePairs.add(new BasicNameValuePair("image3", DataHolder_ReceivingInspection.getInstance().getImg3()));
                    nameValuePairs.add(new BasicNameValuePair("image4", DataHolder_ReceivingInspection.getInstance().getImg4()));
                    nameValuePairs.add(new BasicNameValuePair("image5", DataHolder_ReceivingInspection.getInstance().getImg5()));



                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    Log.e("name value pair", "" + nameValuePairs);
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpclient.execute(httppost, responseHandler);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("response", ""+response);
                    //   Log.e("response", response + "+" + e.getMessage().toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();

            try
            {
                response = response.trim();
                Log.e("response",""+response);
                response = response.trim();

                if (response != null && response.equals("1")) {

                    //Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();

                    // custom dialog
                    final Dialog dialog = new Dialog(Material_TransferActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
//                              dialog.setTitle("Title...");

                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Send Successfully");
//                              ImageView image = (ImageView) dialog.findViewById(R.id.image);
//                              image.setImageResource(R.drawable.ic_launcher);

                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            pd.hide();
                            pd.dismiss();
                            dialog.dismiss();
                            DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                            startActivity(new Intent(Material_TransferActivity.this, Material_TransferActivity.class));
                            finish();

                        }
                    });

                    dialog.show();


                } else {

                    sqLiteAdapterprogress.openToRead();
                    sqLiteAdapterprogress.openToWrite();
                    sqLiteAdapterprogress.insert_value(sessionManager.GET_EMP_ID(),
                            sessionManager.GET_PROJECT(),
                            DataHolder_ReceivingInspection.getInstance().getCity_id(),
                            DataHolder_ReceivingInspection.getInstance().getReceiving_from(),
                            DataHolder_ReceivingInspection.getInstance().getVendor_id(),
                            DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                            DataHolder_ReceivingInspection.getInstance().getMcity_id(),
                            DataHolder_ReceivingInspection.getInstance().getStore_id(),
                            DataHolder_ReceivingInspection.getInstance().getItem_id(),
                            DataHolder_ReceivingInspection.getInstance().getQty_transfer(),
                            DataHolder_ReceivingInspection.getInstance().getGrn_transfer_no(),
                            DataHolder_ReceivingInspection.getInstance().getStr_remark(),
                            DataHolder_ReceivingInspection.getInstance().getCamera_lat(),
                            DataHolder_ReceivingInspection.getInstance().getCamera_long(),
                            DataHolder_ReceivingInspection.getInstance().getCamera_time(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae1(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae2(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae3(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae4(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae5(),
                            DataHolder_ReceivingInspection.getInstance().getImg1(),
                            DataHolder_ReceivingInspection.getInstance().getImg2(),
                            DataHolder_ReceivingInspection.getInstance().getImg3(),
                            DataHolder_ReceivingInspection.getInstance().getImg4(),
                            DataHolder_ReceivingInspection.getInstance().getImg5());
                    sqLiteAdapterprogress.close();
                    DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                    startActivity(new Intent(Material_TransferActivity.this, Material_TransferActivity.class));
                    finish();

                    //Toast.makeText(getApplicationContext(), "record saved due to server error", Toast.LENGTH_SHORT).show();

                }
            } catch (Exception e) {
                //Toast.makeText(getApplicationContext(), "Due to low internet connectivity this data would be saved in database", Toast.LENGTH_SHORT).show();

                sqLiteAdapterprogress.openToRead();
                sqLiteAdapterprogress.openToWrite();
                sqLiteAdapterprogress.insert_value(sessionManager.GET_EMP_ID(),
                        sessionManager.GET_PROJECT(),
                        DataHolder_ReceivingInspection.getInstance().getCity_id(),
                        DataHolder_ReceivingInspection.getInstance().getReceiving_from(),
                        DataHolder_ReceivingInspection.getInstance().getVendor_id(),
                        DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                        DataHolder_ReceivingInspection.getInstance().getMcity_id(),
                        DataHolder_ReceivingInspection.getInstance().getStore_id(),
                        DataHolder_ReceivingInspection.getInstance().getItem_id(),
                        DataHolder_ReceivingInspection.getInstance().getQty_transfer(),
                        DataHolder_ReceivingInspection.getInstance().getGrn_transfer_no(),
                        DataHolder_ReceivingInspection.getInstance().getStr_remark(),
                        DataHolder_ReceivingInspection.getInstance().getCamera_lat(),
                        DataHolder_ReceivingInspection.getInstance().getCamera_long(),
                        DataHolder_ReceivingInspection.getInstance().getCamera_time(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae1(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae2(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae3(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae4(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae5(),
                        DataHolder_ReceivingInspection.getInstance().getImg1(),
                        DataHolder_ReceivingInspection.getInstance().getImg2(),
                        DataHolder_ReceivingInspection.getInstance().getImg3(),
                        DataHolder_ReceivingInspection.getInstance().getImg4(),
                        DataHolder_ReceivingInspection.getInstance().getImg5());
                sqLiteAdapterprogress.close();
                DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                startActivity(new Intent(Material_TransferActivity.this, Material_TransferActivity.class));
                finish();

                response = null;


                Log.e("response exception", ""+e.getMessage());
            }
            response = null;
        }

    }



}
