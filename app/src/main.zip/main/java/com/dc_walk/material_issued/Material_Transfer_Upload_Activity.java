package com.dc_walk.material_issued;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dc_walk.Home_Activity;
import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.data_holder.DataHolder_ReceivingInspection;
import com.dc_walk.sqlite_adapter.SQLiteAdapterMaterialIssued;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;

/**
 * Created by nitinb on 29-01-2016.
 */
public class Material_Transfer_Upload_Activity extends Activity {

    ImageButton upload_btn,pass_btn,rework_btn;
    Button back_btn;
    String response;
    ProgressDialog pd;
    Boolean passclicked=false;
    Boolean reworkclicked=false;
    SessionManager sessionManager;
    ConnectionDetector connectionDetector;
    String internet_interrupt=null;
    String permit_id;
    SQLiteAdapterMaterialIssued sqLiteAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.receiving_upload);

        connectionDetector=new ConnectionDetector(Material_Transfer_Upload_Activity.this);
        sessionManager =new SessionManager(Material_Transfer_Upload_Activity.this);
        sqLiteAdapter= new SQLiteAdapterMaterialIssued(Material_Transfer_Upload_Activity.this);

        back_btn=(Button)findViewById(R.id.back_btn);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Intent i = new Intent(Receiving_Upload_Activity.this, Receiving_Item_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });


        upload_btn=(ImageButton)findViewById(R.id.upload_btn);
        upload_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (connectionDetector.isConnectingToInternet()) {
                    //Log.e("Latitude", "" + mLocation.getLatitude());
                    //Log.e("Longitude", "" + mLocation.getLongitude());
                    new SendToServer().execute();
                    //new SendToServer().execute();

                } else {

                    // Toast.makeText(getApplicationContext(), "record saved", Toast.LENGTH_SHORT).show();
                    // custom dialog
                    final Dialog dialog = new Dialog(Material_Transfer_Upload_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Internet not connecting");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            startActivity(new Intent(Material_Transfer_Upload_Activity.this, Home_Activity.class));
                            finish();
                            overridePendingTransition(R.anim.right_in, R.anim.left_out);


                        }
                    });

                    dialog.show();

                      sqLiteAdapter.openToRead();
                      sqLiteAdapter.openToWrite();
                      sqLiteAdapter.insert_value(sessionManager.GET_EMP_ID(),
                              sessionManager.GET_PROJECT(),
                              DataHolder_ReceivingInspection.getInstance().getCity_id(),
                              DataHolder_ReceivingInspection.getInstance().getReceiving_from(),
                              DataHolder_ReceivingInspection.getInstance().getVendor_id(),
                              DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                              DataHolder_ReceivingInspection.getInstance().getMcity_id(),
                              DataHolder_ReceivingInspection.getInstance().getStore_id(),
                              DataHolder_ReceivingInspection.getInstance().getItem_id(),
                              DataHolder_ReceivingInspection.getInstance().getQty_transfer(),
                              DataHolder_ReceivingInspection.getInstance().getGrn_transfer_no(),
                              DataHolder_ReceivingInspection.getInstance().getStr_remark(),
                              DataHolder_ReceivingInspection.getInstance().getCamera_lat(),
                              DataHolder_ReceivingInspection.getInstance().getCamera_long(),
                              DataHolder_ReceivingInspection.getInstance().getCamera_time(),
                              DataHolder_ReceivingInspection.getInstance().getImageNmae1(),
                              DataHolder_ReceivingInspection.getInstance().getImageNmae2(),
                              DataHolder_ReceivingInspection.getInstance().getImageNmae3(),
                              DataHolder_ReceivingInspection.getInstance().getImageNmae4(),
                              DataHolder_ReceivingInspection.getInstance().getImageNmae5(),
                              DataHolder_ReceivingInspection.getInstance().getImg1(),
                              DataHolder_ReceivingInspection.getInstance().getImg2(),
                              DataHolder_ReceivingInspection.getInstance().getImg3(),
                              DataHolder_ReceivingInspection.getInstance().getImg4(),
                              DataHolder_ReceivingInspection.getInstance().getImg5());
                       sqLiteAdapter.close();
                      //Toast.makeText(getApplicationContext(), "record saved", Toast.LENGTH_SHORT).show();

                    response = null;
                    DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                    startActivity(new Intent(Material_Transfer_Upload_Activity.this, Home_Activity.class));
                    finish();

                }
                    }
                });


    }


    //---------- for sending punch in data to the server------------------//

    public class SendToServer extends AsyncTask<String, String, String>
    {

        ProgressDialog pd;
        // public SendToServer() {
        public SendToServer() {
            // TODO Auto-generated constructor stub

//            Log.e("from", "sendtoserver");
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Material_Transfer_Upload_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_material_transfer_data");
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    // httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    nameValuePairs.add(new BasicNameValuePair("permit_id", sessionManager.GET_EMP_ID()));
                    nameValuePairs.add(new BasicNameValuePair("project", sessionManager.GET_PROJECT()));
                    nameValuePairs.add(new BasicNameValuePair("city_id",  DataHolder_ReceivingInspection.getInstance().getCity_id()));
                    nameValuePairs.add(new BasicNameValuePair("receiving_from_id",  DataHolder_ReceivingInspection.getInstance().getReceiving_from()));
                    nameValuePairs.add(new BasicNameValuePair("mzone_id",  DataHolder_ReceivingInspection.getInstance().getMzone_id()));
                    nameValuePairs.add(new BasicNameValuePair("mcity_id",  DataHolder_ReceivingInspection.getInstance().getMcity_id()));
                    nameValuePairs.add(new BasicNameValuePair("store_id",  DataHolder_ReceivingInspection.getInstance().getStore_id()));
                    nameValuePairs.add(new BasicNameValuePair("item",  DataHolder_ReceivingInspection.getInstance().getItem_id()));
                    nameValuePairs.add(new BasicNameValuePair("qty_transfer",  DataHolder_ReceivingInspection.getInstance().getQty_transfer()));
                    nameValuePairs.add(new BasicNameValuePair("grn_transfer",  DataHolder_ReceivingInspection.getInstance().getGrn_transfer_no()));
                    nameValuePairs.add(new BasicNameValuePair("remark", DataHolder_ReceivingInspection.getInstance().getStr_remark()));
                    nameValuePairs.add(new BasicNameValuePair("latt", DataHolder_ReceivingInspection.getInstance().getCamera_lat()));
                    nameValuePairs.add(new BasicNameValuePair("longg", DataHolder_ReceivingInspection.getInstance().getCamera_long()));
                    nameValuePairs.add(new BasicNameValuePair("mobile_time", DataHolder_ReceivingInspection.getInstance().getCamera_time()));
                    nameValuePairs.add(new BasicNameValuePair("imagename1", DataHolder_ReceivingInspection.getInstance().getImageNmae1()));
                    nameValuePairs.add(new BasicNameValuePair("imagename2", DataHolder_ReceivingInspection.getInstance().getImageNmae2()));
                    nameValuePairs.add(new BasicNameValuePair("imagename3", DataHolder_ReceivingInspection.getInstance().getImageNmae3()));
                    nameValuePairs.add(new BasicNameValuePair("imagename4", DataHolder_ReceivingInspection.getInstance().getImageNmae4()));
                    nameValuePairs.add(new BasicNameValuePair("imagename5", DataHolder_ReceivingInspection.getInstance().getImageNmae5()));
                    nameValuePairs.add(new BasicNameValuePair("image1", DataHolder_ReceivingInspection.getInstance().getImg1()));
                    nameValuePairs.add(new BasicNameValuePair("image2", DataHolder_ReceivingInspection.getInstance().getImg2()));
                    nameValuePairs.add(new BasicNameValuePair("image3", DataHolder_ReceivingInspection.getInstance().getImg3()));
                    nameValuePairs.add(new BasicNameValuePair("image4", DataHolder_ReceivingInspection.getInstance().getImg4()));
                    nameValuePairs.add(new BasicNameValuePair("image5", DataHolder_ReceivingInspection.getInstance().getImg5()));


                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    Log.e("name value pair", "" + nameValuePairs);

                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpclient.execute(httppost, responseHandler);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("response", ""+response);
                    //   Log.e("response", response + "+" + e.getMessage().toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();

            try
            {
                response = response.trim();
                Log.e("response",""+response);
                response = response.trim();

                if (response != null && response.equals("1")) {


                    //Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();

                    final Dialog dialog = new Dialog(Material_Transfer_Upload_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
//                              dialog.setTitle("Title...");

                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Send Successfully");
                   Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            pd.hide();
                            pd.dismiss();
                            dialog.dismiss();
                            DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                            startActivity(new Intent(Material_Transfer_Upload_Activity.this, Home_Activity.class));
                            finish();

                        }
                    });

                    dialog.show();

                } else {

                   sqLiteAdapter.openToRead();
                    sqLiteAdapter.openToWrite();
                    sqLiteAdapter.insert_value(sessionManager.GET_EMP_ID(),
                            sessionManager.GET_PROJECT(),
                            DataHolder_ReceivingInspection.getInstance().getCity_id(),
                            DataHolder_ReceivingInspection.getInstance().getReceiving_from(),
                            DataHolder_ReceivingInspection.getInstance().getVendor_id(),
                            DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                            DataHolder_ReceivingInspection.getInstance().getMcity_id(),
                            DataHolder_ReceivingInspection.getInstance().getStore_id(),
                            DataHolder_ReceivingInspection.getInstance().getItem_id(),
                            DataHolder_ReceivingInspection.getInstance().getQty_transfer(),
                            DataHolder_ReceivingInspection.getInstance().getGrn_transfer_no(),
                            DataHolder_ReceivingInspection.getInstance().getStr_remark(),
                            DataHolder_ReceivingInspection.getInstance().getCamera_lat(),
                            DataHolder_ReceivingInspection.getInstance().getCamera_long(),
                            DataHolder_ReceivingInspection.getInstance().getCamera_time(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae1(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae2(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae3(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae4(),
                            DataHolder_ReceivingInspection.getInstance().getImageNmae5(),
                            DataHolder_ReceivingInspection.getInstance().getImg1(),
                            DataHolder_ReceivingInspection.getInstance().getImg2(),
                            DataHolder_ReceivingInspection.getInstance().getImg3(),
                            DataHolder_ReceivingInspection.getInstance().getImg4(),
                            DataHolder_ReceivingInspection.getInstance().getImg5());
                    sqLiteAdapter.close();
                    DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                    startActivity(new Intent(Material_Transfer_Upload_Activity.this, Home_Activity.class));
                    finish();

                    //Toast.makeText(getApplicationContext(), "record saved due to server error", Toast.LENGTH_SHORT).show();


                }
            } catch (Exception e) {
                //Toast.makeText(getApplicationContext(), "Due to low internet connectivity this data would be saved in database", Toast.LENGTH_SHORT).show();

                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                sqLiteAdapter.insert_value(sessionManager.GET_EMP_ID(),
                        sessionManager.GET_PROJECT(),
                        DataHolder_ReceivingInspection.getInstance().getCity_id(),
                        DataHolder_ReceivingInspection.getInstance().getReceiving_from(),
                        DataHolder_ReceivingInspection.getInstance().getVendor_id(),
                        DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                        DataHolder_ReceivingInspection.getInstance().getMcity_id(),
                        DataHolder_ReceivingInspection.getInstance().getStore_id(),
                        DataHolder_ReceivingInspection.getInstance().getItem_id(),
                        DataHolder_ReceivingInspection.getInstance().getQty_transfer(),
                        DataHolder_ReceivingInspection.getInstance().getGrn_transfer_no(),
                        DataHolder_ReceivingInspection.getInstance().getStr_remark(),
                        DataHolder_ReceivingInspection.getInstance().getCamera_lat(),
                        DataHolder_ReceivingInspection.getInstance().getCamera_long(),
                        DataHolder_ReceivingInspection.getInstance().getCamera_time(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae1(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae2(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae3(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae4(),
                        DataHolder_ReceivingInspection.getInstance().getImageNmae5(),
                        DataHolder_ReceivingInspection.getInstance().getImg1(),
                        DataHolder_ReceivingInspection.getInstance().getImg2(),
                        DataHolder_ReceivingInspection.getInstance().getImg3(),
                        DataHolder_ReceivingInspection.getInstance().getImg4(),
                        DataHolder_ReceivingInspection.getInstance().getImg5());
                sqLiteAdapter.close();
                DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                startActivity(new Intent(Material_Transfer_Upload_Activity.this, Home_Activity.class));
                finish();

                response = null;

                Log.e("response exception", ""+e.getMessage());
            }
            response = null;
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish(); // finish activity
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }

}
