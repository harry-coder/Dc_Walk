package com.dc_walk.material_issued;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dc_walk.R;
import com.dc_walk.data_holder.DataHolder_ReceivingInspection;

/**
 * Created by nitinb on 03-02-2016.
 */
public class Receiving_Remark_Activity extends Activity {

    ImageButton next_btn;
    Button back_btn,Button_down;
    EditText ed_remark;
    String str_remark;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.receiving_remark);
        ed_remark=(EditText)findViewById(R.id.editextid);


        // for back page activity
        back_btn=(Button)findViewById(R.id.backpageId2);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Intent i = new Intent(Receiving_Remark_Activity.this, Receiving_Item_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });

        next_btn=(ImageButton)findViewById(R.id.next_btn);
        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                str_remark = ed_remark.getText().toString().trim();

                if(TextUtils.isEmpty(str_remark)) {

                    //Toast.makeText(Site_Pole_Remark_Activity.this, "Enter all mandatory fields", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Receiving_Remark_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Enter Item Observation fields");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();

                        }
                    });

                    dialog.show();
                } else {


                    DataHolder_ReceivingInspection.getInstance().setStr_remark(str_remark);


                   /* Intent i = new Intent(Receiving_Remark_Activity.this, Receiving_Item_Activity.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
                    onBackPressed();
                }




             /*   Intent i = new Intent(Receiving_Remark_Activity.this, Receiving_Item_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
*/
             /*   Toast.makeText(getBaseContext(), "Your data has been send to the Server",
                        Toast.LENGTH_SHORT).show();*/
            }
        });

        Button_down = (Button) findViewById(R.id.met);
        ed_remark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button_down.setVisibility(View.VISIBLE);
            }

//
        });

        Button_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //when play is clicked show stop button and hide play button
                Button_down.setVisibility(View.GONE);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish(); // finish activity
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }

}
