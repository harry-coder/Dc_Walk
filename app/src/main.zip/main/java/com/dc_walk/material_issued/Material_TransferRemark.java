package com.dc_walk.material_issued;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dc_walk.R;
import com.dc_walk.data_holder.DataHolder_ReceivingInspection;

public class Material_TransferRemark extends Activity {

    EditText remark_et;
    String str_remark;
    Button back_btn,Button_down;
    ImageButton finish_btn ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materialissue_remark);
        remark_et=(EditText)findViewById(R.id.editextid);

        back_btn = (Button) findViewById(R.id.backpageId2);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Intent i = new Intent(Workprogress_Remark.this, WorkprogressActivity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });
        finish_btn= (ImageButton) findViewById(R.id.next_btn);


        finish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                str_remark = remark_et.getText().toString().trim();

                if(TextUtils.isEmpty(str_remark)) {

                    //Toast.makeText(Site_Pole_Remark_Activity.this, "Enter all mandatory fields", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Material_TransferRemark.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Enter Item Observation fields");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();

                        }
                    });

                    dialog.show();

                } else {


                    DataHolder_ReceivingInspection.getInstance().setStr_remark(str_remark);


                   /* Intent i = new Intent(Workprogress_Remark.this, WorkprogressActivity.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
                    onBackPressed();

                }
              /*  Intent i = new Intent(Workprogress_Remark.this, WorkprogressActivity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });


        Button_down = (Button) findViewById(R.id.met);
        remark_et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button_down.setVisibility(View.VISIBLE);
            }

//
        });

        Button_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //when play is clicked show stop button and hide play button
                Button_down.setVisibility(View.GONE);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

            }
        });
    }



    @Override
    public void onBackPressed() {

        finish(); // finish activity
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }

}
