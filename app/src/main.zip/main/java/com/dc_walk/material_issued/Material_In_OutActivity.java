package com.dc_walk.material_issued;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import com.dc_walk.R;

public class Material_In_OutActivity extends Activity {
    boolean check=true;

    Button btn_mat_issue,btn_mat_receive;
    //Spinner spinner_item1, spinner_item2, spinner_item3, spinner_item4, spinner_item5;
    Spinner spinner_geographic, spinner_subarea_one, spinner_subarea_two, spinner_subarea_three,spinner_item,spinner_subitem,spinner_mlocation,spinner_mtkc,spinner_project;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material_in_out);

        btn_mat_receive = (Button) findViewById(R.id.btn_mat_receive);
        btn_mat_issue = (Button) findViewById(R.id.btn_mat_issue);
        btn_mat_issue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Material_In_OutActivity.this, Material_TransferActivity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
            }
        });
        btn_mat_receive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Material_In_OutActivity.this, Material_receivedActivity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
            }
        });
//        btn_mat_receive.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(Material_In_OutActivity.this, Material_ReceiveActivity.class);
//                startActivity(i);
//                overridePendingTransition(R.anim.right_in, R.anim.left_out);
//            }
//        });

    }




}
