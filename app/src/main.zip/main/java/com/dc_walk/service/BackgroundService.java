package com.dc_walk.service;

/**
 * Created by soubhagyarm on 21-08-2016.
 */

import android.app.IntentService;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;
import com.dc_walk.sqlite_adapter.SQLiteAdapterIssue;
import com.dc_walk.sqlite_adapter.SQLiteAdapterMaterialIssued;
import com.dc_walk.sqlite_adapter.SQLiteAdapterReceiving;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * @author Maurya Talisetti
 */
public class BackgroundService extends IntentService {

    public Runnable mRunnable = null;
    private NotificationManager nm;
    ConnectionDetector connectionDetector;
    private final Calendar time = Calendar.getInstance();
    SQLiteAdapterReceiving sqLiteAdapter;
    SQLiteAdapterMaterialIssued sqLiteAdapter_m;
    SQLiteAdapter1 sqLiteInspection;
    SQLiteAdapterIssue sqLiteissue;
    Context context;

    private String REsponse;
    int id;
    public int globalcount = 20;
    Cursor cursor_all_site, cursor_all_Mile,cursor_all_Insp,cursor_all_issue;

    public BackgroundService() {
        super("");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        // TODO Auto-generated method stub
       /*final Handler mHandler = new Handler();
       mRunnable = new Runnable() {
           @Override
           public void run() {

               System.out.println("HYYHHYYH");
               Toast.makeText(getApplicationContext(), " GOT IT ", Toast.LENGTH_SHORT).show();

               senddata();
               mHandler.postDelayed(mRunnable, 50 * 50 * 1000);
           }
       };

       mHandler.postDelayed(mRunnable, 50 * 50 * 1000);*/

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {


                while (true) {
                    //startJob();
                    try {
                        //Thread.sleep(0);
                        Thread.sleep(1 * 10 * 1000);
                        if (connectionDetector.isConnectingToInternet()) {
                            try {
                                sqLiteAdapter.openToWrite();
                                sqLiteAdapter.openToRead();
                                cursor_all_site = sqLiteAdapter.queueAll();
                                cursorS(cursor_all_site);

                                sqLiteAdapter_m.openToWrite();
                                sqLiteAdapter_m.openToRead();
                                cursor_all_Mile = sqLiteAdapter_m.queueAll();
                                cursorM(cursor_all_Mile);


                                sqLiteInspection.openToWrite();
                                sqLiteInspection.openToRead();
                                cursor_all_Insp = sqLiteInspection.queueAll();
                                cursorI(cursor_all_Insp);

                                sqLiteissue.openToWrite();
                                sqLiteissue.openToRead();
                                cursor_all_issue = sqLiteissue.queueAll();
                                cursorIssue(cursor_all_issue);

                            } catch (Exception e) {
                                // TODO: handle exception
                            }


                        }

                    } catch (InterruptedException e) {

                        e.printStackTrace();
                    }
                }

            }
        });
        t.start();
        //return START_STICKY;

        //senddata();

    }

    @Override
    public void onCreate() {
        super.onCreate();

        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        connectionDetector = new ConnectionDetector(BackgroundService.this);
        sqLiteAdapter = new SQLiteAdapterReceiving(BackgroundService.this);
        sqLiteAdapter_m = new SQLiteAdapterMaterialIssued(BackgroundService.this);
        Toast.makeText(this, "Service created at " + time.getTime(),
                Toast.LENGTH_LONG).show();
        // showNotification();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Cancel the persistent notification.
        // nm.cancel(R.string.service_started);
        Toast.makeText(this,
                REsponse + " Service destroyed at " + time.getTime() + ";",
                Toast.LENGTH_LONG).show();
       /* sqLiteAdapter.openToWrite();
        sqLiteAdapter.openToRead();
        sqLiteAdapter.delete_value_All();*/
    }

    public void senddata() {
        // TODO Auto-generated method stub
        if (connectionDetector.isConnectingToInternet()) {
            try {
                sqLiteAdapter.openToWrite();
                sqLiteAdapter.openToRead();
                cursor_all_site = sqLiteAdapter.queueAll();
                cursorS(cursor_all_site);

                sqLiteAdapter_m.openToWrite();
                sqLiteAdapter_m.openToRead();
                cursor_all_Mile = sqLiteAdapter_m.queueAll();
                cursorM(cursor_all_Mile);

            } catch (Exception e) {
                // TODO: handle exception
            }


        } else {

        }
    }

    public void cursorS(Cursor cursorSend) {
        if (cursorSend != null && cursorSend.moveToFirst()) {
            int counter = 0;
            do {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("permit_id", cursorSend.getString(1)));
                nameValuePairs.add(new BasicNameValuePair("project",cursorSend.getString(2)));
                nameValuePairs.add(new BasicNameValuePair("city_id", cursorSend.getString(3)));
                nameValuePairs.add(new BasicNameValuePair("receiving_from_id", cursorSend.getString(4)));
                nameValuePairs.add(new BasicNameValuePair("vendor", cursorSend.getString(5)));
                nameValuePairs.add(new BasicNameValuePair("mzone_id", cursorSend.getString(6)));
                nameValuePairs.add(new BasicNameValuePair("mcity_id", cursorSend.getString(7)));
                nameValuePairs.add(new BasicNameValuePair("store_id", cursorSend.getString(8)));
                nameValuePairs.add(new BasicNameValuePair("item", cursorSend.getString(9)));
                nameValuePairs.add(new BasicNameValuePair("qty_doc", cursorSend.getString(10)));
                nameValuePairs.add(new BasicNameValuePair("qty_rec", cursorSend.getString(11)));
                nameValuePairs.add(new BasicNameValuePair("qty_damaged", cursorSend.getString(12)));
                nameValuePairs.add(new BasicNameValuePair("qty_accepted", cursorSend.getString(13)));
                nameValuePairs.add(new BasicNameValuePair("grn_transfer", cursorSend.getString(14)));
                nameValuePairs.add(new BasicNameValuePair("remark", cursorSend.getString(15)));
                nameValuePairs.add(new BasicNameValuePair("latt",cursorSend.getString(16)));
                nameValuePairs.add(new BasicNameValuePair("longg",cursorSend.getString(17) ));
                nameValuePairs.add(new BasicNameValuePair("mobile_time",cursorSend.getString(18)));
                nameValuePairs.add(new BasicNameValuePair("imagename1",cursorSend.getString(19)));
                nameValuePairs.add(new BasicNameValuePair("imagename2",cursorSend.getString(20)));
                nameValuePairs.add(new BasicNameValuePair("imagename3",cursorSend.getString(21)));
                nameValuePairs.add(new BasicNameValuePair("imagename4",cursorSend.getString(22) ));
                nameValuePairs.add(new BasicNameValuePair("imagename5",cursorSend.getString(23) ));
                nameValuePairs.add(new BasicNameValuePair("image1",cursorSend.getString(24) ));
                nameValuePairs.add(new BasicNameValuePair("image2", cursorSend.getString(25) ));
                nameValuePairs.add(new BasicNameValuePair("image3",cursorSend.getString(26) ));
                nameValuePairs.add(new BasicNameValuePair("image4",cursorSend.getString(27) ));
                nameValuePairs.add(new BasicNameValuePair("image5",cursorSend.getString(28) ));


                Log.e("nameValuePairs sevice", "" + nameValuePairs);
                try {
                      //            new UploadToServer().execute();
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_receiving_pmc_data");
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    REsponse = httpclient.execute(httppost, responseHandler);
                    sqLiteAdapter.openToWrite();
                    sqLiteAdapter.openToRead();
                    String id=cursorSend.getString(0);
                    sqLiteAdapter.delete_value_byID(Integer.parseInt(id));

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } while (cursorSend.moveToNext());

        } else {
        }
    }

    public void cursorM(Cursor cursorSend) {
        if (cursorSend != null && cursorSend.moveToFirst()) {
            int counter = 0;
            do {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair("permit_id", cursorSend.getString(1)));
                nameValuePairs.add(new BasicNameValuePair("project",cursorSend.getString(2)));
                nameValuePairs.add(new BasicNameValuePair("city_id", cursorSend.getString(3)));
                nameValuePairs.add(new BasicNameValuePair("receiving_from_id", cursorSend.getString(4)));
                nameValuePairs.add(new BasicNameValuePair("vendor", cursorSend.getString(5)));
                nameValuePairs.add(new BasicNameValuePair("mzone_id", cursorSend.getString(6)));
                nameValuePairs.add(new BasicNameValuePair("mcity_id", cursorSend.getString(7)));
                nameValuePairs.add(new BasicNameValuePair("store_id", cursorSend.getString(8)));
                nameValuePairs.add(new BasicNameValuePair("item", cursorSend.getString(9)));
                nameValuePairs.add(new BasicNameValuePair("qty_transfer", cursorSend.getString(10)));
                nameValuePairs.add(new BasicNameValuePair("grn_transfer", cursorSend.getString(11)));
                nameValuePairs.add(new BasicNameValuePair("remark", cursorSend.getString(12)));
                nameValuePairs.add(new BasicNameValuePair("latt",cursorSend.getString(13)));
                nameValuePairs.add(new BasicNameValuePair("longg",cursorSend.getString(14) ));
                nameValuePairs.add(new BasicNameValuePair("mobile_time",cursorSend.getString(15)));
                nameValuePairs.add(new BasicNameValuePair("imagename1",cursorSend.getString(16)));
                nameValuePairs.add(new BasicNameValuePair("imagename2",cursorSend.getString(17)));
                nameValuePairs.add(new BasicNameValuePair("imagename3",cursorSend.getString(18)));
                nameValuePairs.add(new BasicNameValuePair("imagename4",cursorSend.getString(19) ));
                nameValuePairs.add(new BasicNameValuePair("imagename5",cursorSend.getString(20) ));
                nameValuePairs.add(new BasicNameValuePair("image1",cursorSend.getString(21) ));
                nameValuePairs.add(new BasicNameValuePair("image2", cursorSend.getString(22) ));
                nameValuePairs.add(new BasicNameValuePair("image3",cursorSend.getString(23) ));
                nameValuePairs.add(new BasicNameValuePair("image4",cursorSend.getString(24) ));
                nameValuePairs.add(new BasicNameValuePair("image5",cursorSend.getString(25) ));


                Log.e("nameValuePairs transfer", "" + nameValuePairs);
                try {
//            new UploadToServer().execute();
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_material_transfer_data");
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    REsponse = httpclient.execute(httppost, responseHandler);
                    sqLiteAdapter_m.openToWrite();
                    sqLiteAdapter_m.openToRead();
                    String id=cursorSend.getString(0);
                    sqLiteAdapter_m.delete_value_byID(Integer.parseInt(id));

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } while (cursorSend.moveToNext());

        } else {
        }
    }

    //-------------For site Inspection data only----------------------------------//
    public void cursorI(Cursor cursorSend) {
        if (cursorSend != null && cursorSend.moveToFirst()) {
            int counter = 0;
            do {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair("permit_id", cursorSend.getString(1)));
                nameValuePairs.add(new BasicNameValuePair("project", cursorSend.getString(2)));
                nameValuePairs.add(new BasicNameValuePair("geographic",cursorSend.getString(3)));
                nameValuePairs.add(new BasicNameValuePair("subarea_one",cursorSend.getString(4)));
                nameValuePairs.add(new BasicNameValuePair("subarea_two",cursorSend.getString(5)));
                nameValuePairs.add(new BasicNameValuePair("main_item",cursorSend.getString(6)));
                nameValuePairs.add(new BasicNameValuePair("sub_item", cursorSend.getString(7)));
                nameValuePairs.add(new BasicNameValuePair("uom_no", cursorSend.getString(8)));
                nameValuePairs.add(new BasicNameValuePair("pole_item_yes", cursorSend.getString(9)));
                nameValuePairs.add(new BasicNameValuePair("pole_item_cancel", cursorSend.getString(10)));
                nameValuePairs.add(new BasicNameValuePair("checkbox_input", cursorSend.getString(11)));
                nameValuePairs.add(new BasicNameValuePair("checkbox_na", cursorSend.getString(12)));
                nameValuePairs.add(new BasicNameValuePair("latt", cursorSend.getString(13)));
                nameValuePairs.add(new BasicNameValuePair("longg", cursorSend.getString(14)));
                nameValuePairs.add(new BasicNameValuePair("mobile_time", cursorSend.getString(15)));
                nameValuePairs.add(new BasicNameValuePair("remark", cursorSend.getString(16)));
                nameValuePairs.add(new BasicNameValuePair("pass_rework", cursorSend.getString(17)));
                nameValuePairs.add(new BasicNameValuePair("imagename1", cursorSend.getString(18)));
                nameValuePairs.add(new BasicNameValuePair("imagename2", cursorSend.getString(19)));
                nameValuePairs.add(new BasicNameValuePair("imagename3", cursorSend.getString(20)));
                nameValuePairs.add(new BasicNameValuePair("imagename4", cursorSend.getString(21)));
                nameValuePairs.add(new BasicNameValuePair("imagename5", cursorSend.getString(22)));
                nameValuePairs.add(new BasicNameValuePair("image1", cursorSend.getString(23)));
                nameValuePairs.add(new BasicNameValuePair("image2", cursorSend.getString(24)));
                nameValuePairs.add(new BasicNameValuePair("image3", cursorSend.getString(25)));
                nameValuePairs.add(new BasicNameValuePair("image4", cursorSend.getString(26)));
                nameValuePairs.add(new BasicNameValuePair("image5", cursorSend.getString(27)));


                Log.e("nameValuePairs Insp", "" + nameValuePairs);
                try {
//            new UploadToServer().execute();
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_pmc_data");
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    REsponse = httpclient.execute(httppost, responseHandler);
                    sqLiteInspection.openToWrite();
                    sqLiteInspection.openToRead();
                    String id=cursorSend.getString(0);
                    sqLiteInspection.delete_value_byID(Integer.parseInt(id));

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } while (cursorSend.moveToNext());

        } else {
        }
    }

    //------------Issue------------------------------//

    //-------------For site Inspection data only----------------------------------//
    public void cursorIssue(Cursor cursorSend) {
        if (cursorSend != null && cursorSend.moveToFirst()) {
            int counter = 0;
            do {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair("permit_id", cursorSend.getString(1)));
                nameValuePairs.add(new BasicNameValuePair("project", cursorSend.getString(2)));
                nameValuePairs.add(new BasicNameValuePair("in_out_id", cursorSend.getString(3)));
                nameValuePairs.add(new BasicNameValuePair("zone_id", cursorSend.getString(4)));
                nameValuePairs.add(new BasicNameValuePair("city_id", cursorSend.getString(5)));
                nameValuePairs.add(new BasicNameValuePair("gcjunction", cursorSend.getString(6)));
                nameValuePairs.add(new BasicNameValuePair("junction_id", cursorSend.getString(7)));
                nameValuePairs.add(new BasicNameValuePair("issue_id", cursorSend.getString(8)));
                nameValuePairs.add(new BasicNameValuePair("other_issue", cursorSend.getString(9)));
                nameValuePairs.add(new BasicNameValuePair("remark", cursorSend.getString(10)));


                Log.e("nameValuePairs Issue", "" + nameValuePairs);
                try {
//            new UploadToServer().execute();
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_issue_data");
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    REsponse = httpclient.execute(httppost, responseHandler);
                    sqLiteissue.openToWrite();
                    sqLiteissue.openToRead();
                    String id=cursorSend.getString(0);
                    sqLiteissue.delete_value_byID(Integer.parseInt(id));

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } while (cursorSend.moveToNext());

        } else {
        }
    }



}
