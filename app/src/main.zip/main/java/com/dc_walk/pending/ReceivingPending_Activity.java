package com.dc_walk.pending;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;

/**
 * Created by nitinb on 08-03-2016.
 */
public class ReceivingPending_Activity extends Activity {

    Button btn_upload;
    SessionManager sessionManager;

    ConnectionDetector connectionDetector;
    SQLiteAdapter1 sqLiteAdapter;

    Cursor cursor_limit, cursor_all;
    int get_count;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.pending);

        btn_upload = (Button) findViewById(R.id.si_pending);
        sessionManager = new SessionManager(ReceivingPending_Activity.this);
        connectionDetector = new ConnectionDetector(ReceivingPending_Activity.this);
        sqLiteAdapter = new SQLiteAdapter1(ReceivingPending_Activity.this);

        // btn upload

        btn_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (connectionDetector.isConnectingToInternet()) {
                    if (setCount() > 0) {
                        new StartProgressBar().execute();
                    } else {
                        //Toast.makeText(Pending_Activity.this, "There is no pending record", Toast.LENGTH_SHORT).show();
                        Toast toast = Toast.makeText(getApplicationContext(), "There is no pending record", Toast.LENGTH_SHORT);
                        View toastView = toast.getView();
                        TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
                        toastMessage.setTextSize(20);
                        toastMessage.setTextColor(Color.RED);
                        //toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
                        toastMessage.setGravity(Gravity.CENTER);
                        toastMessage.setCompoundDrawablePadding(16);
                        toastView.setBackgroundColor(getResources().getColor(R.color.colorBg));
                        toast.show();
                    }
                } else {
                    //Toast.makeText(Pending_Activity.this, "internet not connected", Toast.LENGTH_SHORT).show();
                    Toast toast = Toast.makeText(getApplicationContext(), "Internet not connected", Toast.LENGTH_SHORT);
                    View toastView = toast.getView();
                    TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
                    toastMessage.setTextSize(20);
                    toastMessage.setTextColor(Color.RED);
                    //toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
                    toastMessage.setGravity(Gravity.CENTER);
                    toastMessage.setCompoundDrawablePadding(16);
                    toastView.setBackgroundColor(getResources().getColor(R.color.colorBg));
                    toast.show();
                }

            }
        });


    }


    public class StartProgressBar extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ReceivingPending_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {
                senddata();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            //Log.e("response", response);
            if (connectionDetector.isConnectingToInternet()) {
//					Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
            } else {
                //Toast.makeText(getBaseContext(),"Internet not connected",Toast.LENGTH_SHORT).show();
                Toast toast = Toast.makeText(getApplicationContext(), "Internet not connected", Toast.LENGTH_SHORT);
                View toastView = toast.getView();
                TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
                toastMessage.setTextSize(20);
                toastMessage.setTextColor(Color.RED);
                //toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
                toastMessage.setGravity(Gravity.CENTER);
                toastMessage.setCompoundDrawablePadding(16);
                toastView.setBackgroundColor(getResources().getColor(R.color.colorBg));
                toast.show();
            }
            try {
                if (setCount() > 0) {
                    //Toast.makeText(getBaseContext(),"still records are pending",Toast.LENGTH_SHORT).show();
                    Toast toast = Toast.makeText(getApplicationContext(), "still records are pending", Toast.LENGTH_SHORT);
                    View toastView = toast.getView();
                    TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
                    toastMessage.setTextSize(20);
                    toastMessage.setTextColor(Color.RED);
                    //toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
                    toastMessage.setGravity(Gravity.CENTER);
                    toastMessage.setCompoundDrawablePadding(16);
                    toastView.setBackgroundColor(getResources().getColor(R.color.colorBg));
                    toast.show();
                } else {
                    //Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
                    Toast toast = Toast.makeText(getApplicationContext(), "send complete records", Toast.LENGTH_SHORT);
                    View toastView = toast.getView();
                    TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
                    toastMessage.setTextSize(20);
                    toastMessage.setTextColor(Color.RED);
                    //toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
                    toastMessage.setGravity(Gravity.CENTER);
                    toastMessage.setCompoundDrawablePadding(16);
                    toastView.setBackgroundColor(getResources().getColor(R.color.colorBg));
                    toast.show();
                }
                //  setVisibile();
            } catch (Exception e) {
                // TODO: handle exception
            }
        }
    }


    public void senddata() {
        // TODO Auto-generated method stub
        if (connectionDetector.isConnectingToInternet()) {
            try {
                sqLiteAdapter.openToWrite();
                sqLiteAdapter.openToRead();
                //Log.e("firstsenddata", "come into senddata");
                if (sqLiteAdapter.countData() >= 25) {
                    if (cursor_limit != null) {

                        try {
                            cursor_limit = null;
                        } catch (Exception e) {
                            // TODO: handle exception
                        }
                    }
                    cursor_limit = sqLiteAdapter.getdataFixdata();
                    cursor(cursor_limit);

                    //Log.e("senddata2", ""+cursorPendingData2.getCount());

                } else {
                    cursor_all = sqLiteAdapter.queueAll();
                    cursor(cursor_all);
                    //	Log.e("senddata3", ""+cursorPendingData3.getCount());
                }
            } catch (Exception e) {
                // TODO: handle exception
            }


        } else {
            //Toast.makeText(this, "Internet not connected", Toast.LENGTH_LONG).show();
            Toast toast = Toast.makeText(getApplicationContext(), "Internet not connected", Toast.LENGTH_SHORT);
            View toastView = toast.getView();
            TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
            toastMessage.setTextSize(20);
            toastMessage.setTextColor(Color.RED);
            //toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
            toastMessage.setGravity(Gravity.CENTER);
            toastMessage.setCompoundDrawablePadding(16);
            toastView.setBackgroundColor(getResources().getColor(R.color.colorBg));
            toast.show();
        }
    }

    public void cursor(Cursor cursorSend) {
        if (cursorSend != null && cursorSend.moveToFirst()) {
            do {
                int activity_id = cursorSend.getInt(0);
                String permit_id = cursorSend.getString(1);
                String project = cursorSend.getString(2);
                String geographic = cursorSend.getString(3);
                String subarea_one = cursorSend.getString(4);
                String subarea_two = cursorSend.getString(5);
                String subarea_three = cursorSend.getString(6);
                String inspection = cursorSend.getString(7);
                String tkc = cursorSend.getString(8);
                String utility = cursorSend.getString(9);
                String contractor = cursorSend.getString(10);
                String mobile_time = cursorSend.getString(11);
                String latt = cursorSend.getString(12);
                String longg = cursorSend.getString(13);
                String remark = cursorSend.getString(14);
                String image1 = cursorSend.getString(15);
                String image2 = cursorSend.getString(16);
                String image3 = cursorSend.getString(17);
                String pole_item = cursorSend.getString(18);
                String pole_item_cancel = cursorSend.getString(19);
                // Log.e("from Cursor", "" + cursorSend.getInt(0));
                try {
                   /* new PendingData(getBaseContext(), activity_id, permit_id, project, geographic, subarea_one, subarea_two, subarea_three, inspection,
                            tkc,
                            utility, contractor, mobile_time, latt, longg, remark, image1, image2, image3, pole_item, pole_item_cancel).execute();
*/
                } catch (Exception e) {
                }
            } while (cursorSend.moveToNext());
        } else {
        }
    }


    private int setCount() {
        // TODO Auto-generated method stub
        try {
            sqLiteAdapter.openToRead();
            sqLiteAdapter.openToWrite();
            get_count = sqLiteAdapter.countData();
            Log.e("Count", "" + get_count);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return get_count;
    }


    @Override
    public void onBackPressed() {
        //  super.onBackPressed();
        showAlert();
    }


    public void showAlert() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                ReceivingPending_Activity.this);

        // set title
        alertDialogBuilder.setTitle("Do you want to quit?");

        // set dialog message
        alertDialogBuilder
                //  .setMessage("Click yes to exit!")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, close
                        // current activity
                       /* startActivity(new Intent(Login.this, Login.class));
                        Login.this.finish(); */
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, just close
                        // the dialog box and do nothing
                        dialog.cancel();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }

}
