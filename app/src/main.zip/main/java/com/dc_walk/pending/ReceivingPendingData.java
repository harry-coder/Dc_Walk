package com.dc_walk.pending;


import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.dc_walk.authentication.SessionManager;
import com.dc_walk.sqlite_adapter.SQLiteAdapterReceiving;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;

public class ReceivingPendingData extends AsyncTask<String, String,String> {
     String response;
	SQLiteAdapterReceiving sqLiteAdapter;
	Context context;
    SessionManager sessionManager;
	int id;
	String strpermit_id,strproject, strcityid, strreceiving_from,strvendor,strmzone,strmcity,
			strstoreid,stritem,strqty_doc,strqty_rec,strqty_damaged,strqty_accepted,strgrn_transfer,strremark,
			strlatt,strlongg,strmobile_time,strimage1_name,strimage2_name,strimage3_name,strimage4_name,strimage5_name,strimage1,strimage2,strimage3,strimage4,strimage5;

	public ReceivingPendingData(Context c, int activity_id, String permit_id,String project,String cityid,String receiving_from,String vendor,String mzone,String mcity,
								String storeid,String item,String qty_doc,String qty_rec,String qty_damaged,String qty_accepted,String grn_transfer,String remark,
								String latt,String longg,String mobile_time,String image1_name,String image2_name,String image3_name,String image4_name,String image5_name,String image1,String image2,String image3,String image4,String image5) {
		
	// TODO Auto-generated constructor stub
		try{
		context=c;
		sqLiteAdapter=new SQLiteAdapterReceiving(context);
   //		adapter.openToRead();
		    sqLiteAdapter.openToWrite();
			id=activity_id;
			strpermit_id=  permit_id;
			strproject=    project;
			strcityid= cityid;
			strreceiving_from=receiving_from;
			strvendor=vendor;
			strmzone=mzone;
			strmcity =mcity ;
			strstoreid =   storeid ;
			stritem=    item;
			strqty_doc=    qty_doc;
			strqty_rec= qty_rec;
			strqty_damaged= qty_damaged;
			strqty_accepted=qty_accepted;
			strgrn_transfer=grn_transfer;
			strremark=remark;
			strlatt=       latt;
			strlongg=      longg;
			strmobile_time=     mobile_time;
			strimage1_name=     image1_name;
			strimage2_name=     image2_name;
			strimage3_name=     image3_name;
			strimage4_name=     image4_name;
			strimage5_name=     image5_name;
			strimage1=     image1;
			strimage2=     image2;
			strimage3=     image3;
			strimage4=     image4;
			strimage5=     image5;

	}catch(Exception e)
	{
		e.printStackTrace();
	}
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub		
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

		nameValuePairs.add(new BasicNameValuePair("permit_id",strpermit_id ));
		nameValuePairs.add(new BasicNameValuePair("project",strproject));
		nameValuePairs.add(new BasicNameValuePair("city_id", strcityid));
		nameValuePairs.add(new BasicNameValuePair("receiving_from_id", strreceiving_from));
		nameValuePairs.add(new BasicNameValuePair("vendor", strvendor));
		nameValuePairs.add(new BasicNameValuePair("mzone_id", strmzone));
		nameValuePairs.add(new BasicNameValuePair("mcity_id", strmcity));
		nameValuePairs.add(new BasicNameValuePair("store_id", strstoreid));
		nameValuePairs.add(new BasicNameValuePair("item", stritem));
		nameValuePairs.add(new BasicNameValuePair("qty_doc", strqty_doc));
		nameValuePairs.add(new BasicNameValuePair("qty_rec", strqty_rec));
		nameValuePairs.add(new BasicNameValuePair("qty_damaged", strqty_damaged));
		nameValuePairs.add(new BasicNameValuePair("qty_accepted", strqty_accepted));
		nameValuePairs.add(new BasicNameValuePair("grn_transfer", strgrn_transfer));
		nameValuePairs.add(new BasicNameValuePair("remark", strremark));
		nameValuePairs.add(new BasicNameValuePair("latt",strlatt));
		nameValuePairs.add(new BasicNameValuePair("longg",strlongg ));
        nameValuePairs.add(new BasicNameValuePair("mobile_time",strmobile_time));
		nameValuePairs.add(new BasicNameValuePair("imagename1",strimage1_name));
		nameValuePairs.add(new BasicNameValuePair("imagename2",strimage2_name));
		nameValuePairs.add(new BasicNameValuePair("imagename3",strimage3_name));
		nameValuePairs.add(new BasicNameValuePair("imagename4",strimage4_name ));
		nameValuePairs.add(new BasicNameValuePair("imagename5",strimage5_name ));
		nameValuePairs.add(new BasicNameValuePair("image1",strimage1 ));
		nameValuePairs.add(new BasicNameValuePair("image2", strimage2 ));
		nameValuePairs.add(new BasicNameValuePair("image3",strimage3 ));
		nameValuePairs.add(new BasicNameValuePair("image4",strimage4 ));
		nameValuePairs.add(new BasicNameValuePair("image5",strimage5 ));
         Log.e("nameValuePairs", "" + nameValuePairs);
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_receiving_pmc_data");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			response = httpclient.execute(httppost, responseHandler);

        } catch (Exception e) {
		}
		return response;
	}
	
	@Override
	protected void onPostExecute(String result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
		
		try{
			if(response.trim().equalsIgnoreCase("1")){

				sqLiteAdapter.openToWrite();
				sqLiteAdapter.delete_value_byID(id);

				response=null;
			}
			else {
				Toast.makeText(context,"server error", Toast.LENGTH_SHORT).show();

			}
		}catch(Exception e){}
		finally{
			
			sqLiteAdapter.close();
		}
		}

}
