package com.dc_walk.pending;


import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.dc_walk.authentication.SessionManager;
import com.dc_walk.sqlite_adapter.SQLiteAdapterIssue;


import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;

public class WorkProgressPendingData extends AsyncTask<String, String,String> {
     String response;
	SQLiteAdapterIssue sqLiteAdapter;
	Context context;
    SessionManager sessionManager;
	int id;
	String strpermit_id,strproject, strin_out_id, strzone_id,strcity_id,strg_c_junction,strjunction_id,
			strissue_id,strother_issue,strremark;

	public WorkProgressPendingData(Context c, int activity_id,String permit_id,String project,String in_out_id,String zone_id,String city_id,String g_c_junction,String junction_id,
								   String issue_id,String other_issue,String remark) {
		
	// TODO Auto-generated constructor stub
		try{
		context=c;
		sqLiteAdapter=new SQLiteAdapterIssue(context);
   //		adapter.openToRead();
		    sqLiteAdapter.openToWrite();
			id=activity_id;
			strpermit_id =  permit_id;
			strproject =  project;
			strin_out_id =   in_out_id;
			strzone_id =  zone_id;
			strcity_id = city_id;
			strg_c_junction =  g_c_junction;
			strjunction_id = junction_id;
			strissue_id = issue_id;
			strother_issue = other_issue;
			strremark =  remark;


	}catch(Exception e)
	{
		e.printStackTrace();
	}
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub		
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

		nameValuePairs.add(new BasicNameValuePair("permit_id",strpermit_id ));
		nameValuePairs.add(new BasicNameValuePair("project", strproject));
		nameValuePairs.add(new BasicNameValuePair("in_out_id", strin_out_id));
		nameValuePairs.add(new BasicNameValuePair("zone_id", strzone_id));
		nameValuePairs.add(new BasicNameValuePair("city_id", strcity_id));
		nameValuePairs.add(new BasicNameValuePair("gcjunction", strg_c_junction));
		nameValuePairs.add(new BasicNameValuePair("junction_id", strjunction_id));
		nameValuePairs.add(new BasicNameValuePair("issue_id", strissue_id));
		nameValuePairs.add(new BasicNameValuePair("other_issue", strother_issue));
		nameValuePairs.add(new BasicNameValuePair("remark", strremark));

       Log.e("nameValuePairs", "" + nameValuePairs);
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_issue_data");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			response = httpclient.execute(httppost, responseHandler);

        } catch (Exception e) {
		}
		return response;
	}
	
	@Override
	protected void onPostExecute(String result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
		
		try{
			if(response.trim().equalsIgnoreCase("1")){

				sqLiteAdapter.openToWrite();
				sqLiteAdapter.delete_value_byID(id);

				response=null;
			}
			else {
				Toast.makeText(context,"server error", Toast.LENGTH_SHORT).show();

			}
		}catch(Exception e){}
		finally{
			
			sqLiteAdapter.close();
		}
		}

}
