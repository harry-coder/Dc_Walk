package com.dc_walk.data_holder;

/**
 * Created by nitinb on 10-02-2016.
 */
public class DataHolder_Survey {

    private static DataHolder_Survey dataObject = null;


    public DataHolder_Survey() {
        // left blank intentionally
    }

    public static DataHolder_Survey getInstance() {
        if (dataObject == null)
            dataObject = new DataHolder_Survey();
        return dataObject;
    }

    public String project_id;

    public String getProject_id() {
        return project_id;
    }

    public void setProject_id(String project_id) {
        this.project_id = project_id;
    }

    public String getSurvey_id() {
        return survey_id;
    }

    public void setSurvey_id(String survey_id) {
        this.survey_id = survey_id;
    }

    public String getTkcRespName() {
        return tkcRespName;
    }

    public void setTkcRespName(String tkcRespName) {
        this.tkcRespName = tkcRespName;
    }

    public String getUtilityRespName() {
        return utilityRespName;
    }

    public void setUtilityRespName(String utilityRespName) {
        this.utilityRespName = utilityRespName;
    }

    public String getNewSurvey() {
        return newSurvey;
    }

    public void setNewSurvey(String newSurvey) {
        this.newSurvey = newSurvey;
    }

    public String getContinueSurvey() {
        return continueSurvey;
    }

    public void setContinueSurvey(String continueSurvey) {
        this.continueSurvey = continueSurvey;
    }

    public String survey_id;
    public String tkcRespName;
    public String utilityRespName;
    public String newSurvey;
    public String continueSurvey;

    public String captureLat;

    public String getCaptureLat() {
        return captureLat;
    }

    public void setCaptureLat(String captureLat) {
        this.captureLat = captureLat;
    }

    public String getCaptureLong() {
        return captureLong;
    }

    public void setCaptureLong(String captureLong) {
        this.captureLong = captureLong;
    }

    public String getCapturetime() {
        return capturetime;
    }

    public void setCapturetime(String capturetime) {
        this.capturetime = capturetime;
    }

    public String getPreviousPoint() {
        return previousPoint;
    }

    public void setPreviousPoint(String previousPoint) {
        this.previousPoint = previousPoint;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public String captureLong;
    public String capturetime;
    public String previousPoint;
    public String assetType;
    public String assetTypeName;
    public String remarks;
    public String surveyDTR;
    public String previousAssetConcate;
    public String previousLat;
    public String surveyDTRremarksConcate;
    public String assetConcateType;

    public String getAssetConcateType() {
        return assetConcateType;
    }

    public void setAssetConcateType(String assetConcateType) {
        this.assetConcateType = assetConcateType;
    }

    public String getSurveyDTRremarksConcate() {
        return surveyDTRremarksConcate;
    }

    public void setSurveyDTRremarksConcate(String surveyDTRremarksConcate) {
        this.surveyDTRremarksConcate = surveyDTRremarksConcate;
    }

    public String getPreviousLat() {
        return previousLat;
    }

    public void setPreviousLat(String previousLat) {
        this.previousLat = previousLat;
    }

    public String getPreviousLong() {
        return previousLong;
    }

    public void setPreviousLong(String previousLong) {
        this.previousLong = previousLong;
    }

    public String previousLong;


    public String getPreviousAssetConcate() {
        return previousAssetConcate;
    }

    public void setPreviousAssetConcate(String previousAssetConcate) {
        this.previousAssetConcate = previousAssetConcate;
    }

    public int countDTR;
    public int countFeeder;
    public int countSubstation;
    public int countConsumer;

    public int getCountDTR() {
        return countDTR;
    }

    public void setCountDTR(int countDTR) {
        this.countDTR = countDTR;
    }

    public int getCountFeeder() {
        return countFeeder;
    }

    public void setCountFeeder(int countFeeder) {
        this.countFeeder = countFeeder;
    }

    public int getCountSubstation() {
        return countSubstation;
    }

    public void setCountSubstation(int countSubstation) {
        this.countSubstation = countSubstation;
    }

    public int getCountConsumer() {
        return countConsumer;
    }

    public void setCountConsumer(int countConsumer) {
        this.countConsumer = countConsumer;
    }

    public String getSurveyDTR() {
        return surveyDTR;
    }

    public void setSurveyDTR(String surveyDTR) {
        this.surveyDTR = surveyDTR;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getAssetTypeName() {
        return assetTypeName;
    }

    public void setAssetTypeName(String assetTypeName) {
        this.assetTypeName = assetTypeName;
    }
}
