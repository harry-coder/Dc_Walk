package com.dc_walk.receiving_insp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class ReceivingInspection_Activity extends Activity {

    //public String EMP_ID = "emp_id";


    Button finishBtn,factory_inspection_item;

    EditText ed_other_rsp, ed_supplier_rsp, ed_vendorResp;
    String str_supplier_rsp, str_other_rsp, str_vendorResp;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.receiving_inspection_item);



     //-------------for back Page-----------------//
        finishBtn = (Button) findViewById(R.id.finishBtn);
        finishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Intent i = new Intent(ReceivingInspection_Activity.this, Home_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/

                onBackPressed();

            }
        });




    }





}
