package com.dc_walk.adapter;

public class ItemObject {

    private String name;

    public ItemObject(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
