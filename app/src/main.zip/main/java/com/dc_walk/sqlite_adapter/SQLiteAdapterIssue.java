package com.dc_walk.sqlite_adapter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by nitinb on 09-02-2016.
 */
public class SQLiteAdapterIssue {

    public static final String MYDATABASE_NAME ="PMCF";
    public static final int MYDATABASE_VERSION = 1;

   // Create FACTORY inspection table
    public static final String SI_TABLE = "SI_TABLE";
    public static final String SI_TABLE_ID="id";
    public static final String SI_EMP_ID="emp_id";
    public static final String SI_PROJECT = "si_project";
    public static final String SI_IN_OUT_ID = "si_in_out_id";
    public static final String SI_ZONE_ID = "si_zone_id";
    public static final String SI_CITY_ID = "si_city_id";
    public static final String SI_G_C_JUNCTION = "si_g_c_junction";
    public static final String SI_JUNCTION_ID = "si_junction_id";
    public static final String SI_ISSUE_ID = "si_issue_id";
    public static final String SI_OTHER_ISSUE = "si_other_issue";
    public static final String SI_REMARK = "si_remark";


    //..........Site Inspection table............................//
    private static final String CREATE_SI_TABLE =
            "create table " + SI_TABLE + " ("
                    + SI_TABLE_ID + " integer primary key autoincrement, "
                    + SI_EMP_ID + " text, "
                    + SI_PROJECT + " text, "
                    + SI_IN_OUT_ID + " text, "
                    + SI_ZONE_ID + " text, "
                    + SI_CITY_ID + " text, "
                    + SI_G_C_JUNCTION + " text, "
                    + SI_JUNCTION_ID + " text, "
                    + SI_ISSUE_ID + " text, "
                    + SI_OTHER_ISSUE + " text, "
                    + SI_REMARK + " text  ) ; ";


    //............ insert SI..............//
    public long insert_value(String content0, String content1, String content2, String content3,
                             String content4, String content5, String content6, String content7,
                             String content8, String content9){

        ContentValues contentValues = new ContentValues();
        contentValues.put(SI_EMP_ID, content0);
        contentValues.put(SI_PROJECT, content1);
        contentValues.put(SI_IN_OUT_ID, content2);
        contentValues.put(SI_ZONE_ID, content3);
        contentValues.put(SI_CITY_ID, content4);
        contentValues.put(SI_G_C_JUNCTION, content5);
        contentValues.put(SI_JUNCTION_ID, content6);
        contentValues.put(SI_ISSUE_ID, content7);
        contentValues.put(SI_OTHER_ISSUE, content8);
        contentValues.put(SI_REMARK, content9);

        // Log.e("content value", "" + contentValues);
        return sqLiteDatabase.insert(SI_TABLE, null, contentValues);
    }



    public int delete_value_All(){
        return sqLiteDatabase.delete(SI_TABLE, null, null);
    }

    public void delete_value_byID(int id){
        sqLiteDatabase.delete(SI_TABLE, SI_TABLE_ID + "=" + id, null);
    }

    public int countData(){

        String countQuery = "SELECT  * FROM " + SI_TABLE;
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        int cnt = cursor.getCount();
//	    cursor.close();
        return cnt;
    }

    public Cursor getdataFixdata(){

        String countQuery = "SELECT  * FROM " + SI_TABLE+ " limit 0 , 25";
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        Log.e("getfixdata", ""+cursor.getCount());
        Log.e("getfixcolumn", ""+cursor.getColumnCount());
//	    int cnt = cursor.getCount();
//	    cursor.close();

        return cursor;
    }

    public Cursor queueAll(){

        String countQuery = "SELECT  * FROM " + SI_TABLE;
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        return cursor;
    }


    //--------------Open General Purchase--------------------------------//

    // Create Open General Purchase table
    public static final String OP_TABLE = "OP_TABLE";
    public static final String OP_TABLE_ID="id";
    public static final String OP_EMP_ID="emp_id";
    public static final String OP_PROJECT = "project";
    public static final String OP_SCHEME = "scheme";
    public static final String OP_SUPPLIER_NAME = "supplier_name";
    public static final String OP_PONO = "po_number";
    public static final String OP_INVOICENO = "invoice_no";
    public static final String OP_MAIN_ITEM = "main_item";
    public static final String OP_SUBITEM = "subitem";
    public static final String OP_LOTNO = "lot_no";
    public static final String OP_SPECNO= "spec_no";
    public static final String OP_QTYINSPECTED = "qty_inspected";
    public static final String OP_QTY_PASSED = "qty_passed";
    public static final String OP_LOT_STATUS = "lot_status";
    public static final String OP_REMARK = "remark";
    public static final String OP_LAT = "lat";
    public static final String OP_LONG = "long";
    public static final String OP_TIME = "time";
    public static final String OP_IMAGE1_NAME = "image1_name";
    public static final String OP_IMAGE2_NAME = "image2_name";
    public static final String OP_IMAGE3_NAME = "image3_name";
    public static final String OP_IMAGE4_NAME = "image4_name";
    public static final String OP_IMAGE5_NAME = "image5_name";
    public static final String OP_IMAGE1 = "image1";
    public static final String OP_IMAGE2 = "image2";
    public static final String OP_IMAGE3 = "image3";
    public static final String OP_IMAGE4 = "image4";
    public static final String OP_IMAGE5 = "image5";

    //..........Site Inspection table............................//
    private static final String CREATE_OP_TABLE =
            "create table " + OP_TABLE + " ("
                    + OP_TABLE_ID + " integer primary key autoincrement, "
                    + OP_EMP_ID + " text, "
                    + OP_PROJECT + " text, "
                    + OP_SCHEME + " text, "
                    + OP_SUPPLIER_NAME + " text, "
                    + OP_PONO + " text, "
                    + OP_INVOICENO + " text, "
                    + OP_MAIN_ITEM + " text, "
                    + OP_SUBITEM + " text, "
                    + OP_LOTNO + " text, "
                    + OP_SPECNO + " text, "
                    + OP_QTYINSPECTED + " text, "
                    + OP_QTY_PASSED + " text, "
                    + OP_LOT_STATUS + " text, "
                    + OP_REMARK + " text, "
                    + OP_LAT + " text, "
                    + OP_LONG + " text, "
                    + OP_TIME + " text, "
                    + OP_IMAGE1_NAME+ " text, "
                    + OP_IMAGE2_NAME + " text, "
                    + OP_IMAGE3_NAME + " text, "
                    + OP_IMAGE4_NAME+ " text, "
                    + OP_IMAGE5_NAME + " text, "
                    + OP_IMAGE1 + " text, "
                    + OP_IMAGE2+ " text, "
                    + OP_IMAGE3 + " text, "
                    + OP_IMAGE4 + " text, "
                    + OP_IMAGE5 + " text  ) ; ";


    //............ insert OPEN PURCHASE..............//
    public long insert_op_value(String content0, String content1, String content2, String content3,
                             String content4, String content5, String content6, String content7,
                             String content8, String content9, String content10, String content11, String content12, String content13, String content14, String content15, String content16, String content17, String content18, String content19,String content20, String content21, String content22, String content23, String content24, String content25, String content26){

        ContentValues contentValues = new ContentValues();
        contentValues.put(OP_EMP_ID, content0);
        contentValues.put(OP_PROJECT, content1);
        contentValues.put(OP_SCHEME, content2);
        contentValues.put(OP_SUPPLIER_NAME, content3);
        contentValues.put(OP_PONO, content4);
        contentValues.put(OP_INVOICENO, content5);
        contentValues.put(OP_MAIN_ITEM, content6);
        contentValues.put(OP_SUBITEM, content7);
        contentValues.put(OP_LOTNO, content8);
        contentValues.put(OP_SPECNO, content9);
        contentValues.put(OP_QTYINSPECTED, content10);
        contentValues.put(OP_QTY_PASSED, content11);
        contentValues.put(OP_LOT_STATUS, content12);
        contentValues.put(OP_REMARK, content13);
        contentValues.put(OP_LAT, content14);
        contentValues.put(OP_LONG, content15);
        contentValues.put(OP_TIME, content16);
        contentValues.put(OP_IMAGE1_NAME, content17);
        contentValues.put(OP_IMAGE2_NAME, content18);
        contentValues.put(OP_IMAGE3_NAME, content19);
        contentValues.put(OP_IMAGE4_NAME, content20);
        contentValues.put(OP_IMAGE5_NAME, content21);
        contentValues.put(OP_IMAGE1, content22);
        contentValues.put(OP_IMAGE2, content23);
        contentValues.put(OP_IMAGE3, content24);
        contentValues.put(OP_IMAGE4, content25);
        contentValues.put(OP_IMAGE5, content26);
        // Log.e("content value", "" + contentValues);
        return sqLiteDatabase.insert(OP_TABLE, null, contentValues);
    }



    public int delete_value_AllOP(){
        return sqLiteDatabase.delete(OP_TABLE, null, null);
    }

    public void delete_valueOP_byID(int id){
        sqLiteDatabase.delete(OP_TABLE, OP_TABLE_ID + "=" + id, null);
    }

    public int countDataOP(){

        String countQuery = "SELECT  * FROM " + OP_TABLE;
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        int cnt = cursor.getCount();
//	    cursor.close();
        return cnt;
    }

    public Cursor getdataFixdataOP(){

        String countQuery = "SELECT  * FROM " + OP_TABLE+ " limit 0 , 25";
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        Log.e("getfixdata", ""+cursor.getCount());
        Log.e("getfixcolumn", ""+cursor.getColumnCount());
//	    int cnt = cursor.getCount();
//	    cursor.close();

        return cursor;
    }

    public Cursor queueAllOP(){

        String countQuery = "SELECT  * FROM " + OP_TABLE;
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        return cursor;
    }




    private SQLiteHelper sqLiteHelper;
    private SQLiteDatabase sqLiteDatabase;
    private Context context;

    public SQLiteAdapterIssue(Context c)
    {
        context = c;

    }

    public SQLiteAdapterIssue openToRead() throws android.database.SQLException {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);
        sqLiteDatabase = sqLiteHelper.getReadableDatabase();
        return this;
    }
    public SQLiteAdapterIssue openToWrite() throws android.database.SQLException {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);
        sqLiteDatabase = sqLiteHelper.getWritableDatabase();
        return this;
    }
    public void close(){
        sqLiteHelper.close();
    }

    //#########################################  select ####################################################//



    public class SQLiteHelper extends SQLiteOpenHelper {

        public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO Auto-generated method stub
           db.execSQL(CREATE_SI_TABLE);
            db.execSQL(CREATE_OP_TABLE);


        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub
            db.execSQL("DROP TABLE IF EXISTS " + CREATE_SI_TABLE);
            db.execSQL("DROP TABLE IF EXISTS " + CREATE_OP_TABLE);

            onCreate(db);
        }
    }




}
