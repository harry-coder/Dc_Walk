package com.dc_walk.sqlite_adapter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by nitinb on 09-02-2016.
 */
public class SQLiteAdapterMaterialIssued {

    public static final String MYDATABASE_NAME ="MPMC";
    public static final int MYDATABASE_VERSION = 2;


    // Create Material location table
    public static final String SI_TABLE = "SI_TABLE";
    public static final String SI_TABLE_ID="id";
    public static final String SI_EMP_ID="emp_id";
    public static final String SI_PROJECT = "si_project";
    public static final String SI_CITYID = "si_cityid";
    public static final String SI_RECEIVING_FROM = "si_receiving_from";
    public static final String SI_VENDOR_ID = "si_vendor_id";
    public static final String SI_MZONEID = "si_mzone_id";
    public static final String SI_MCITYID = "si_mcity_id";
    public static final String SI_STOREID = "si_store_id";
    public static final String SI_ITEM = "si_item";
    public static final String SI_QTY_TRANSFER = "si_qty_transfer";
    public static final String SI_GRN_TRANSFER = "si_grn_transfer";
    public static final String SI_REMARK = "si_remark";
    public static final String SI_LAT = "si_lat";
    public static final String SI_LONG = "si_long";
    public static final String SI_TIME = "si_time";
    public static final String SI_IMAGE1_NAME = "si_image1_name";
    public static final String SI_IMAGE2_NAME = "si_image2_name";
    public static final String SI_IMAGE3_NAME = "si_image3_name";
    public static final String SI_IMAGE4_NAME = "si_image4_name";
    public static final String SI_IMAGE5_NAME = "si_image5_name";
    public static final String SI_IMAGE1 = "si_image1";
    public static final String SI_IMAGE2 = "si_image2";
    public static final String SI_IMAGE3 = "si_image3";
    public static final String SI_IMAGE4 = "si_image4";
    public static final String SI_IMAGE5 = "si_image5";


    //..........Material Location table............................//
    private static final String CREATE_SI_TABLE =
            "create table " + SI_TABLE + " ("
                    + SI_TABLE_ID + " integer primary key autoincrement, "
                    + SI_EMP_ID + " text, "
                    + SI_PROJECT + " text, "
                    + SI_CITYID + " text, "
                    + SI_RECEIVING_FROM + " text, "
                    + SI_VENDOR_ID + " text, "
                    + SI_MZONEID + " text, "
                    + SI_MCITYID + " text, "
                    + SI_STOREID + " text, "
                    + SI_ITEM + " text, "
                    + SI_QTY_TRANSFER + " text, "
                    + SI_GRN_TRANSFER + " text, "
                    + SI_REMARK+ " text, "
                    + SI_LAT + " text, "
                    + SI_LONG + " text, "
                    + SI_TIME+ " text, "
                    + SI_IMAGE1_NAME + " text, "
                    + SI_IMAGE2_NAME + " text, "
                    + SI_IMAGE3_NAME+ " text, "
                    + SI_IMAGE4_NAME + " text, "
                    + SI_IMAGE5_NAME + " text, "
                    + SI_IMAGE1+ " text, "
                    + SI_IMAGE2 + " text, "
                    + SI_IMAGE3 + " text, "
                    + SI_IMAGE4 + " text, "
                    + SI_IMAGE5 + " text  ) ; ";



    //............ insert MATERIAL Location..............//
    public long insert_value(String content0, String content1, String content2, String content3,
                             String content4, String content5, String content6, String content7,
                             String content8, String content9, String content10, String content11, String content12, String content13, String content14, String content15, String content16, String content17, String content18, String content19, String content20, String content21, String content22, String content23, String content24){

        ContentValues contentValues = new ContentValues();
        contentValues.put(SI_EMP_ID, content0);
        contentValues.put(SI_PROJECT, content1);
        contentValues.put(SI_CITYID, content2);
        contentValues.put(SI_RECEIVING_FROM, content3);
        contentValues.put(SI_VENDOR_ID, content4);
        contentValues.put(SI_MZONEID, content5);
        contentValues.put(SI_MCITYID, content6);
        contentValues.put(SI_STOREID, content7);
        contentValues.put(SI_ITEM, content8);
        contentValues.put(SI_QTY_TRANSFER, content9);
        contentValues.put(SI_GRN_TRANSFER, content10);
        contentValues.put(SI_REMARK, content11);
        contentValues.put(SI_LAT, content12);
        contentValues.put(SI_LONG, content13);
        contentValues.put(SI_TIME, content14);
        contentValues.put(SI_IMAGE1_NAME, content15);
        contentValues.put(SI_IMAGE2_NAME, content16);
        contentValues.put(SI_IMAGE3_NAME, content17);
        contentValues.put(SI_IMAGE4_NAME, content18);
        contentValues.put(SI_IMAGE5_NAME, content19);
        contentValues.put(SI_IMAGE1, content20);
        contentValues.put(SI_IMAGE2, content21);
        contentValues.put(SI_IMAGE3, content22);
        contentValues.put(SI_IMAGE4, content23);
        contentValues.put(SI_IMAGE5, content24);

        // Log.e("content value", "" + contentValues);
        return sqLiteDatabase.insert(SI_TABLE, null, contentValues);
    }


    public void delete_value_byID(int id){
        //sqLiteDatabase.delete(SI_TABLE, SI_TABLE_ID + "=" + id, null);
        String id1= Integer.toString(id);
        sqLiteDatabase.delete(SI_TABLE, SI_TABLE_ID + "=" + id1, null);
    }

    public int countData(){

        String countQuery = "SELECT  * FROM " + SI_TABLE;
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        int cnt = cursor.getCount();
//	    cursor.close();
        return cnt;
    }

    public Cursor getdataFixdata(){

        String countQuery = "SELECT  * FROM " + SI_TABLE+ " limit 0 , 25";
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
      /*  Log.e("getfixdata", ""+cursor.getCount());
        Log.e("getfixcolumn", ""+cursor.getColumnCount());*/
//	    int cnt = cursor.getCount();
//	    cursor.close();

        return cursor;
    }

    public Cursor queueAll(){

        String countQuery = "SELECT  * FROM " + SI_TABLE;
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        return cursor;
    }



    private SQLiteHelper sqLiteHelper;
    private SQLiteDatabase sqLiteDatabase;
    private Context context;

    public SQLiteAdapterMaterialIssued(Context c)
    {
        context = c;

    }

    public SQLiteAdapterMaterialIssued openToRead() throws android.database.SQLException {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);
        sqLiteDatabase = sqLiteHelper.getReadableDatabase();
        return this;
    }
    public SQLiteAdapterMaterialIssued openToWrite() throws android.database.SQLException {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);
        sqLiteDatabase = sqLiteHelper.getWritableDatabase();
        return this;
    }
    public void close(){
        sqLiteHelper.close();
    }

    //#########################################  select ####################################################//



    public class SQLiteHelper extends SQLiteOpenHelper {

        public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO Auto-generated method stub

            db.execSQL(CREATE_SI_TABLE);


        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub

              db.execSQL("DROP TABLE IF EXISTS " + CREATE_SI_TABLE);

            onCreate(db);
        }
    }





}
