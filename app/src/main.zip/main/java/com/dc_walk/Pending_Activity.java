package com.dc_walk;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;

import com.dc_walk.pending.MaterialPendingData;

import com.dc_walk.pending.ReceivingPendingData;

import com.dc_walk.pending.WorkProgressPendingData;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;

import com.dc_walk.sqlite_adapter.SQLiteAdapterIssue;
import com.dc_walk.sqlite_adapter.SQLiteAdapterMaterialIssued;
import com.dc_walk.sqlite_adapter.SQLiteAdapterReceiving;


/**
 * Created by nitinb on 08-03-2016.
 */
public class Pending_Activity extends Activity {


    Button back_btn;

    Button btn_si_upload,btn_factory_upload,btn_receiving_upload,btn_workprogress_upload,btn_survey_upload,btn_material_upload;
    SessionManager sessionManager;

    ConnectionDetector connectionDetector;
    SQLiteAdapter1 sqLiteAdapter;

    SQLiteAdapterReceiving sqLiteAdapterReceiving;

    SQLiteAdapterMaterialIssued sqLiteAdapterMaterial;
    Cursor cursor_limit, cursor_all;
    int get_count;

    Cursor cursor_limitfactory, cursor_allfactory;
    int get_countfactory;

    Cursor cursor_limitreceiving, cursor_allreceiving;
    int get_countreceiving;

    SQLiteAdapterIssue sqLiteAdapterWork;
    Cursor cursor_limitwork, cursor_allwork;
    int get_countwork;

    Cursor cursor_limitmissue, cursor_allmissue;
    int get_countmissue;

    Cursor cursor_limitsurvey, cursor_allsurvey;
    int get_countsurvey;

    Cursor cursor_limitmaterial, cursor_allmaterial;
    int get_countmaterial;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.pending);

        sessionManager= new SessionManager(Pending_Activity.this);
        connectionDetector=new ConnectionDetector(Pending_Activity.this);
        sqLiteAdapter=new SQLiteAdapter1(Pending_Activity.this);
        sqLiteAdapterReceiving=new SQLiteAdapterReceiving(Pending_Activity.this);
        sqLiteAdapterMaterial =new SQLiteAdapterMaterialIssued(Pending_Activity.this);
        sqLiteAdapterWork =new SQLiteAdapterIssue(Pending_Activity.this);
        //sqLiteAdapterSurvey =new SQLiteAdapterSurveyPending(Pending_Activity.this);

        back_btn = (Button) findViewById(R.id.back_btn);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Pending_Activity.this, Home_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
             }
        });

        // btn site inspection upload
        btn_si_upload=(Button)findViewById(R.id.si_pending);
        btn_si_upload.setVisibility(View.GONE);
        set_siVisibile();
        btn_si_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(connectionDetector.isConnectingToInternet()) {
                    if (setCount() > 0) {
                        new StartProgressBar().execute();
                    } else {
                        //Toast.makeText(Pending_Activity.this, "There is no pending record", Toast.LENGTH_SHORT).show();
                        final Dialog dialog = new Dialog(Pending_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        // set the custom dialog components - text, image and button
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("There is no pending record");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });

                        dialog.show();

                        Intent i = new Intent(Pending_Activity.this, Home_Activity.class);
                        startActivity(i);
                        overridePendingTransition(R.anim.right_in, R.anim.left_out);
                    }
                }else {
                    //Toast.makeText(Pending_Activity.this, "internet not connected", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("internet not connected");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }

            }
        });


        // btn Receiving upload
        btn_receiving_upload=(Button)findViewById(R.id.receiving);
        btn_receiving_upload.setVisibility(View.GONE);
        set_reiVisibile();
        btn_receiving_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(connectionDetector.isConnectingToInternet()) {
                    if (setCountreceiving() > 0) {
                        new ReceivingProgressBar().execute();
                    } else {
                        //Toast.makeText(Pending_Activity.this, "There is no pending record", Toast.LENGTH_SHORT).show();
                        final Dialog dialog = new Dialog(Pending_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        // set the custom dialog components - text, image and button
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("There is no pending records");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });

                        dialog.show();
                    }
                }else {
                    //Toast.makeText(Pending_Activity.this, "internet not connected", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("internet not connected");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }

            }
        });


        //---------Material issue Inspection---------------------//
        btn_material_upload=(Button)findViewById(R.id.materialid);
        btn_material_upload.setVisibility(View.GONE);
        set_missueVisibile();
        btn_material_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(connectionDetector.isConnectingToInternet()) {
                    if (setCountmissue() > 0) {
                        new missueProgressBar().execute();
                    } else {
                        //Toast.makeText(Pending_Activity.this, "There is no pending record", Toast.LENGTH_SHORT).show();
                        final Dialog dialog = new Dialog(Pending_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        // set the custom dialog components - text, image and button
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("there is no pending records");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });

                        dialog.show();
                    }
                }else {
                    //Toast.makeText(Pending_Activity.this, "internet not connected", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("internet not connected");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }

            }
        });

       //---------Material issue Inspection---------------------//
        btn_workprogress_upload=(Button)findViewById(R.id.workprogress);
        btn_workprogress_upload.setVisibility(View.GONE);
        set_issueVisibile();
        btn_workprogress_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(connectionDetector.isConnectingToInternet()) {
                    if (setCountWork() > 0) {
                        new WorkProgressBar().execute();
                    } else {
                        //Toast.makeText(Pending_Activity.this, "There is no pending record", Toast.LENGTH_SHORT).show();
                        final Dialog dialog = new Dialog(Pending_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        // set the custom dialog components - text, image and button
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("there is no pending records");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });

                        dialog.show();
                    }
                }else {
                    //Toast.makeText(Pending_Activity.this, "internet not connected", Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("internet not connected");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }

            }
        });




    }


    public class StartProgressBar extends AsyncTask<String, String,String> {
        ProgressDialog pd;
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            pd=new ProgressDialog(Pending_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try{
                senddata();
            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            //Log.e("response", response);
            if(connectionDetector.isConnectingToInternet()){
//					Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
            }else{
                //Toast.makeText(getBaseContext(),"Internet not connected",Toast.LENGTH_SHORT).show();
                final Dialog dialog = new Dialog(Pending_Activity.this);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                dialog.setContentView(R.layout.custom);
                // set the custom dialog components - text, image and button
                TextView text = (TextView) dialog.findViewById(R.id.text);
                text.setText("internet not connected");
                Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
            try {
                if(setCount()>0){
                    //Toast.makeText(getBaseContext(),"still records are pending",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("still records are pending");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }else{
                    //Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("send complete records");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }
                //setVisibile();
            } catch (Exception e) {
                // TODO: handle exception
            }
        }
    }


    public void senddata() {
        // TODO Auto-generated method stub
        if(connectionDetector.isConnectingToInternet()){
            try {
                sqLiteAdapter.openToWrite();
                sqLiteAdapter.openToRead();
                //Log.e("firstsenddata", "come into senddata");
                if(sqLiteAdapter.countData()>=25){
                    if(cursor_limit!=null){

                        try {
                            cursor_limit=null;
                        } catch (Exception e) {
                            // TODO: handle exception
                        }
                    }
                    cursor_limit=sqLiteAdapter.getdataFixdata();
                    cursor(cursor_limit);
                    //Log.e("senddata2", ""+cursorPendingData2.getCount());
                }
                else {
                    cursor_all=  sqLiteAdapter.queueAll();
                    cursor(cursor_all);
                    //	Log.e("senddata3", ""+cursorPendingData3.getCount());
                }
            } catch (Exception e) {
                // TODO: handle exception
            }


        }else{
            //Toast.makeText(this, "Internet not connected", Toast.LENGTH_LONG).show();
            final Dialog dialog = new Dialog(Pending_Activity.this);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
            dialog.setContentView(R.layout.custom);
            // set the custom dialog components - text, image and button
            TextView text = (TextView) dialog.findViewById(R.id.text);
            text.setText("internet not connected");
            Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
            // if button is clicked, close the custom dialog
            dialogButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.show();
        }
    }

    public void cursor(Cursor cursorSend)
    {
        if(cursorSend!=null && cursorSend.moveToFirst()){
            do {
                int activity_id=cursorSend.getInt(0);
                String permit_id=cursorSend.getString(1);
                String project=cursorSend.getString(2);
                String geographic=cursorSend.getString(3);
                String subarea_one=cursorSend.getString(4);
                String subarea_two=cursorSend.getString(5);
                String main_item=cursorSend.getString(6);
                String subitem_code=cursorSend.getString(7);
                String uom_no=cursorSend.getString(8);
                String pole_item_yes=cursorSend.getString(9);
                String pole_item_cancel=cursorSend.getString(10);
                String check_input=cursorSend.getString(11);
                String check_na=cursorSend.getString(12);
                String latt=cursorSend.getString(13);
                String longg=cursorSend.getString(14);
                String mobile_time=cursorSend.getString(15);
                String remark=cursorSend.getString(16);
                String pass_rework=cursorSend.getString(17);
                String image1_name=cursorSend.getString(18);
                String image2_name=cursorSend.getString(19);
                String image3_name=cursorSend.getString(20);
                String image4_name=cursorSend.getString(21);
                String image5_name=cursorSend.getString(22);
                String image1=cursorSend.getString(23);
                String image2=cursorSend.getString(24);
                String image3=cursorSend.getString(25);
                String image4=cursorSend.getString(26);
                String image5=cursorSend.getString(27);


                // Log.e("from Cursor", "" + cursorSend.getInt(0));
                try{
                    new PendingData(getBaseContext(),activity_id,permit_id,project,geographic, subarea_one,subarea_two,main_item,subitem_code,uom_no,pole_item_yes,pole_item_cancel,check_input,check_na,
                            latt,longg,mobile_time,remark,pass_rework,image1_name,image2_name,image3_name,image4_name,image5_name,image1,image2,image3,image4,image5).execute();

                }catch(Exception e){}
            } while (cursorSend.moveToNext());
        }else{}
    }


    private int setCount() {
        // TODO Auto-generated method stub
        try {
            sqLiteAdapter.openToRead();
            sqLiteAdapter.openToWrite();
            get_count=sqLiteAdapter.countData();
            Log.e("Count SI", "" + get_count);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return get_count;
    }


    @Override
    public void onBackPressed() {
        //  super.onBackPressed();
        showAlert();
    }


    public void showAlert()
    {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                Pending_Activity.this);

        // set title
        alertDialogBuilder.setTitle("Do you want to quit?");

        // set dialog message
        alertDialogBuilder
                //  .setMessage("Click yes to exit!")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, close
                        // current activity
                        startActivity(new Intent(Pending_Activity.this, Home_Activity.class));

                        //finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, just close
                        // the dialog box and do nothing
                        dialog.cancel();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }





    public class ReceivingProgressBar extends AsyncTask<String, String,String> {
        ProgressDialog pd;
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            pd=new ProgressDialog(Pending_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try{
                senddatareceiving();
            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            //Log.e("response", response);
            if(connectionDetector.isConnectingToInternet()){
//					Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
            }else{
                //Toast.makeText(getBaseContext(),"Internet not connected",Toast.LENGTH_SHORT).show();
                final Dialog dialog = new Dialog(Pending_Activity.this);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                dialog.setContentView(R.layout.custom);
                // set the custom dialog components - text, image and button
                TextView text = (TextView) dialog.findViewById(R.id.text);
                text.setText("internet not connected");
                Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
            try {
                if(setCountreceiving()>0){
                    //Toast.makeText(getBaseContext(),"still records are pending",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("still records are pending");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }else{
                    //Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("send complete records");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }
                //  setVisibile();
            } catch (Exception e) {
                // TODO: handle exception
            }
        }
    }



    public void senddatareceiving() {
        // TODO Auto-generated method stub
        if(connectionDetector.isConnectingToInternet()){
            try {
                sqLiteAdapterReceiving.openToWrite();
                sqLiteAdapterReceiving.openToRead();
                //Log.e("firstsenddata", "come into senddata");
                if(sqLiteAdapterReceiving.countData()>=25){
                    if(cursor_limitreceiving!=null){

                        try {
                            cursor_limitreceiving=null;
                        } catch (Exception e) {
                            // TODO: handle exception
                        }
                    }
                    cursor_limitreceiving=sqLiteAdapterReceiving.getdataFixdata();
                    cursorreceiving(cursor_limitreceiving);

                    //Log.e("senddata2", ""+cursorPendingData2.getCount());

                }
                else {
                    cursor_allreceiving=  sqLiteAdapterReceiving.queueAll();
                    cursorreceiving(cursor_allreceiving);
                    //Log.e("senddata3", "" + cursor_allfactory.getCount());
                }
            } catch (Exception e) {
                // TODO: handle exception
            }


        }else{
            //Toast.makeText(this, "Internet not connected", Toast.LENGTH_LONG).show();
            final Dialog dialog = new Dialog(Pending_Activity.this);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
            dialog.setContentView(R.layout.custom);
            // set the custom dialog components - text, image and button
            TextView text = (TextView) dialog.findViewById(R.id.text);
            text.setText("internet not connected");
            Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
            // if button is clicked, close the custom dialog
            dialogButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.show();
        }
    }

    public void cursorreceiving(Cursor cursorSend)
    {
        if(cursorSend!=null && cursorSend.moveToFirst()){
            do {
                int activity_id=cursorSend.getInt(0);
                String permit_id=cursorSend.getString(1);
                String project=cursorSend.getString(2);
                String cityid=cursorSend.getString(3);
                String receiving_from=cursorSend.getString(4);
                String vendor=cursorSend.getString(5);
                String mzone =cursorSend.getString(6);
                String mcity =cursorSend.getString(7);
                String storeid =cursorSend.getString(8);
                String item=cursorSend.getString(9);
                String qty_doc=cursorSend.getString(10);
                String qty_rec=cursorSend.getString(11);
                String qty_damaged=cursorSend.getString(12);
                String qty_accepted=cursorSend.getString(13);
                String grn_transfer=cursorSend.getString(14);
                String remark=cursorSend.getString(15);
                String latt=cursorSend.getString(16);
                String longg=cursorSend.getString(17);
                String mobile_time=cursorSend.getString(18);
                String image1_name=cursorSend.getString(19);
                String image2_name=cursorSend.getString(20);
                String image3_name=cursorSend.getString(21);
                String image4_name=cursorSend.getString(22);
                String image5_name=cursorSend.getString(23);
                String image1=cursorSend.getString(24);
                String image2=cursorSend.getString(25);
                String image3=cursorSend.getString(26);
                String image4=cursorSend.getString(27);
                String image5=cursorSend.getString(28);

                // Log.e("from Cursor", "" + cursorSend.getInt(0));
                try{
                    new ReceivingPendingData(getBaseContext(),activity_id,permit_id,project, cityid, receiving_from,vendor,mzone,mcity,
                            storeid,item,qty_doc,qty_rec,qty_damaged,qty_accepted,grn_transfer,remark,
                            latt,longg,mobile_time,image1_name,image2_name,image3_name,image4_name,image5_name,image1,image2,image3,image4,image5).execute();
                }catch(Exception e){}
            } while (cursorSend.moveToNext());
        }else{}
    }


    private int setCountreceiving() {
        // TODO Auto-generated method stub
        try {
            sqLiteAdapterReceiving.openToRead();
            sqLiteAdapterReceiving.openToWrite();
            get_countreceiving=sqLiteAdapterReceiving.countData();
            Log.e("Count Receiving", "" + get_countreceiving);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return get_countreceiving;
    }







    //--------------material issue --------------------------//

    public class missueProgressBar extends AsyncTask<String, String,String> {
        ProgressDialog pd;
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            pd=new ProgressDialog(Pending_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try{
                senddatamissue();
            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            //Log.e("response", response);
            if(connectionDetector.isConnectingToInternet()){
//					Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
            }else{
                //Toast.makeText(getBaseContext(),"Internet not connected",Toast.LENGTH_SHORT).show();
                final Dialog dialog = new Dialog(Pending_Activity.this);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                dialog.setContentView(R.layout.custom);
                // set the custom dialog components - text, image and button
                TextView text = (TextView) dialog.findViewById(R.id.text);
                text.setText("internet not connected");
                Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
            try {
                if(setCountmissue()>0){
                    //Toast.makeText(getBaseContext(),"still records are pending",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("still records are pending");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }else{
                    //Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("send complete records");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }
                //  setVisibile();
            } catch (Exception e) {
                // TODO: handle exception
            }
        }
    }



    public void senddatamissue() {
        // TODO Auto-generated method stub
        if(connectionDetector.isConnectingToInternet()){
            try {
                sqLiteAdapterMaterial.openToWrite();
                sqLiteAdapterMaterial.openToRead();
                //Log.e("firstsenddata", "come into senddata");
                if(sqLiteAdapterMaterial.countData()>=25){
                    if(cursor_limitmissue!=null){

                        try {
                            cursor_limitmissue=null;
                        } catch (Exception e) {
                            // TODO: handle exception
                        }
                    }
                    cursor_limitmissue=sqLiteAdapterMaterial.getdataFixdata();
                    cursormissue(cursor_limitmissue);

                    //Log.e("senddata2", ""+cursorPendingData2.getCount());

                }
                else {
                    cursor_allmissue=  sqLiteAdapterMaterial.queueAll();
                    cursormissue(cursor_allmissue);
                    //Log.e("senddata3", "" + cursor_allfactory.getCount());
                }
            } catch (Exception e) {
                // TODO: handle exception
            }


        }else{
            //Toast.makeText(this, "Internet not connected", Toast.LENGTH_LONG).show();
            final Dialog dialog = new Dialog(Pending_Activity.this);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
            dialog.setContentView(R.layout.custom);
            // set the custom dialog components - text, image and button
            TextView text = (TextView) dialog.findViewById(R.id.text);
            text.setText("internet not connected");
            Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
            // if button is clicked, close the custom dialog
            dialogButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.show();
        }
    }

    public void cursormissue(Cursor cursorSend)
    {
        if(cursorSend!=null && cursorSend.moveToFirst()){
            do {
                int activity_id=cursorSend.getInt(0);
                String permit_id=cursorSend.getString(1);
                String project=cursorSend.getString(2);
                String cityid=cursorSend.getString(3);
                String receiving_from=cursorSend.getString(4);
                String vendor=cursorSend.getString(5);
                String mzone =cursorSend.getString(6);
                String mcity =cursorSend.getString(7);
                String storeid =cursorSend.getString(8);
                String item=cursorSend.getString(9);
                String qty_transfer=cursorSend.getString(10);
                String grn_transfer=cursorSend.getString(11);
                String remark=cursorSend.getString(12);
                String latt=cursorSend.getString(13);
                String longg=cursorSend.getString(14);
                String mobile_time=cursorSend.getString(15);
                String image1_name=cursorSend.getString(16);
                String image2_name=cursorSend.getString(17);
                String image3_name=cursorSend.getString(18);
                String image4_name=cursorSend.getString(19);
                String image5_name=cursorSend.getString(20);
                String image1=cursorSend.getString(21);
                String image2=cursorSend.getString(22);
                String image3=cursorSend.getString(23);
                String image4=cursorSend.getString(24);
                String image5=cursorSend.getString(25);

                Log.e("from Cursor", "" + cursorSend.getInt(0));
                try{
                    new MaterialPendingData(getBaseContext(),activity_id,permit_id,project, cityid, receiving_from,vendor,mzone,mcity,
                            storeid,item,qty_transfer,grn_transfer,remark,
                            latt,longg,mobile_time,image1_name,image2_name,image3_name,image4_name,image5_name,image1,image2,image3,image4,image5).execute();
                }catch(Exception e){}
            } while (cursorSend.moveToNext());
        }else{}
    }


    private int setCountmissue() {
        // TODO Auto-generated method stub
        try {
            sqLiteAdapterMaterial.openToRead();
            sqLiteAdapterMaterial.openToWrite();
            get_countmissue=sqLiteAdapterMaterial.countData();
            Log.e("Count Material issue", "" + get_countmissue);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return get_countmissue;
    }


    //--------------for issue----------------------------//

    //--------------material issue --------------------------//

    public class WorkProgressBar extends AsyncTask<String, String,String> {
        ProgressDialog pd;
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            pd=new ProgressDialog(Pending_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try{
                senddatawork();
            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            //Log.e("response", response);
            if(connectionDetector.isConnectingToInternet()){
//					Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
            }else{
                //Toast.makeText(getBaseContext(),"Internet not connected",Toast.LENGTH_SHORT).show();
                final Dialog dialog = new Dialog(Pending_Activity.this);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                dialog.setContentView(R.layout.custom);
                // set the custom dialog components - text, image and button
                TextView text = (TextView) dialog.findViewById(R.id.text);
                text.setText("internet not connected");
                Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
            try {
                if(setCountWork()>0){
                    //Toast.makeText(getBaseContext(),"still records are pending",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("still records are pending");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }else{
                    //Toast.makeText(getBaseContext(),"send complete records",Toast.LENGTH_SHORT).show();
                    final Dialog dialog = new Dialog(Pending_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("send complete records");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                }
                //  setVisibile();
            } catch (Exception e) {
                // TODO: handle exception
            }
        }
    }



    public void senddatawork() {
        // TODO Auto-generated method stub
        if(connectionDetector.isConnectingToInternet()){
            try {
                sqLiteAdapterWork.openToWrite();
                sqLiteAdapterWork.openToRead();
                //Log.e("firstsenddata", "come into senddata");
                if(sqLiteAdapterWork.countData()>=25){
                    if(cursor_limitwork!=null){

                        try {
                            cursor_limitwork=null;
                        } catch (Exception e) {
                            // TODO: handle exception
                        }
                    }
                    cursor_limitwork=sqLiteAdapterWork.getdataFixdata();
                    cursorwork(cursor_limitwork);

                    //Log.e("senddata2", ""+cursorPendingData2.getCount());

                }
                else {
                    cursor_allwork=  sqLiteAdapterWork.queueAll();
                    cursorwork(cursor_allwork);
                    //Log.e("senddata3", "" + cursor_allfactory.getCount());
                }
            } catch (Exception e) {
                // TODO: handle exception
            }


        }else{
            //Toast.makeText(this, "Internet not connected", Toast.LENGTH_LONG).show();
            final Dialog dialog = new Dialog(Pending_Activity.this);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
            dialog.setContentView(R.layout.custom);
            // set the custom dialog components - text, image and button
            TextView text = (TextView) dialog.findViewById(R.id.text);
            text.setText("internet not connected");
            Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
            // if button is clicked, close the custom dialog
            dialogButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.show();
        }
    }

    public void cursorwork(Cursor cursorSend)
    {
        if(cursorSend!=null && cursorSend.moveToFirst()){
            do {
                int activity_id=cursorSend.getInt(0);
                String permit_id=cursorSend.getString(1);
                String project=cursorSend.getString(2);
                String in_out_id=cursorSend.getString(3);
                String zone_id=cursorSend.getString(4);
                String city_id=cursorSend.getString(5);
                String g_c_junction =cursorSend.getString(6);
                String junction_id =cursorSend.getString(7);
                String issue_id =cursorSend.getString(8);
                String other_issue=cursorSend.getString(9);
                String remark=cursorSend.getString(10);


                Log.e("from Cursor", "" + cursorSend.getInt(0));
                try{
                    new WorkProgressPendingData(getBaseContext(),activity_id,permit_id,project, in_out_id, zone_id,city_id,g_c_junction,junction_id,
                            issue_id,other_issue,remark).execute();
                }catch(Exception e){}
            } while (cursorSend.moveToNext());
        }else{}
    }


    private int setCountWork() {
        // TODO Auto-generated method stub
        try {
            sqLiteAdapterWork.openToRead();
            sqLiteAdapterWork.openToWrite();
            get_countwork=sqLiteAdapterWork.countData();
            Log.e("Count issue", "" + get_countwork);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return get_countwork;
    }







    //---------------for button visiblity---------------------------//
private void set_siVisibile() {
    sqLiteAdapter.openToRead();
    sqLiteAdapter.openToWrite();
    int pending_int = 0;
    pending_int = sqLiteAdapter.countData();
    sqLiteAdapter.close();

    if (pending_int > 0 ) {
        btn_si_upload.setVisibility(View.VISIBLE);
    } else {
        btn_si_upload.setVisibility(View.INVISIBLE);
        btn_si_upload.setVisibility(View.GONE);
    }
  }



    private void set_reiVisibile() {
        sqLiteAdapterReceiving.openToRead();
        sqLiteAdapterReceiving.openToWrite();
        int pending_fint = 0;
        pending_fint = sqLiteAdapterReceiving.countData();
        sqLiteAdapterReceiving.close();

        if (pending_fint > 0 ) {
            btn_receiving_upload.setVisibility(View.VISIBLE);
        } else {
            btn_receiving_upload.setVisibility(View.INVISIBLE);
            btn_receiving_upload.setVisibility(View.GONE);
        }
    }



    private void set_missueVisibile() {
        sqLiteAdapterMaterial.openToRead();
        sqLiteAdapterMaterial.openToWrite();
        int pending_missueint = 0;
        pending_missueint = sqLiteAdapterMaterial.countData();
        sqLiteAdapterMaterial.close();

        if (pending_missueint > 0 ) {
            btn_material_upload.setVisibility(View.VISIBLE);
        } else {
            btn_material_upload.setVisibility(View.INVISIBLE);
            btn_material_upload.setVisibility(View.GONE);
        }
    }



    private void set_issueVisibile() {
        sqLiteAdapterWork.openToRead();
        sqLiteAdapterWork.openToWrite();
        int pending_issueint = 0;
        pending_issueint = sqLiteAdapterWork.countData();
        sqLiteAdapterWork.close();

        if (pending_issueint > 0 ) {
            btn_workprogress_upload.setVisibility(View.VISIBLE);
        } else {
            btn_workprogress_upload.setVisibility(View.INVISIBLE);
            btn_workprogress_upload.setVisibility(View.GONE);
        }
    }





}
