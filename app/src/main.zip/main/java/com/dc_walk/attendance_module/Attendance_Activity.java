package com.dc_walk.attendance_module;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dc_walk.Home_Activity;
import com.dc_walk.Pending_Activity;
import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.location.FusedLocationService;
import com.dc_walk.service.BackgroundService;
import com.dc_walk.service.CaptureService;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;

import com.dc_walk.sqlite_adapter.SQLiteAdapterIssue;
import com.dc_walk.sqlite_adapter.SQLiteAdapterMaterialIssued;
import com.dc_walk.sqlite_adapter.SQLiteAdapterReceiving;


import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by nitinb on 27-01-2016.
 */
public class Attendance_Activity extends Activity {

    FrameLayout pendingholder;
    ImageButton btn_punchIn, btn_punchOut;
    Button back_btn, pending_btn;
    ConnectionDetector connectionDetector;
    String internet_interrupt = null;

    Location mLocation = null;
    FusedLocationService fusedLocationService;
    String sending_latt, sending_longg;
    String permit_id, str_timestamp;

    double latt, longg;
    String response;
    ProgressDialog pd;

    SessionManager sessionManager;
    SQLiteAdapter1 sqLiteAdapter;
    SQLiteAdapterReceiving sqLiteAdapterReceiving;
    SQLiteAdapterMaterialIssued sqLiteAdapterMaterial;

    SQLiteAdapterIssue sqLiteAdapterIssue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendance);

        sqLiteAdapter=new SQLiteAdapter1(Attendance_Activity.this);

        sqLiteAdapterReceiving=new SQLiteAdapterReceiving(Attendance_Activity.this);
        sqLiteAdapterMaterial =new SQLiteAdapterMaterialIssued(Attendance_Activity.this);

        sqLiteAdapterIssue =new SQLiteAdapterIssue(Attendance_Activity.this);

        back_btn = (Button) findViewById(R.id.backpageId2);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               /* Intent i = new Intent(Attendance_Activity.this, Home_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });

        fusedLocationService = new FusedLocationService(this);
        mLocation = fusedLocationService.getLocation();
        connectionDetector = new ConnectionDetector(Attendance_Activity.this);
        sessionManager = new SessionManager(Attendance_Activity.this);
        permit_id = sessionManager.GET_EMP_ID();

        pendingholder=(FrameLayout)findViewById(R.id.pendingholder);
        pending_btn = (Button) findViewById(R.id.pending);
        //pending_btn.setVisibility(View.INVISIBLE);
        pendingholder.setVisibility(View.GONE);
        pending_btn.setVisibility(View.GONE);
        setVisibile();
        pending_btn = (Button) findViewById(R.id.pending);
        pending_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //ShowAlert();

                Intent i = new Intent(Attendance_Activity.this, Pending_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);

            }
        });

        //------------ For Punch In Button--------------------------//
        btn_punchIn = (ImageButton) findViewById(R.id.punch_in);
        btn_punchIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isMockSettingsON(getApplicationContext()) == false) {
                    mLocation = fusedLocationService.getLocation();

                } else {
                    showAlertMock();
                }

                mLocation = fusedLocationService.getLocation();
                str_timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                if (mLocation != null) {
                    if (connectionDetector.isConnectingToInternet()) {
                        final Dialog dialog = new Dialog(Attendance_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText(" Are you Sure to Punch In ");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        Button dialogButtonNO = (Button) dialog.findViewById(R.id.dialogButtonNo);
                        dialogButton.setText("Yes");
                        dialogButtonNO.setText("No");
                        dialogButtonNO.setVisibility(View.VISIBLE);
                        // if button is clicked, close the custom dialog
//                        dialogButton.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//                                dialog.dismiss();
//                                // reworkclicked = true;
//                                new SendToServer(mLocation.getLatitude(), mLocation.getLongitude()).execute();
//                                startService();
//
//                            }
//                        });
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                                // reworkclicked = true;
                                new SendToServer(mLocation.getLatitude(), mLocation.getLongitude()).execute();
                                startService();
/*
                                Intent intent = new Intent(Attendance_Activity.this, AttendanceService.class);
                                startService(intent);*/

                            }
                        });
                        dialogButtonNO.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();

                            }
                        });

                        dialog.show();

                        //new SendToServer().execute();


                    } else {
                        // custom dialog
                        final Dialog dialog = new Dialog(Attendance_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.CENTER);
                        dialog.setContentView(R.layout.custom);
//                              dialog.setTitle("Title...");

                        // set the custom dialog components - text, image and button
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("Internet Not connecting");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();

                            }
                        });

                        dialog.show();
//                        Toast.makeText(getApplicationContext(), "record saved", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    // ShowAlertagain();

                    final Dialog dialog = new Dialog(Attendance_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Do you want to on location Setting?");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //dialog.dismiss();
                            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivity(intent);
                            dialog.cancel();

                        }
                    });

                    dialog.show();
                }
            }

        });

        //-------For logout Button--------------------------//

        btn_punchOut = (ImageButton) findViewById(R.id.punch_out);
        btn_punchOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isMockSettingsON(getApplicationContext()) == false) {
                    mLocation = fusedLocationService.getLocation();
                } else {
                    showAlertMock();
                }

                mLocation = fusedLocationService.getLocation();
                str_timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                if (mLocation != null) {
                    if (connectionDetector.isConnectingToInternet()) {
                        final Dialog dialog = new Dialog(Attendance_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        dialog.setContentView(R.layout.custom);
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText(" Are you Sure to Punch Out ");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        Button dialogButtonNO = (Button) dialog.findViewById(R.id.dialogButtonNo);
                        dialogButton.setText("Yes");
                        dialogButtonNO.setText("No");
                        dialogButtonNO.setVisibility(View.VISIBLE);
                        // if button is clicked, close the custom dialog
//                        dialogButton.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//                                dialog.dismiss();
//                                // reworkclicked = true;
//                                new SendToServerPunchOut(mLocation.getLatitude(), mLocation.getLongitude()).execute();
//                                stopService();
//
//                            }
//                        });

                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                                // reworkclicked = true;
                                new SendToServerPunchOut(mLocation.getLatitude(), mLocation.getLongitude()).execute();
                                stopService();

                            }
                        });
                        dialogButtonNO.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();

                            }
                        });

                        dialog.show();
                        //Log.e("Latitude", "" + mLocation.getLatitude());
                        //Log.e("Longitude", "" + mLocation.getLongitude());
                        //new SendToServerPunchOut(mLocation.getLatitude(), mLocation.getLongitude()).execute();
                        //new SendToServer().execute();


                    } else {
                        final Dialog dialog = new Dialog(Attendance_Activity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.CENTER);
                        dialog.setContentView(R.layout.custom);
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("Internet Not connecting");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();

                            }
                        });

                        dialog.show();

                    }

                } else {
                    //ShowAlertagain();
                    final Dialog dialog = new Dialog(Attendance_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Do you want to on location Setting?");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //dialog.dismiss();
                            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivity(intent);
                            dialog.cancel();

                        }
                    });

                    dialog.show();
                }
            }

        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }

    //------------ For pending data----------------//
    private void setVisibile() {
        sqLiteAdapter.openToRead();
        sqLiteAdapter.openToWrite();
        int pending_int = 0;
        pending_int = sqLiteAdapter.countData();
        sqLiteAdapter.close();


        sqLiteAdapterReceiving.openToRead();
        sqLiteAdapterReceiving.openToWrite();
        int rpending_int = 0;
        rpending_int = sqLiteAdapterReceiving.countData();
        sqLiteAdapterReceiving.close();


        sqLiteAdapterMaterial.openToRead();
        sqLiteAdapterMaterial.openToWrite();
        int materialpending_int = 0;
        materialpending_int = sqLiteAdapterMaterial.countData();
        sqLiteAdapterMaterial.close();

        sqLiteAdapterIssue.openToRead();
        sqLiteAdapterIssue.openToWrite();
        int issuepending_int = 0;
        issuepending_int = sqLiteAdapterIssue.countData();
        sqLiteAdapterIssue.close();


        // if (pending_int > 0) {

        if (pending_int > 0 ||rpending_int > 0 || materialpending_int > 0 || issuepending_int > 0) {
            pending_btn.setVisibility(View.VISIBLE);
            pendingholder.setVisibility(View.VISIBLE);

            Intent intent = new Intent(Attendance_Activity.this, BackgroundService.class);
            startService(intent);
        } else {
            pending_btn.setVisibility(View.INVISIBLE);
            pending_btn.setVisibility(View.GONE);
            pendingholder.setVisibility(View.GONE);
        }
    }



    public void ShowAlert() {
        Attendance_Activity.this.runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(Attendance_Activity.this);
                builder.setTitle("Enter Pin");
                final EditText input = new EditText(Attendance_Activity.this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                input.setLayoutParams(lp);
                builder.setView(input)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog1, int id) {
                                permit_id = input.getText().toString().trim();
                                if (permit_id.equalsIgnoreCase("3003")) {

                                    Intent i = new Intent(Attendance_Activity.this, Pending_Activity.class);
                                    startActivity(i);
                                    overridePendingTransition(R.anim.right_in, R.anim.left_out);

                                } else {
                                    //Toast.makeText(getApplicationContext(), "Permit id is not valid", Toast.LENGTH_SHORT).show();
                                    // custom dialog
                                    final Dialog dialog = new Dialog(Attendance_Activity.this);
                                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                                    dialog.setContentView(R.layout.custom);
                                    TextView text = (TextView) dialog.findViewById(R.id.text);
                                    text.setText("Pending id is not valid");
                                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                                    // if button is clicked, close the custom dialog
                                    dialogButton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            dialog.dismiss();


                                        }
                                    });

                                    dialog.show();
                                }

                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }


    //-------------------for coordinates setting  ----------------------------------------------//

    public static boolean isMockSettingsON(Context context) {
        // returns true if mock location enabled, false if not enabled.
        if (Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ALLOW_MOCK_LOCATION).equals("0"))
            return false;
        else
            return true;
    }

    public void ShowAlertagain() {
        if (!isLocationServiceEnabled()) {
            // Toast.makeText(getApplicationContext(), "please wait while location is fetching", Toast.LENGTH_SHORT).show();

            runOnUiThread(new Runnable() {
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Attendance_Activity.this);
                    builder.setMessage("Do you want to Continue without location?");
                    builder.setCancelable(true);
                    builder.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    latt = 0;
                                    longg = 0;
                                    if (connectionDetector.isConnectingToInternet()) {
                                        new SendToServer(latt, longg).execute();
                                    } else {

                                    }
                                    dialog.cancel();
                                }
                            });
                    builder.setNegativeButton("SETTINGS",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    startActivity(intent);
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
        } else {

            //   Log.e("Latitude", "" + mLocation.getLatitude());
            //   Log.e("Longitude", "" + mLocation.getLongitude());
        }
    }


    public void showAlertMock() {


        AlertDialog.Builder builder = new AlertDialog.Builder(Attendance_Activity.this);
        builder.setMessage("Please OFF Mock Location from setting");
        //builder.setCancelable(true);


        builder
                //  .setMessage("Click yes to exit!")
                .setCancelable(true)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, close
                        // current activity
                        startActivity(new Intent(Attendance_Activity.this, Home_Activity.class));
                        Attendance_Activity.this.finish();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();

    }


    public boolean isLocationServiceEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = lm.getBestProvider(new Criteria(), true).trim();
        //  Log.e("provider" ,""+provider);
        //  Log.e("LocationManager" ,""+lm);
        return (provider != null &&
                !LocationManager.PASSIVE_PROVIDER.equals(provider));
    }


    //---------- for sending punch in data to the server------------------//

    public class SendToServer extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        // public SendToServer() {
        public SendToServer(Double latitude, Double longitude) {
            // TODO Auto-generated constructor stub
            sending_latt = String.valueOf(latitude);
            sending_longg = String.valueOf(longitude);
//            Log.e("from", "sendtoserver");
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Attendance_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/demo_jackson/embc_app/insert_punch_in");
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    // httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    nameValuePairs.add(new BasicNameValuePair("permit_id", sessionManager.GET_EMP_ID()));
                    nameValuePairs.add(new BasicNameValuePair("mobile_date", str_timestamp));
                    nameValuePairs.add(new BasicNameValuePair("latt", sending_latt));
                    nameValuePairs.add(new BasicNameValuePair("longg", sending_longg));

                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    Log.e("name value pair", "" + nameValuePairs);
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpclient.execute(httppost, responseHandler);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("response", "" + response);
                    //   Log.e("response", response + "+" + e.getMessage().toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();

            try {
                response = response.trim();
                Log.e("response", "" + response);
                response = response.trim();

                if (response != null && response.equals("1")) {

                    // custom dialog
                    final Dialog dialog = new Dialog(Attendance_Activity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL| Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
//                              dialog.setTitle("Title...");

                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText(" Punch In Marked ");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            pd.hide();
                            pd.dismiss();
                            dialog.dismiss();
                            startActivity(new Intent(Attendance_Activity.this, Home_Activity.class));
                            finish();


                        }
                    });

                    dialog.show();


                } else {

                    // Toast.makeText(getApplicationContext(), "record saved due to server error", Toast.LENGTH_SHORT).show();

                }
            } catch (Exception e) {
                //Toast.makeText(getApplicationContext(), "Due to low internet connectivity this data would be saved in database", Toast.LENGTH_SHORT).show();
                response = null;
                Log.e("response exception", "" + e.getMessage());
            }
            response = null;
        }

    }

    //---------- for sending Punch Out data to the server------------------//

    public class SendToServerPunchOut extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        // public SendToServer() {
        public SendToServerPunchOut(Double latitude, Double longitude) {
            // TODO Auto-generated constructor stub
            sending_latt = String.valueOf(latitude);
            sending_longg = String.valueOf(longitude);
//            Log.e("from", "sendtoserver");
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Attendance_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                try {
                    HttpClient httpclient = new DefaultHttpClient();


                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/demo_jackson/embc_app/punch_out");
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    // httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    nameValuePairs.add(new BasicNameValuePair("permit_id", sessionManager.GET_EMP_ID()));
                    nameValuePairs.add(new BasicNameValuePair("mobile_date", str_timestamp));
                    nameValuePairs.add(new BasicNameValuePair("latt", sending_latt));
                    nameValuePairs.add(new BasicNameValuePair("longg", sending_longg));

                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    Log.e("name value pair", "" + nameValuePairs);
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpclient.execute(httppost, responseHandler);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("response", "" + response);
                    //   Log.e("response", response + "+" + e.getMessage().toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
//              Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
            try {

                if (response != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(response);

                        // Getting JSON Array node
                        JSONArray contacts = jsonObj.getJSONArray("resp");

                        int fileLength = contacts.length();

                        // for (int i = 0; i < contacts.length(); i++) {

                        if (fileLength == 0) {
                            //Toast.makeText(getApplicationContext(), " device not configured ", Toast.LENGTH_LONG).show();

                        } else {
                            JSONObject c = contacts.getJSONObject(0);
                            String total_survey = c.getString("total_survey");
                            String total_time = c.getString("total_time");

                            // custom dialog
                            final Dialog dialog = new Dialog(Attendance_Activity.this);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                            dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL| Gravity.CENTER_VERTICAL);
                            dialog.setContentView(R.layout.custom);
//                              dialog.setTitle("Title...");

                            // set the custom dialog components - text, image and button
                            TextView text = (TextView) dialog.findViewById(R.id.text);
                            //text.setText("Total Survey: " + total_survey.toString() + " and  Total working hours " + total_time.toString() + "hrs");
                            text.setText("Punch Out Successfully");
                            Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                            // if button is clicked, close the custom dialog
                            dialogButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    pd.hide();
                                    pd.dismiss();
                                    dialog.dismiss();
                                    Intent intent = new Intent(getApplicationContext(), Home_Activity.class);
                                    startActivity(intent);
                                    finish();

                                }
                            });

                            dialog.show();

                        }
                        // }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        //Toast.makeText(getApplicationContext(), " device not configured ", Toast.LENGTH_LONG).show();
                        finish();
                    }
                } else {
                    //  Log.e("ServiceHandler", "Couldn't get any data from the url");
                }

            } catch (Exception e) {

                // Toast.makeText(getApplicationContext(), "please try again", Toast.LENGTH_LONG).show();
                finish();
            }
        }



    }


    //--------------------- Alert for Logout---------------------//
/*

    @Override
    public void onBackPressed() {
        //  super.onBackPressed();
        showAlert();
    }


    public void showAlert() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                Attendance_Activity.this);

        // set title
        alertDialogBuilder.setTitle("Do you want to logout?");

        // set dialog message
        alertDialogBuilder
                //  .setMessage("Click yes to exit!")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, close
                        // current activity
                        startActivity(new Intent(Attendance_Activity.this, Home_Activity.class));
                        Attendance_Activity.this.finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, just close
                        // the dialog box and do nothing
                        dialog.cancel();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }
*/


    public void startService() {
        startService(new Intent(getBaseContext(), CaptureService.class));
    }

    // Method to stop the service
    public void stopService() {
        stopService(new Intent(getBaseContext(), CaptureService.class));
    }

}