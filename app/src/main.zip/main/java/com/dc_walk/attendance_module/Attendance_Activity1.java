package com.dc_walk.attendance_module;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.location.FusedLocationService;
import com.dc_walk.service.CaptureService;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class Attendance_Activity1 extends Activity {

    private static int flag=0;

    ImageButton btn_punchIn,btn_punchOut;

    ConnectionDetector connectionDetector;
    String internet_interrupt = null;
    Location mLocation = null;
    FusedLocationService fusedLocationService;
    String sending_latt, sending_longg;
    String permit_id, str_timestamp;
    double latt, longg;
    String response;
    ProgressDialog pd;
    //SessionManager sessionManager;

    Timer timer;
    TimerTask timerTask;

    //we are going to use a handler to be able to run in our TimerTask
    final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendance);

        fusedLocationService = new FusedLocationService(this);
        mLocation = fusedLocationService.getLocation();
        connectionDetector = new ConnectionDetector(Attendance_Activity1.this);

        btn_punchIn = (ImageButton) findViewById(R.id.punch_in);
        btn_punchIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(), "Punch In successfully", Toast.LENGTH_SHORT).show();

                //startTimer();

                startService();

            }

        });

        if(flag == 1)
        {
            this.finish();
            flag=0;
        }
        btn_punchOut = (ImageButton) findViewById(R.id.punch_out);
        btn_punchOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isMockSettingsON(getApplicationContext()) == false) {
                    mLocation = fusedLocationService.getLocation();
                } else {
                    showAlertMock();
                }

                mLocation = fusedLocationService.getLocation();
                str_timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                if (mLocation != null) {
                    if (connectionDetector.isConnectingToInternet()) {
                        //Log.e("Latitude", "" + mLocation.getLatitude());
                        //Log.e("Longitude", "" + mLocation.getLongitude());
                        new SendToServerPunchOut(mLocation.getLatitude(), mLocation.getLongitude()).execute();
                        //new SendToServer().execute();
                        stopService();


                    } else {
                        final Dialog dialog = new Dialog(Attendance_Activity1.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        dialog.getWindow().setGravity(Gravity.CENTER);
                        dialog.setContentView(R.layout.custom);
                        TextView text = (TextView) dialog.findViewById(R.id.text);
                        text.setText("Internet Not connecting");
                        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                        // if button is clicked, close the custom dialog
                        dialogButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();

                            }
                        });

                        dialog.show();

                    }

                } else {
                    //ShowAlertagain();
                    final Dialog dialog = new Dialog(Attendance_Activity1.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER);
                    dialog.setContentView(R.layout.custom);
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Do you want to on location Setting?");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //dialog.dismiss();
                            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivity(intent);
                            dialog.cancel();

                        }
                    });

                    dialog.show();
                }
            }

        });

    }

   /* @Override
    protected void onResume() {
        super.onResume();

        //onResume we start our timer so it can start when the app comes from the background

                startTimer();
            //new SendToServer().execute();

    }
  */

    public void startTimer() {
        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask();

        //schedule the timer, after the first 5000ms the TimerTask will run every 10000ms
        //timer.schedule(timerTask, 5000, 10000); //
        timer.schedule(timerTask, 5000, 60000); //
    }

    public void stoptimertask(View v) {
        //stop the timer, if it's not already null
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    public void initializeTimerTask() {

        timerTask = new TimerTask() {
            public void run() {

                //use a handler to run a toast that shows the current timestamp
                handler.post(new Runnable() {
                    public void run() {

                       /* Calendar calendar = Calendar.getInstance();
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd:MMMM:yyyy HH:mm:ss a");
                        String strDate = simpleDateFormat.format(calendar.getTime());*/


                        str_timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                        mLocation = fusedLocationService.getLocation();
                        sending_latt = String.valueOf(mLocation.getLatitude());
                        sending_longg = String.valueOf(mLocation.getLongitude());
                        String tview = "Lat:" + sending_latt + "    Long:" + sending_longg + "   Time:" + str_timestamp;
                        new SendToServer(mLocation.getLatitude(), mLocation.getLongitude()).execute();

                    }
                });
            }
        };
    }

    //---------- for sending punch in data to the server------------------//

    public class SendToServer extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        // public SendToServer() {
        public SendToServer(Double latitude, Double longitude) {
            // TODO Auto-generated constructor stub
            sending_latt = String.valueOf(latitude);
            sending_longg = String.valueOf(longitude);
//            Log.e("from", "sendtoserver");
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Attendance_Activity1.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/DEMO_DCNINE/embc_app/insert_punch_track");
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    // httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    nameValuePairs.add(new BasicNameValuePair("permit_id","3003"));
                    nameValuePairs.add(new BasicNameValuePair("mobile_date", str_timestamp));
                    nameValuePairs.add(new BasicNameValuePair("latt", sending_latt));
                    nameValuePairs.add(new BasicNameValuePair("longg", sending_longg));

                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    Log.e("name value pair", "" + nameValuePairs);
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpclient.execute(httppost, responseHandler);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("response", "" + response);
                    //   Log.e("response", response + "+" + e.getMessage().toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();

            try {
                response = response.trim();
                Log.e("response", "" + response);
                response = response.trim();

                if (response != null && response.equals("1")) {

                    //Toast.makeText(getApplicationContext(), "Punch In successfully", Toast.LENGTH_SHORT).show();




                } else {

                    // Toast.makeText(getApplicationContext(), "record saved due to server error", Toast.LENGTH_SHORT).show();


                }
            } catch (Exception e) {
                //Toast.makeText(getApplicationContext(), "Due to low internet connectivity this data would be saved in database", Toast.LENGTH_SHORT).show();
                response = null;
                Log.e("response exception", "" + e.getMessage());
            }
            response = null;
        }

    }

    public static boolean isMockSettingsON(Context context) {
        // returns true if mock location enabled, false if not enabled.
        if (Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ALLOW_MOCK_LOCATION).equals("0"))
            return false;
        else
            return true;
    }

    public void ShowAlertagain() {
        if (!isLocationServiceEnabled()) {
            // Toast.makeText(getApplicationContext(), "please wait while location is fetching", Toast.LENGTH_SHORT).show();

            runOnUiThread(new Runnable() {
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Attendance_Activity1.this);
                    builder.setMessage("Do you want to Continue without location?");
                    builder.setCancelable(true);
                    builder.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    latt = 0;
                                    longg = 0;
                                    if (connectionDetector.isConnectingToInternet()) {
                                        new SendToServer(latt, longg).execute();
                                    } else {

                                    }
                                    dialog.cancel();
                                }
                            });
                    builder.setNegativeButton("SETTINGS",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    startActivity(intent);
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
        } else {

            //   Log.e("Latitude", "" + mLocation.getLatitude());
            //   Log.e("Longitude", "" + mLocation.getLongitude());
        }
    }


    public void showAlertMock() {


        AlertDialog.Builder builder = new AlertDialog.Builder(Attendance_Activity1.this);
        builder.setMessage("Please OFF Mock Location from setting");
        //builder.setCancelable(true);


        builder
                //  .setMessage("Click yes to exit!")
                .setCancelable(true)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, close
                        // current activity
                        startActivity(new Intent(Attendance_Activity1.this, Attendance_Activity1.class));
                        Attendance_Activity1.this.finish();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();

    }


    public boolean isLocationServiceEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = lm.getBestProvider(new Criteria(), true).trim();
        //  Log.e("provider" ,""+provider);
        //  Log.e("LocationManager" ,""+lm);
        return (provider != null &&
                !LocationManager.PASSIVE_PROVIDER.equals(provider));
    }



    //--------punch out-------------------------------------------------//
    public class SendToServerPunchOut extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        // public SendToServer() {
        public SendToServerPunchOut(Double latitude, Double longitude) {
            // TODO Auto-generated constructor stub
            sending_latt = String.valueOf(latitude);
            sending_longg = String.valueOf(longitude);
//            Log.e("from", "sendtoserver");
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Attendance_Activity1.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/DEMO_DCNINE/embc_app/insert_punch_track");
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    // httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    nameValuePairs.add(new BasicNameValuePair("permit_id","3003"));
                    nameValuePairs.add(new BasicNameValuePair("mobile_date", str_timestamp));
                    nameValuePairs.add(new BasicNameValuePair("latt", sending_latt));
                    nameValuePairs.add(new BasicNameValuePair("longg", sending_longg));

                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    Log.e("name value pair", "" + nameValuePairs);
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpclient.execute(httppost, responseHandler);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("response", "" + response);
                    //   Log.e("response", response + "+" + e.getMessage().toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            // pd.dismiss();

            try {
                response = response.trim();
                Log.e("response", "" + response);
                response = response.trim();

                if (response != null && response.equals("1")) {

                    // custom dialog
                    final Dialog dialog = new Dialog(Attendance_Activity1.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL| Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
//                              dialog.setTitle("Title...");

                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText(" Punch out Marked ");
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            pd.hide();
                            pd.dismiss();
                            dialog.dismiss();
                            Intent intent = new Intent(Attendance_Activity1.this, Attendance_Activity1.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            finish();
                            flag = 1;
                            startActivity(intent);



                        }
                    });

                    dialog.show();


                } else {

                    // Toast.makeText(getApplicationContext(), "record saved due to server error", Toast.LENGTH_SHORT).show();


                }
            } catch (Exception e) {
                //Toast.makeText(getApplicationContext(), "Due to low internet connectivity this data would be saved in database", Toast.LENGTH_SHORT).show();
                response = null;
                Log.e("response exception", "" + e.getMessage());
            }
            response = null;
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();

    }

    public void startService() {
        startService(new Intent(getBaseContext(), CaptureService.class));
    }

    // Method to stop the service
    public void stopService() {
        stopService(new Intent(getBaseContext(), CaptureService.class));
    }




}