package com.dc_walk.factory_inspection_module;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class FactoryInspection_stage_Activity extends Activity {

    //public String EMP_ID = "emp_id";

    TextView factory_inspection_stage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.factoryinspection_stages);



        // for Factory Inspection item  Activity
        factory_inspection_stage = (TextView) findViewById(R.id.stge1);
        factory_inspection_stage.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(FactoryInspection_stage_Activity.this, FactoryInspection_Item_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);

            }
        });




    }


   /* public void onBackPressed() {
        startActivity(new Intent(ReceivingInspection_Activity.this, Home_Activity.class));
        finish();
        overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }*/




}
