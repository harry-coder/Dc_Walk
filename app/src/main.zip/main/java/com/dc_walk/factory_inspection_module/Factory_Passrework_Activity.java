package com.dc_walk.factory_inspection_module;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class Factory_Passrework_Activity extends Activity {

    LinearLayout alert_pop1;
    Button passbtn,reworkbtn, popok, popcancel;
    TextView poptext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.factory_pass_rework);

        poptext=(TextView)findViewById(R.id.text);
        passbtn=(Button)findViewById(R.id.passId);
        reworkbtn=(Button)findViewById(R.id.reworkId);
        alert_pop1=(LinearLayout)findViewById(R.id.alert_pop1);
        popok=(Button)findViewById(R.id.dialogButtonOK);
        popcancel=(Button)findViewById(R.id.dialogButtonNo);


        passbtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
//                dialogButton.setText("Yes");
//                dialogButtonNO.setText("No");
                alert_pop1.setVisibility(View.VISIBLE);
                poptext.setText("Are you sure you want to pass this inspection ?");
            }
        });
        reworkbtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
//                dialogButton.setText("Yes");
//                dialogButtonNO.setText("No");
                alert_pop1.setVisibility(View.VISIBLE);
                poptext.setText("Are you sure you want to rework this inspection ?");
            }
        });
        popok.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                alert_pop1.setVisibility(View.GONE);
            }
        });
        popcancel.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                alert_pop1.setVisibility(View.GONE);
            }
        });


    }


   /* public void onBackPressed() {
        startActivity(new Intent(ReceivingInspection_Activity.this, Home_Activity.class));
        finish();
        overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }*/




}
