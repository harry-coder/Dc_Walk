package com.dc_walk.factory_inspection_module;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class FactoryInspection_Item_Activity extends Activity {


    Button imageButton7;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.factory_inspection_item);

        imageButton7=(Button)findViewById(R.id.imageButton7);
        imageButton7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(FactoryInspection_Item_Activity.this, Factory_Passrework_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);

            }
        });

    }





}