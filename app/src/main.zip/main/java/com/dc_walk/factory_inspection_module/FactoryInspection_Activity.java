package com.dc_walk.factory_inspection_module;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class FactoryInspection_Activity extends Activity {

    //public String EMP_ID = "emp_id";


    Button back_btn,factory_inspection_item;

    EditText ed_other_rsp, ed_supplier_rsp, ed_vendorResp;
    String str_supplier_rsp, str_other_rsp, str_vendorResp;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.factory_inspection);



     //-------------for back Page-----------------//
        back_btn = (Button) findViewById(R.id.back_btn);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Intent i = new Intent(ReceivingInspection_Activity.this, Home_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });

        // for Factory Inspection item  Activity
        factory_inspection_item = (Button) findViewById(R.id.factinsp1);
        factory_inspection_item.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(FactoryInspection_Activity.this, Factory_Passrework_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);

            }
        });




    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish(); // finish activity
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }
   /* public void onBackPressed() {
        startActivity(new Intent(ReceivingInspection_Activity.this, Home_Activity.class));
        finish();
        overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }*/




}
