package com.dc_walk.selfiecamera;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.util.Base64;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.dc_walk.R;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.data_holder.DataHolder_ReceivingInspection;
import com.dc_walk.data_holder.DataHolder_SiteInspection;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends ActionBarActivity {
	ImageView iv;
	//to call our own custom cam
	private final static int CAMERA_PIC_REQUEST1 = 0;
	Context con;
	int count = 0;
	SessionManager sessionManager;
	String permit_id;
	ImageButton use_picture;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		iv = (ImageView) findViewById(R.id.imageView1);
		con=this;

		sessionManager = new SessionManager(MainActivity.this);
		permit_id= sessionManager.GET_EMP_ID();


		use_picture = (ImageButton) findViewById(R.id.use_picture_button);
		use_picture.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				onBackPressed();

			}
		});


	}

	public void onClick(View view) {
		if (getFrontCameraId() == -1) {
			Toast.makeText(getApplicationContext(),
					"Front Camera Not Detected", Toast.LENGTH_SHORT).show();
		} else {
			Intent cameraIntent = new Intent();
			cameraIntent.setClass(this, CameraActivity.class);
			startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST1);

			// startActivity(new
			// Intent(MainActivity.this,CameraActivity.class));
		}
	}

	int getFrontCameraId() {
		CameraInfo ci = new CameraInfo();
		for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
			Camera.getCameraInfo(i, ci);
			if (ci.facing == CameraInfo.CAMERA_FACING_FRONT)
				return i;
		}
		return -1; // No front-facing camera found
	}

	Bitmap bitmapFrontCam;

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == CAMERA_PIC_REQUEST1) {
			if (resultCode == RESULT_OK) {
				try {

					bitmapFrontCam = (Bitmap) data.getParcelableExtra("BitmapImage");

					/*final Bitmap bitmapunpro = BitmapFactory.decodeFile(fileUri.getPath(),
							options);

					final Bitmap bitmap = getResizedBitmap(BitmapFactory.decodeFile(fileUri.getPath(),
							options), 80, 110);*/

					String lrgbitmapstring;
					ByteArrayOutputStream bytes = new ByteArrayOutputStream();
					bitmapFrontCam.compress(Bitmap.CompressFormat.JPEG, 50, bytes);


					byte[] byteArray = bytes.toByteArray();
					lrgbitmapstring = Base64.encodeToString(byteArray, Base64.DEFAULT);
					if (DataHolder_ReceivingInspection.getInstance().getlrgImg1() == null) {

						DataHolder_SiteInspection.getInstance().setlrgImg6(lrgbitmapstring);
					} else {
						Toast.makeText(getApplicationContext(), "Maximum 1 Images", Toast.LENGTH_LONG).show();
					}




				} catch (Exception e) {
				}
				iv.setImageBitmap(bitmapFrontCam);
				previewCapturedImage(count, bitmapFrontCam);
			}

		} else if (resultCode == RESULT_CANCELED) {
			Toast.makeText(this, "Picture was not taken", Toast.LENGTH_SHORT)
					.show();
		}
	}


	/*
    * Display image from a path to ImageView
   */
	private void previewCapturedImage(int count, Bitmap data) {
		String bitmapstring;
//        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");data
		Bitmap bm = data.copy(Bitmap.Config.RGB_565, true);
//        bitmapstring=bm.toString();
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		data.compress(Bitmap.CompressFormat.JPEG, 50, bytes);
		byte[] byteArray = bytes.toByteArray();
		bitmapstring = Base64.encodeToString(byteArray, Base64.DEFAULT);
		System.out.println("hyyyy" + count);


		System.out.println("AMIN " + DataHolder_SiteInspection.getInstance().getImg6());

		String str_timestamp1 = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(new Date());


		if (DataHolder_SiteInspection.getInstance().getImg6() == null) {
			File destination = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/PMC/",
					permit_id+"_"+str_timestamp1+"."+"jpg");
			DataHolder_SiteInspection.getInstance().setImageNmae6(permit_id+"_"+str_timestamp1+"."+"jpg");
			System.out.println("IMAGE NAME 1 " + permit_id+"_"+str_timestamp1+"."+"jpg");
			FileOutputStream fo;
			try {
				destination.createNewFile();
				fo = new FileOutputStream(destination);
				fo.write(bytes.toByteArray());
				fo.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			DataHolder_SiteInspection.getInstance().setImg6(bitmapstring);
			System.out.println("AMIN1");

		}  else {
			Toast.makeText(getApplicationContext(), "Maximum 1 Images", Toast.LENGTH_LONG).show();
		}


	}


	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.right_in, R.anim.left_out);
	}
	
}
