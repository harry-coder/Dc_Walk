package com.dc_walk.site_inspection;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;

import com.dc_walk.R;
import com.dc_walk.data_holder.DataHolder_SiteInspection;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;

import java.util.ArrayList;

/**
 * Created by nitinb on 29-01-2016.
 */
public class SiteInspection_Item_Activity extends Activity {

    ImageButton pole_btn,cable_btn,dt_btn,conductor_btn,bpl_btn,power_btn,control_btn;
    Button back_btn;
    SQLiteAdapter1 sqLiteAdapter;
    String str_mobile_status_id,str_uom_status;


    ArrayList<String> item_pole_code_list,item_code_list,item_name_list,mobile_status_list,uom_status_list;
    ArrayAdapter<String> item_adapter;
    Cursor item_cursor;

    GridView gridView;
    ArrayList<String> list;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection_item);


        //GridView
        gridView=(GridView) findViewById(R.id.gridView);

        item_pole_code_list=new ArrayList<String>();
        item_code_list=new ArrayList<String>();
        item_name_list=new ArrayList<String>();
        uom_status_list=new ArrayList<String>();
        mobile_status_list=new ArrayList<String>();



        new ChooseItemValue(SiteInspection_Item_Activity.this).execute();

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View v, int position, long arg3) {

                Toast.makeText(getApplicationContext(), uom_status_list.get(position).toString(), Toast.LENGTH_SHORT).show();

                DataHolder_SiteInspection.getInstance().setStr_uom_status(uom_status_list.get(position).toString());
                DataHolder_SiteInspection.getInstance().setItem_mainname(item_name_list.get(position).toString());
                DataHolder_SiteInspection.getInstance().setStr_mainpole(item_code_list.get(position).toString());
                str_mobile_status_id = mobile_status_list.get(position).toString();

                String asset = str_mobile_status_id;
                switch (asset) {
                    case "1":
                        //Toast.makeText(getApplicationContext(), work_description_id, Toast.LENGTH_SHORT).show();

                        Intent i = new Intent(SiteInspection_Item_Activity.this, SiteInspection_SubItem_Activity.class);
                        startActivity(i);
                        overridePendingTransition(R.anim.right_in, R.anim.left_out);

                        break;
                    case "2":
                        //Toast.makeText(getApplicationContext(), work_description_id, Toast.LENGTH_SHORT).show();

                        Intent in = new Intent(SiteInspection_Item_Activity.this, Site_Pole_Check_Activity1.class);
                        startActivity(in);
                        overridePendingTransition(R.anim.right_in, R.anim.left_out);

                        break;
                    default:

                        //Toast.makeText(getApplicationContext(), "not work description", Toast.LENGTH_SHORT).show();
                        Intent inten = new Intent(SiteInspection_Item_Activity.this, Pass_Rework_SiteInspection_Activity.class);
                        overridePendingTransition(R.anim.right_in, R.anim.left_out);
                        startActivity(inten);
                        break;

                }


            }
        });



    }

    @Override
    public void onBackPressed() {

        finish(); // finish activity
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }


    //......................... Item Value ................................................//

    public class ChooseItemValue extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        ChooseItemValue(Context ctx) {_context=ctx;}
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(SiteInspection_Item_Activity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(SiteInspection_Item_Activity.this);
            try {

                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                if(item_cursor!=null){
                    item_cursor=null;
                }

                //item_cursor=sqLiteAdapter.select_item_all();
                item_cursor=sqLiteAdapter.select_supplier_all();
                item_code_list.clear();
                item_name_list.clear();
                uom_status_list.clear();
                mobile_status_list.clear();
                if(item_cursor!=null && item_cursor.moveToFirst()){
                    //item_code_list.add("select");
                    // item_name_list.add("select");
                    do {
                        String code=item_cursor.getString(1);
                        String name=item_cursor.getString(3);
                        String uom_status=item_cursor.getString(4);
                        String mobile_status=item_cursor.getString(6);
                        /*Log.e("code",code);
                        Log.e("name",name);*/
                        item_code_list.add(code);
                        item_name_list.add(name);
                        uom_status_list.add(uom_status);
                        mobile_status_list.add(mobile_status);
                    } while (item_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
                // Log.e("exception",e.getMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
//                item_adapter=new ArrayAdapter<String>(SiteInspection_Item_Activity.this,android.R.layout.simple_spinner_item,item_name_list);
//                item_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                // spinner_block.setAdapter(block_adapter);

                adapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.grid_view,item_name_list);
                gridView.setAdapter(adapter);


                sqLiteAdapter.close();

            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    String[] itemNameArray;
    final ArrayList<String> selectedItemName = new ArrayList<>();
    final ArrayList<String> selectedItemCode = new ArrayList<>();

    protected void showSelectColoursDialog(final ArrayList<String> item_name_list, final ArrayList<String> item_code_list) {

        int count = item_name_list.size();
        itemNameArray=new String[count];

        boolean[] checkedBlockName = new boolean[count];

        for(int i = 0; i < count; i++)
            itemNameArray[i] = item_name_list.get(i);

        for(int i = 0; i < count; i++)
            checkedBlockName[i] = selectedItemName.contains(itemNameArray[i]);

        DialogInterface.OnMultiChoiceClickListener coloursDialogListener = new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                if(isChecked) {
                    selectedItemName.add(itemNameArray[which]);
                    selectedItemCode.add(item_code_list.get(which));
                }
                else {
                    //sl.remove(colours[which]);
                }

            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Item");
        builder.setMultiChoiceItems(itemNameArray, checkedBlockName, coloursDialogListener);

        AlertDialog dialog = builder.create();
        dialog.show();
    }



}
