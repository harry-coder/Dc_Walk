package com.dc_walk.site_inspection;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Criteria;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.data_holder.DataHolder_SiteInspection;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;



/**
 * Created by nitinb on 29-01-2016.
 */
public class Pass_Rework_SiteInspection_Activity extends Activity {

    //ImageButton upload_btn;
    Button back_btn,pass_btn,rework_btn,upload_btn,camera_inspection,finish_btn,ButtonOK,ButtonNO,remark_btn;
    EditText ed_no;
    String response;
    LinearLayout alert_pop1;
    ProgressDialog pd;
    Boolean passclicked=false;
    Boolean reworkclicked=false;
    SessionManager sessionManager;
    ConnectionDetector connectionDetector;
    String internet_interrupt=null;
    String permit_id,str_no;
    SQLiteAdapter1 sqLiteAdapter;
    //private RatingBar ratingBar;
    private TextView txtRatingValue;

    LinearLayout passrework_hold,no_hold;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pass_rework);

        connectionDetector=new ConnectionDetector(Pass_Rework_SiteInspection_Activity.this);
        sessionManager =new SessionManager(Pass_Rework_SiteInspection_Activity.this);
        sqLiteAdapter= new SQLiteAdapter1(Pass_Rework_SiteInspection_Activity.this);

        String uom_status_id=DataHolder_SiteInspection.getInstance().getStr_uom_status();

        passrework_hold=(LinearLayout) findViewById(R.id.layoutid);
        passrework_hold.setVisibility(View.GONE);

        no_hold=(LinearLayout) findViewById(R.id.uom_base);
        no_hold.setVisibility(View.GONE);


        if(Integer.parseInt(uom_status_id)==3){
            passrework_hold.setVisibility(View.VISIBLE);

        }else{

            no_hold.setVisibility(View.VISIBLE);
            ed_no=(EditText) findViewById(R.id.ed_no);
            ed_no.setVisibility(View.VISIBLE);

        }

        //permit_id=sessionManager.GET_EMP_ID();
        ed_no=(EditText) findViewById(R.id.ed_no);
        //ed_no.setVisibility(View.INVISIBLE);
        pass_btn=(Button)findViewById(R.id.passId);
        ButtonOK=(Button)findViewById(R.id.dialogButtonOK);
        ButtonNO=(Button)findViewById(R.id.dialogButtonNo);
        rework_btn=(Button)findViewById(R.id.imageButton2);
        back_btn=(Button)findViewById(R.id.back_btn);


        alert_pop1=(LinearLayout)findViewById(R.id.alert_pop1);

        //addListenerOnRatingBar();
        camera_inspection=(Button)findViewById(R.id.imageButton5);
        camera_inspection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              /*  Intent i = new Intent(Pass_Rework_SiteInspection_Activity.this, UploadinspectionCamera_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
                ShowAlertagain();

            }
        });

        remark_btn=(Button)findViewById(R.id.imageButton6);
        remark_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Pass_Rework_SiteInspection_Activity.this, Site_Inspection_Remark_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
            }
        });

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Intent i = new Intent(Upload_SiteInspection_Activity.this, SiteInspection_Item_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);*/
            }
        });


        pass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //passclicked=true;
                //pass_btn.getBackground().setAlpha(64);
                DataHolder_SiteInspection.getInstance().setStr_pass("1");
                alert_pop1.setVisibility(View.VISIBLE);
            }
        });
        rework_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //reworkclicked=true;
                DataHolder_SiteInspection.getInstance().setStr_pass("2");
                pass_btn.setBackgroundResource(R.drawable.touchstartb);
                rework_btn.setBackgroundResource(R.drawable.touchendb);

            }
        });
        ButtonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataHolder_SiteInspection.getInstance().setStr_pass("1");
                alert_pop1.setVisibility(View.GONE);
                pass_btn.setBackgroundResource(R.drawable.touchstartb);
                rework_btn.setBackgroundColor(0x11000000);


            }
        });
        ButtonNO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alert_pop1.setVisibility(View.GONE);
                //pass_btn.setBackgroundColor(0xFFFF0000);


            }
        });




        finish_btn=(Button)findViewById(R.id.finish_btn);
        finish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                str_no=ed_no.getText().toString().trim();
                DataHolder_SiteInspection.getInstance().setStr_uom_no(str_no);
                Intent i = new Intent(Pass_Rework_SiteInspection_Activity.this, Upload_SiteInspection_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
            }
        });
    }




    @Override
    public void onBackPressed() {

        finish(); // finish activity
        this.overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }



    public boolean isLocationServiceEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = lm.getBestProvider(new Criteria(), true).trim();
        //  Log.e("provider" ,""+provider);
        //  Log.e("LocationManager" ,""+lm);
        return (provider != null &&
                !LocationManager.PASSIVE_PROVIDER.equals(provider));
    }
    public void ShowAlertagain() {
        if (!isLocationServiceEnabled()) {
            // Toast.makeText(getApplicationContext(), "please wait while location is fetching", Toast.LENGTH_SHORT).show();

            runOnUiThread(new Runnable() {
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Pass_Rework_SiteInspection_Activity.this);
                    builder.setMessage("Do you want to on location Setting?");
                    builder.setCancelable(true);
//                    builder.setPositiveButton("OK",
//                            new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    latt = 0;
//                                    longg = 0;
//                                    if (connectionDetector.isConnectingToInternet()) {
////                                        new SendToServer(latt, longg).execute();
//                                    } else {
//
//                                    }
//                                    dialog.cancel();
//                                }
//                            });
                    builder.setNegativeButton("SETTINGS",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    startActivity(intent);
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
        } else {
            //Intent i = new Intent(SiteInspection_TKC_Activity.this, Camera_Activity.class);
            Intent i = new Intent(Pass_Rework_SiteInspection_Activity.this, Camera_Activity.class);
            startActivity(i);
            overridePendingTransition(R.anim.right_in, R.anim.left_out);
            //   Log.e("Latitude", "" + mLocation.getLatitude());
            //   Log.e("Longitude", "" + mLocation.getLongitude());
        }
    }


}
