package com.dc_walk.site_inspection;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dc_walk.R;

public class Site_Inspection_Parameters extends Activity {
    boolean check=true;

    ImageButton next_btn;
    TextView tow_civil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection_parameters);





    }



}
