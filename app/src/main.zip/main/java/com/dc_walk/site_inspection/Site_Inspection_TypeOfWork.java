package com.dc_walk.site_inspection;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dc_walk.R;

public class Site_Inspection_TypeOfWork extends Activity {
    boolean check=true;

    ImageButton next_btn;
    TextView tow_civil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection_typeofwork);

        tow_civil=(TextView)findViewById(R.id.tow_civil);
        tow_civil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //Toast.makeText(Home_Activity.this, "Invalid permit id", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Site_Inspection_TypeOfWork.this, Site_Inspection_TOW_Activities.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);


            }
        });



    }



}
