package com.dc_walk.site_inspection;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.data_holder.DataHolder_SiteInspection;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;

import java.util.ArrayList;

public class Site_InspectionActivity extends Activity {
    boolean check=true;

    RadioGroup radio_consumer_type;


    Spinner spinner_city,spinner_junction;
    String str_zone_id,str_city_name,str_city_id,str_junction_id,str_junction_name;


    Cursor city_cursor,junction_cursor;

    ArrayList<String> city_id_list,city_name_list,zone_id_list;
    ArrayList<String> junction_id_list,junction_name_list;


    ArrayAdapter<String> city_adapter,junction_adapter;
    SQLiteAdapter1 sqLiteAdapter;

    ImageButton finish_btn;

    SessionManager sessionManager;
    ConnectionDetector connectionDetector;
    String response;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection);

        connectionDetector=new ConnectionDetector(Site_InspectionActivity.this);
        sessionManager =new SessionManager(Site_InspectionActivity.this);

        spinner_city = (Spinner) findViewById(R.id.spinner_city);
        spinner_junction = (Spinner) findViewById(R.id.spinner_junction);
        spinner_junction.setVisibility(View.GONE);


        zone_id_list=new ArrayList<String>();
        city_id_list=new ArrayList<String>();
        city_name_list=new ArrayList<String>();

        junction_id_list=new ArrayList<String>();
        junction_name_list=new ArrayList<String>();




        new Project_Value(Site_InspectionActivity.this).execute();
        spinner_city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                str_zone_id = zone_id_list.get(position).toString();
                str_city_id = city_id_list.get(position).toString();
                str_city_name = city_name_list.get(position).toString();

//              Toast.makeText(getApplicationContext(),""+position,Toast.LENGTH_LONG).show();

                if (position > 0) {
                    new SubAreaOne_Value(Site_InspectionActivity.this).execute();
                } else {
                    spinner_junction.setVisibility(View.GONE);
                    //spinner_subarea_one.setAdapter(null);
                    junction_id_list.clear();
                    junction_name_list.clear();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });





        spinner_junction.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                str_junction_id = junction_id_list.get(position).toString();
                str_junction_name=junction_name_list.get(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });




        finish_btn = (ImageButton) findViewById(R.id.next_btn);
        finish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(spinner_city.getSelectedItemPosition() == 0){
                    Toast.makeText(getApplicationContext(), "Select City Name* ", Toast.LENGTH_SHORT).show();

                }else if (spinner_junction.getSelectedItemPosition() == 0)
                {
                    Toast.makeText(getApplicationContext(),"Select Junction Name*",Toast.LENGTH_SHORT).show();
                    // hurray at-least on radio button is checked.
                }else {

                    DataHolder_SiteInspection.getInstance().setStr_zone_id(str_zone_id);
                    DataHolder_SiteInspection.getInstance().setStr_city_id(str_city_id);
                    DataHolder_SiteInspection.getInstance().setStr_junction_id(str_junction_id);

                    Intent i = new Intent(Site_InspectionActivity.this, SiteInspection_Item_Activity.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);
                }
            }
        });




    }






    //...........Project Class...........................................//
    public class Project_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        Project_Value(Context ctx) { _context=ctx;}

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(Site_InspectionActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(Site_InspectionActivity.this);
            try {
                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                // project_cursor=sqLiteAdapter.select_project_all();
                city_cursor=sqLiteAdapter.select_subarea_one_all_allocated();
                if(city_cursor!=null && city_cursor.moveToFirst()){
                    zone_id_list.add("Select City Name");
                    city_id_list.add("Select City Name");
                    city_name_list.add("Select City Name");

                    do {
                        String zone_id=city_cursor.getString(1);
                        String city_id=city_cursor.getString(2);
                        String city_name=city_cursor.getString(3);
                       /* Log.e("city_code",city_id);
                        Log.e("city_name",city_name);*/
                        zone_id_list.add(zone_id);
                        city_id_list.add(city_id);
                        city_name_list.add(city_name);

                    } while (city_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
               /* project_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,project_name_list);
                project_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                city_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,city_name_list);
                spinner_city.setAdapter(city_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }




    //..................... SubAreaOne_Value .................................................//

    public class SubAreaOne_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;Context _context;
        SubAreaOne_Value(Context ctx) {_context=ctx;}
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(Site_InspectionActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {

                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                if(junction_cursor!=null){
                    junction_cursor=null;
                }

                junction_cursor = sqLiteAdapter.select_subarea_two_all(Integer.parseInt(str_city_id));
                //subareaone_cursor = sqLiteAdapter.select_subarea_one_all(Integer.parseInt(geographic_id));
                junction_id_list.clear();
                junction_name_list.clear();
                if(junction_cursor!=null && junction_cursor.moveToFirst()){
                    junction_id_list.add("Select Junction");
                    junction_name_list.add("Select Junction");

                    do {
                        String junction_id=junction_cursor.getString(2);
                        String junction_name=junction_cursor.getString(3);

                      /*  Log.e("junction_id",junction_id);
                        Log.e("junction_name",junction_name);
*/
                        junction_id_list.add(junction_id);
                        junction_name_list.add(junction_name);


                    } while (junction_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
                // Log.e("exception",e.getMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {

                spinner_junction.setVisibility(View.VISIBLE);
                /* subareaone_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,subareaone_name_list);
                subareaone_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                junction_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,junction_name_list);
                spinner_junction.setAdapter(junction_adapter);

                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }







}
