package com.dc_walk.site_inspection;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.dc_walk.R;

public class Site_Inspection_TOW_Activities extends Activity {
    boolean check=true;

    TextView actv_fop;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection_tow_activities);




    }



}
