package com.dc_walk.issues;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.location.Criteria;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.dc_walk.R;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.data_holder.DataHolder_ReceivingInspection;
import com.dc_walk.material_issued.Receiving_Camera_Activity;
import com.dc_walk.sqlite_adapter.SQLiteAdapter1;
import com.dc_walk.sqlite_adapter.SQLiteAdapterIssue;

import java.util.ArrayList;

public class IssuesActivity extends Activity {
    boolean check=true;

    RadioGroup radio_consumer_type;
    Button Button_down;

    Spinner spinner_city,spinner_junction,spinner_inout, spinner_gcj,spinner_issue;
    String str_zone_id,str_inout, str_city_id,str_city_name, str_gcjunction, str_issue_id,str_issue_name,str_junction_id,str_junction_name,str_other,str_remark;

    EditText ed_other,ed_remark;

    LinearLayout vendor_hold;
    RelativeLayout ed_other_holder;

    Cursor city_cursor,issue_cursor,junction_cursor,inout_cursor,general_ccr_jun_cursor;

    ArrayList<String> city_id_list,city_name_list,zone_id_list;
    ArrayList<String> junction_id_list,junction_name_list;
    ArrayList<String> issue_name_list,issue_id_list;
    ArrayList<String> in_out_list;
    ArrayList<String> general_ccr_junction_list;

    ArrayAdapter<String> city_adapter,junction_adapter,issue_adapter,inout_adapter,general_ccr_jun_adapter;
    SQLiteAdapter1 sqLiteAdapter;

    ImageButton finish_btn;

    SessionManager sessionManager;
    ConnectionDetector connectionDetector;
    String response;
    SQLiteAdapterIssue sqLiteAdapterissue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_issues);

        connectionDetector=new ConnectionDetector(IssuesActivity.this);
        sessionManager =new SessionManager(IssuesActivity.this);
        sqLiteAdapterissue= new SQLiteAdapterIssue(IssuesActivity.this);

        spinner_inout = (Spinner) findViewById(R.id.spinner_issue_type);
        spinner_gcj = (Spinner) findViewById(R.id.spinner_type);

        spinner_city = (Spinner) findViewById(R.id.spinner_city);
        spinner_junction = (Spinner) findViewById(R.id.spinner_junction);
        spinner_junction.setVisibility(View.GONE);

        spinner_issue = (Spinner) findViewById(R.id.spinner_issue_list);

        ed_other = (EditText) findViewById(R.id.ed_other_issue);
        ed_other.setVisibility(View.GONE);

        ed_other_holder = (RelativeLayout) findViewById(R.id.ed_other_issue_holder);
        ed_other_holder.setVisibility(View.GONE);


        ed_remark = (EditText) findViewById(R.id.ed_remark);

        zone_id_list=new ArrayList<String>();
        city_id_list=new ArrayList<String>();
        city_name_list=new ArrayList<String>();

        junction_id_list=new ArrayList<String>();
        junction_name_list=new ArrayList<String>();

        issue_id_list=new ArrayList<String>();
        issue_name_list=new ArrayList<String>();

        in_out_list=new ArrayList<String>();
        general_ccr_junction_list=new ArrayList<String>();


        new Project_Value(IssuesActivity.this).execute();
       spinner_city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                str_zone_id = zone_id_list.get(position).toString();
                str_city_id = city_id_list.get(position).toString();
                str_city_name = city_name_list.get(position).toString();
//              Toast.makeText(getApplicationContext(),""+position,Toast.LENGTH_LONG).show();


       }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });



        spinner_issue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                str_issue_id=issue_id_list.get(position).toString();
                str_issue_name=issue_name_list.get(position).toString();

                // Toast.makeText(getApplicationContext(),""+str_issue_name,Toast.LENGTH_LONG).show();
                //if (str_issue_name == "others") {
                if (position == 5) {

                    ed_other.setVisibility(View.VISIBLE);
                    ed_other_holder.setVisibility(View.VISIBLE);
                } else {
                    ed_other.setVisibility(View.GONE);
                    ed_other_holder.setVisibility(View.GONE);

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });


        spinner_junction.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                str_junction_id = junction_id_list.get(position).toString();
                str_junction_name=junction_name_list.get(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        new InOut_Value(IssuesActivity.this).execute();
        spinner_inout.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                str_inout = in_out_list.get(position).toString();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        new General_ccr_junction_Value(IssuesActivity.this).execute();
        spinner_gcj.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                str_gcjunction = general_ccr_junction_list.get(position).toString();

                if (position == 3) {
                    spinner_junction.setVisibility(View.VISIBLE);
                    new SubAreaOne_Value(IssuesActivity.this).execute();
                } else {
                    spinner_junction.setVisibility(View.GONE);
                    //spinner_subarea_one.setAdapter(null);
                    junction_id_list.clear();
                    junction_name_list.clear();
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });




        new Tkc_Value(IssuesActivity.this).execute();


        finish_btn = (ImageButton) findViewById(R.id.btn_finish);
        finish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                str_other= ed_other.getText().toString().trim();
                str_remark= ed_remark.getText().toString().trim();



                if(spinner_inout.getSelectedItemPosition() == 0){
                    Toast.makeText(getApplicationContext(), "Select IN/OUT Name* ", Toast.LENGTH_SHORT).show();


                }else if (spinner_city.getSelectedItemPosition() == 0)
                {
                    Toast.makeText(getApplicationContext(),"Select City Name",Toast.LENGTH_SHORT).show();
                    // hurray at-least on radio button is checked.
                }else  if(spinner_gcj.getSelectedItemPosition() == 0){
                    Toast.makeText(getApplicationContext(), "Select General/CCR/Junction", Toast.LENGTH_SHORT).show();

                }else if(spinner_issue.getSelectedItemPosition() == 0){
                    Toast.makeText(getApplicationContext(), "Select Issue Name* ", Toast.LENGTH_SHORT).show();

                }else if(TextUtils.isEmpty(str_remark)){
                    Toast.makeText(getApplicationContext(), "Enter Remark* ", Toast.LENGTH_SHORT).show();

                } else{


                    DataHolder_ReceivingInspection.getInstance().setIn_out_id(str_inout);
                    DataHolder_ReceivingInspection.getInstance().setMzone_id(str_zone_id);
                    DataHolder_ReceivingInspection.getInstance().setCity_id(str_city_id);
                    DataHolder_ReceivingInspection.getInstance().setG_c_junction(str_gcjunction);
                    DataHolder_ReceivingInspection.getInstance().setJunction_id(str_junction_id);
                    DataHolder_ReceivingInspection.getInstance().setIssue_id(str_issue_id);
                    DataHolder_ReceivingInspection.getInstance().setOther_issue(str_other);
                    DataHolder_ReceivingInspection.getInstance().setStr_remark(str_remark);
                    Intent i = new Intent(IssuesActivity.this, Issue_UploadActivity.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);

                }

            }
        });

        Button_down = (Button) findViewById(R.id.met);
        ed_remark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button_down.setVisibility(View.VISIBLE);
            }

//
        });

        Button_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //when play is clicked show stop button and hide play button
                Button_down.setVisibility(View.GONE);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

            }
        });


    }



    //...........Project Class...........................................//
    public class Project_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        Project_Value(Context ctx) { _context=ctx;}

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(IssuesActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(IssuesActivity.this);
            try {
                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                // project_cursor=sqLiteAdapter.select_project_all();
                city_cursor=sqLiteAdapter.select_subarea_one_all_allocated();
                if(city_cursor!=null && city_cursor.moveToFirst()){
                    zone_id_list.add("Select City Name");
                    city_id_list.add("Select City Name");
                    city_name_list.add("Select City Name");

                    do {
                        String zone_id=city_cursor.getString(1);
                        String city_id=city_cursor.getString(2);
                        String city_name=city_cursor.getString(3);
                      /*  Log.e("dist_code",city_id);
                        Log.e("dist_name",city_name);*/
                        zone_id_list.add(zone_id);
                        city_id_list.add(city_id);
                        city_name_list.add(city_name);

                    } while (city_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
               /* project_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,project_name_list);
                project_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                city_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,city_name_list);
                spinner_city.setAdapter(city_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }




    //..................... SubAreaOne_Value .................................................//

    public class SubAreaOne_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;Context _context;
        SubAreaOne_Value(Context ctx) {_context=ctx;}
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(IssuesActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {

                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                if(junction_cursor!=null){
                    junction_cursor=null;
                }

                junction_cursor = sqLiteAdapter.select_subarea_two_all(Integer.parseInt(str_city_id));
                //subareaone_cursor = sqLiteAdapter.select_subarea_one_all(Integer.parseInt(geographic_id));
                junction_id_list.clear();
                junction_name_list.clear();
                if(junction_cursor!=null && junction_cursor.moveToFirst()){
                    junction_id_list.add("Select Junction");
                    junction_name_list.add("Select Junction");

                    do {
                        String junction_id=junction_cursor.getString(2);
                        String junction_name=junction_cursor.getString(3);

                       /* Log.e("junction_id",junction_id);
                        Log.e("junction_name",junction_name);*/

                        junction_id_list.add(junction_id);
                        junction_name_list.add(junction_name);


                    } while (junction_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
                // Log.e("exception",e.getMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {

                spinner_junction.setVisibility(View.VISIBLE);
                /* subareaone_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,subareaone_name_list);
                subareaone_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/
                junction_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,junction_name_list);
                spinner_junction.setAdapter(junction_adapter);

                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

   //--------For issue-----------------------------//
    public class Tkc_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        Tkc_Value(Context ctx) { _context=ctx;}

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(IssuesActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(IssuesActivity.this);
            try {
                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                //DataHolder_SiteInspection.getInstance().getStr_tkc();
                issue_cursor=sqLiteAdapter.select_material_issued_all();
                if(issue_cursor!=null && issue_cursor.moveToFirst()){
                    issue_id_list.add("Select Issue Name");
                    issue_name_list.add("Select Issue Name");

                    do {
                        String issue_id=issue_cursor.getString(1);
                        String issue_name=issue_cursor.getString(2);
                        issue_id_list.add(issue_id);
                        issue_name_list.add(issue_name);

                    } while (issue_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override
       /* protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
               *//* project_adapter=new ArrayAdapter<String>(SiteInspection_Activity2.this,android.R.layout.simple_spinner_item,project_name_list);
                project_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*//*
                tkc_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,tkc_name_list);
                spinner_tkc.setAdapter(tkc_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }*/

        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {

                issue_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,issue_name_list);
                spinner_issue.setAdapter(issue_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }

    //-----For IN OUT------------------------//
    public class InOut_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        InOut_Value(Context ctx) { _context=ctx;}

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(IssuesActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(IssuesActivity.this);
            try {
                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                //DataHolder_SiteInspection.getInstance().getStr_tkc();
                inout_cursor=sqLiteAdapter.select_in_out_all();
                if(inout_cursor!=null && inout_cursor.moveToFirst()){
                    in_out_list.add("Select IN/OUT Name");

                    do {
                        String inout_id=inout_cursor.getString(1);
                        in_out_list.add(inout_id);

                    } while (inout_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override


        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {

                inout_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,in_out_list);
                spinner_inout.setAdapter(inout_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }

    //------For Greneral CCR Junction----------------------//

    public class General_ccr_junction_Value extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;
        General_ccr_junction_Value(Context ctx) { _context=ctx;}

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(IssuesActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();}

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqLiteAdapter=new SQLiteAdapter1(IssuesActivity.this);
            try {
                sqLiteAdapter.openToRead();
                sqLiteAdapter.openToWrite();
                //DataHolder_SiteInspection.getInstance().getStr_tkc();
                general_ccr_jun_cursor=sqLiteAdapter.select_surveysubstationvoltage_all();
                if(general_ccr_jun_cursor!=null && general_ccr_jun_cursor.moveToFirst()){
                    general_ccr_junction_list.add("Select General/CCR/Junction Type");

                    do {
                        String gcj_id=general_ccr_jun_cursor.getString(1);
                        general_ccr_junction_list.add(gcj_id);


                    } while (general_ccr_jun_cursor.moveToNext());
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
        @Override


        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {

                general_ccr_jun_adapter = new ArrayAdapter<String>(
                        getApplicationContext(), R.layout.custom_spinner, R.id.textView1,general_ccr_junction_list);
                spinner_gcj.setAdapter(general_ccr_jun_adapter);
                sqLiteAdapter.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }




    public boolean isLocationServiceEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = lm.getBestProvider(new Criteria(), true).trim();
        //  Log.e("provider" ,""+provider);
        //  Log.e("LocationManager" ,""+lm);
        return (provider != null &&
                !LocationManager.PASSIVE_PROVIDER.equals(provider));
    }
    public void ShowAlertagain() {
        if (!isLocationServiceEnabled()) {
            // Toast.makeText(getApplicationContext(), "please wait while location is fetching", Toast.LENGTH_SHORT).show();

            runOnUiThread(new Runnable() {
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(IssuesActivity.this);
                    builder.setMessage("Do you want to Continue without location?");
                    builder.setCancelable(true);
//                    builder.setPositiveButton("OK",
//                            new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    latt = 0;
//                                    longg = 0;
//                                    if (connectionDetector.isConnectingToInternet()) {
////                                        new SendToServer(latt, longg).execute();
//                                    } else {
//
//                                    }
//                                    dialog.cancel();
//                                }
//                            });
                    builder.setNegativeButton("SETTINGS",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    startActivity(intent);
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
        } else {
            //Intent i = new Intent(OpenPurchaseInspection_Item_Activity.this, AndroidCameraExample.class);
            Intent i = new Intent(IssuesActivity.this, Receiving_Camera_Activity.class);
            startActivity(i);
            overridePendingTransition(R.anim.right_in, R.anim.left_out);
            //   Log.e("Latitude", "" + mLocation.getLatitude());
            //   Log.e("Longitude", "" + mLocation.getLongitude());
        }
    }


   /* //---------- for sending punch in data to the server------------------//

    public class SendToServer extends AsyncTask<String, String, String>
    {

        ProgressDialog pd;
        // public SendToServer() {
        public SendToServer() {
            // TODO Auto-generated constructor stub

//            Log.e("from", "sendtoserver");
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd = new ProgressDialog(IssuesActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {


                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://monitorpm.feedbackinfra.com/dcnine_honeywell/embc_app/insert_issue_data");
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    nameValuePairs.add(new BasicNameValuePair("permit_id", sessionManager.GET_EMP_ID()));
                    nameValuePairs.add(new BasicNameValuePair("project", sessionManager.GET_PROJECT()));
                    nameValuePairs.add(new BasicNameValuePair("in_out_id", str_inout));
                    nameValuePairs.add(new BasicNameValuePair("zone_id", str_zone_id));
                    nameValuePairs.add(new BasicNameValuePair("city_id", str_city_id));
                    nameValuePairs.add(new BasicNameValuePair("gcjunction", str_gcjunction));
                    nameValuePairs.add(new BasicNameValuePair("junction_id", str_junction_id));
                    nameValuePairs.add(new BasicNameValuePair("issue_id", str_issue_id));
                    nameValuePairs.add(new BasicNameValuePair("other_issue", str_other));
                    nameValuePairs.add(new BasicNameValuePair("remark", str_remark));



                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    Log.e("name value pair", "" + nameValuePairs);
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpclient.execute(httppost, responseHandler);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("response", ""+response);
                    //   Log.e("response", response + "+" + e.getMessage().toString());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();

            try
            {
                response = response.trim();
                Log.e("response",""+response);
                response = response.trim();

                if (response != null && response.equals("1")) {

                    //Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();

                    // custom dialog
                    final Dialog dialog = new Dialog(IssuesActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.getWindow().setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                    dialog.setContentView(R.layout.custom);
//                              dialog.setTitle("Title...");

                    // set the custom dialog components - text, image and button
                    TextView text = (TextView) dialog.findViewById(R.id.text);
                    text.setText("Send Successfully");
//                              ImageView image = (ImageView) dialog.findViewById(R.id.image);
//                              image.setImageResource(R.drawable.ic_launcher);

                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            pd.hide();
                            pd.dismiss();
                            dialog.dismiss();
                            DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                            startActivity(new Intent(IssuesActivity.this, Home_Activity.class));
                            finish();

                        }
                    });

                    dialog.show();


                } else {

                    sqLiteAdapterissue.openToRead();
                    sqLiteAdapterissue.openToWrite();
                    sqLiteAdapterissue.insert_value(sessionManager.GET_EMP_ID(),
                            sessionManager.GET_PROJECT(),
                            DataHolder_ReceivingInspection.getInstance().getIn_out_id(),
                            DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                            DataHolder_ReceivingInspection.getInstance().getCity_id(),
                            DataHolder_ReceivingInspection.getInstance().getG_c_junction(),
                            DataHolder_ReceivingInspection.getInstance().getJunction_id(),
                            DataHolder_ReceivingInspection.getInstance().getIssue_id(),
                            DataHolder_ReceivingInspection.getInstance().getOther_issue(),
                            DataHolder_ReceivingInspection.getInstance().getStr_remark());
                    sqLiteAdapterissue.close();
                    DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                    startActivity(new Intent(IssuesActivity.this, Home_Activity.class));
                    finish();

                    //Toast.makeText(getApplicationContext(), "record saved due to server error", Toast.LENGTH_SHORT).show();

                }
            } catch (Exception e) {
                //Toast.makeText(getApplicationContext(), "Due to low internet connectivity this data would be saved in database", Toast.LENGTH_SHORT).show();

                sqLiteAdapterissue.openToRead();
                sqLiteAdapterissue.openToWrite();
                sqLiteAdapterissue.insert_value(sessionManager.GET_EMP_ID(),
                        sessionManager.GET_PROJECT(),
                        DataHolder_ReceivingInspection.getInstance().getIn_out_id(),
                        DataHolder_ReceivingInspection.getInstance().getMzone_id(),
                        DataHolder_ReceivingInspection.getInstance().getCity_id(),
                        DataHolder_ReceivingInspection.getInstance().getG_c_junction(),
                        DataHolder_ReceivingInspection.getInstance().getJunction_id(),
                        DataHolder_ReceivingInspection.getInstance().getIssue_id(),
                        DataHolder_ReceivingInspection.getInstance().getOther_issue(),
                        DataHolder_ReceivingInspection.getInstance().getStr_remark());
                sqLiteAdapterissue.close();
                DataHolder_ReceivingInspection.getInstance().nullify_DataHolder_ReceivingInspection();
                startActivity(new Intent(IssuesActivity.this, Home_Activity.class));
                finish();

                response = null;


                Log.e("response exception", ""+e.getMessage());
            }
            response = null;
        }

    }*/


}
