package com.dc_walk.notification;

import android.app.Activity;
import android.os.Bundle;

import com.dc_walk.R;

/**
 * Created by nitinb on 02-02-2016.
 */
public class issue_contractor_details extends Activity {

    //public String EMP_ID = "emp_id";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contractor_issue_details);






    }


   /* public void onBackPressed() {
        startActivity(new Intent(ReceivingInspection_Activity.this, Home_Activity.class));
        finish();
        overridePendingTransition(R.anim.right_in, R.anim.left_out);

    }*/




}
