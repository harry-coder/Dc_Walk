package com.dc_walk.site_inspection2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.dc_walk.R;

public class Site_Inspection_Parameter2 extends Activity {
    boolean check=true;

    Button btndone, rem_pop1_cancel;
    ImageButton remButton;
    LinearLayout rem_pop1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection_parameters2);

        remButton=(ImageButton)findViewById(R.id.remButton);
        rem_pop1=(LinearLayout)findViewById(R.id.rem_pop1);
        rem_pop1_cancel=(Button)findViewById(R.id.rem_pop1_cancel);

        btndone=(Button)findViewById(R.id.imageButton7);
        btndone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Home_Activity.this, "Invalid permit id", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Site_Inspection_Parameter2.this, Site_Inspection_Passrework2.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);

            }
        });
        remButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Home_Activity.this, "Invalid permit id", Toast.LENGTH_SHORT).show();
                rem_pop1.setVisibility(View.VISIBLE);

            }
        });
        rem_pop1_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Home_Activity.this, "Invalid permit id", Toast.LENGTH_SHORT).show();
                rem_pop1.setVisibility(View.GONE);

            }
        });



    }



}
