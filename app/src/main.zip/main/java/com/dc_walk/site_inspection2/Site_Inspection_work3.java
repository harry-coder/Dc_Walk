package com.dc_walk.site_inspection2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dc_walk.R;

public class Site_Inspection_work3 extends Activity {
    boolean check=true;

    ImageButton next_btn;
    TextView tow_civil, scopeid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection_typeofwork4);

//        scopeid=(TextView)findViewById(R.id.scopeid);
//        scopeid.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                //Toast.makeText(Home_Activity.this, "Invalid permit id", Toast.LENGTH_SHORT).show();
//                Intent i = new Intent(Site_Inspection_work3.this, Site_Inspection_Parameter2.class);
//                startActivity(i);
//                overridePendingTransition(R.anim.right_in, R.anim.left_out);
//
//            }
//        });




    }



}
