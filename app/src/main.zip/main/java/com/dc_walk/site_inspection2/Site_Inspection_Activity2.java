package com.dc_walk.site_inspection2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dc_walk.R;

public class Site_Inspection_Activity2 extends Activity {
    boolean check=true;

    ImageButton next_btn;
    TextView tow_civil;
    Spinner insptype;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.site_inspection2);


        insptype=(Spinner)findViewById(R.id.insptype);

        next_btn=(ImageButton)findViewById(R.id.next_btn);
        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String text = insptype.getSelectedItem().toString();

                //Toast.makeText(getApplicationContext(), "vlaue is "+text, Toast.LENGTH_LONG).show();


                if(insptype.getSelectedItemPosition() == 1){
                    Intent i = new Intent(Site_Inspection_Activity2.this, Site_Inspection_work1.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);

                }else if (insptype.getSelectedItemPosition() == 2)
                {
                    Intent i = new Intent(Site_Inspection_Activity2.this, Site_Inspection_work2.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);
                }else if(insptype.getSelectedItemPosition() == 3){

                    Intent i = new Intent(Site_Inspection_Activity2.this, Site_Inspection_work3.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.right_in, R.anim.left_out);
                }else {

                    Toast.makeText(getApplicationContext(), "Please Select Inspection Type", Toast.LENGTH_LONG).show();
                }



            }
        });



    }



}
