package com.dc_walk;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dc_walk.walk.Walk_Activity;
import com.dc_walk.authentication.ConnectionDetector;
import com.dc_walk.authentication.SessionManager;
import com.dc_walk.data_holder.DataHolderClass;


import com.dc_walk.sqlite_adapter.SQLiteAdapterMaterialIssued;
import com.dc_walk.sqlite_adapter.SQLiteAdapterReceiving;


import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;


/**
 * Created by nitinb on 28-01-2016.
 */
public class Home_Activity extends Activity {
    ImageButton walk_btn;
    TextView tvView;
    LinearLayout notification_btn;
    DataHolderClass dataHolderClass;
    String permit_id;
    public static String imeiSIM1 ;
    public static String imeiSIM2 ;
    String version;
    PackageInfo pInfo;
    //    SQLiteAdapter1 sqLiteAdapter;
    String georaphiclevel, level1, level2, level3, level4;


    SQLiteAdapterReceiving sqLiteAdapterReceiving;

    SQLiteAdapterMaterialIssued sqLiteAdapterMaterial;
    SessionManager sessionManager;
    String district_id;
    ConnectionDetector detector;


    HttpClient httpclient;
    HttpPost httppost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        sessionManager = new SessionManager(Home_Activity.this);
        this.district_id = sessionManager.GET_CURRENT_URL();


        walk_btn = (ImageButton) findViewById(R.id.walk_id);


        walk_btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub

                Intent i = new Intent(Home_Activity.this, Walk_Activity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
            }
        });

    }

}